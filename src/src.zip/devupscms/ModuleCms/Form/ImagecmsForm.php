<?php 

    class ImagecmsForm extends FormManager{

        public static function formBuilder(\Imagecms $imagecms, $action = null, $button = false) {
            $entitycore = new Core($imagecms);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['width_size'] = [
                "label" => 'Width_size', 
			"type" => FORMTYPE_TEXT, 
                "value" => $imagecms->getWidth_size(), 
            ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/imagecmsForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Imagecms $imagecms, $action = null, $button = false) {
            return FormFactory::__renderForm(ImagecmsForm::formBuilder($imagecms, $action, $button));
        }
        
        public static function __renderFormWidget(\Imagecms $imagecms, $action_form = null) {
            include ROOT.Imagecms::classpath()."Form/ImagecmsFormWidget.php";
        }

        public static function __renderDetailWidget(\Imagecms $imagecms){
            include ROOT . Imagecms::classpath() . "Form/ImagecmsDetailWidget.php";
        }
    }
    