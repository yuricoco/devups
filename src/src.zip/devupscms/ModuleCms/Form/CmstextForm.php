<?php 

    class CmstextForm extends FormManager{

        public static function formBuilder(\Cmstext $cmstext, $action = null, $button = false) {
            $entitycore = new Core($cmstext);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['titre'] = [
                "label" => 'Titre', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $cmstext->getTitre(), 
            ];

            $entitycore->field['reference'] = [
                "label" => 'Reference', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $cmstext->getReference(), 
            ];

            $entitycore->field['content'] = [
                "label" => 'Content',
			"type" => FORMTYPE_TEXTAREA,
                "value" => $cmstext->getContent(), 
            ];

            $entitycore->field['lang'] = [
                "label" => 'Lang', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_RADIO, 
                "value" => $cmstext->getLang(),
                "options" => Cmstext::$LANGS,
            ];
            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/cmstextForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Cmstext $cmstext, $action = null, $button = false) {
            return FormFactory::__renderForm(CmstextForm::formBuilder($cmstext, $action, $button));
        }
        
        public static function __renderFormWidget(\Cmstext $cmstext, $action_form = null) {
            include ROOT.Cmstext::classpath()."Form/CmstextFormWidget.php";
        }

        public static function __renderDetailWidget(\Cmstext $cmstext){
            include ROOT . Cmstext::classpath() . "Form/CmstextDetailWidget.php";
        }

    }
