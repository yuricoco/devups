
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($cmstext, [
['label' => 'Titre', 'value' => 'titre'], 
['label' => 'Reference', 'value' => 'reference'], 
['label' => 'Content', 'value' => 'content'], 
['label' => 'Lang', 'value' => 'lang'], 
['label' => 'Creationdate', 'value' => 'creationdate']
]); ?>

        </div>
			