
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($imagecms, [
['label' => 'Width_size', 'value' => 'width_size']
]); ?>

        </div>
			