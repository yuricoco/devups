
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($timeline, [
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Activate', 'value' => 'activate'], 
['label' => 'Chapter', 'value' => 'Chapter.id']
]); ?>

        </div>
			