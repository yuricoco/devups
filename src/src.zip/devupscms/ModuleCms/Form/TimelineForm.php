<?php

class TimelineForm extends FormManager
{

    public static function formBuilder(\Timeline $timeline, $action = null, $button = false)
    {
        $entitycore = new Core($timeline);

        $entitycore->formaction = $action;
        $entitycore->formbutton = $button;

        //$entitycore->addcss('csspath');


        if($timeline->getId())
            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate',
                FH_REQUIRE => false,
                "type" => FORMTYPE_TEXT,
                "value" => $timeline->getCreationdate(),
            ];

        $entitycore->field['activate'] = [
            "label" => 'Activate',
            FH_REQUIRE => false,
            "type" => FORMTYPE_RADIO,
            "value" => $timeline->getActivate(),
            "options" => Timeline::$ACTIVATES,
        ];

        $entitycore->field['chapter'] = [
            "type" => FORMTYPE_SELECT,
            "value" => $timeline->getChapter()->getId(),
            "label" => 'Chapter',
            "options" => FormManager::Options_Helper('id', Chapter::allrows()),
        ];


        $entitycore->addDformjs($action);
        $entitycore->addjs('Ressource/js/timelineForm.js');

        return $entitycore;
    }

    public static function __renderForm(\Timeline $timeline, $action = null, $button = false)
    {
        return FormFactory::__renderForm(TimelineForm::formBuilder($timeline, $action, $button));
    }

    public static function __renderFormWidget(\Timeline $timeline, $action_form = null)
    {
        include ROOT . Timeline::classpath() . "Form/TimelineFormWidget.php";
    }

    public static function __renderDetailWidget(\Timeline $timeline)
    {
        include ROOT . Timeline::classpath() . "Form/TimelineDetailWidget.php";
    }
}
    