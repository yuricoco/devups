
    <?php //Form::addcss('Ressource/js/cmstext.css') ?>
    
    <?= Form::open($cmstext, ["action"=> "$action_form", "method"=> "post"]) ?>

     <div class='form-group'>
<label for='titre'>Titre</label>
	<?= Form::input('titre', $cmstext->getTitre(), ['class' => 'form-control']); ?>
 </div>
<div class='form-group'>
<label for='reference'>Reference</label>
	<?= Form::input('reference', $cmstext->getReference(), ['class' => 'form-control']); ?>
 </div>
<div class='form-group'>
<label for='content'>Content</label>
	<?= Form::textarea('content', $cmstext->getContent(), ['class' => 'form-control']); ?>
 </div>
<div class='form-group'>
<label for='lang'>Lang</label>
	<?= Form::input('lang', $cmstext->getLang(), ['class' => 'form-control']); ?>
 </div>
<div class='form-group'>
<label for='creationdate'>Creationdate</label>
	<?= Form::input('creationdate', $cmstext->getCreationdate(), ['class' => 'form-control']); ?>
 </div>

       
    <?= Form::submit("save", ['class' => 'btn btn-success']) ?>
    
    <?= Form::close() ?>
    
    <?= Form::addDformjs() ?>    
    <?= Form::addjs('Ressource/js/cmstextForm.js') ?>
    