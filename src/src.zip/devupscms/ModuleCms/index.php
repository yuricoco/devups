<?php
//ModuleCms

require '../../../admin/header.php';

global $views;
$views = __DIR__ . '/Ressource/views';


define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleCms</a> ');


$cmstextCtrl = new CmstextController();
$timelineCtrl = new TimelineController();
$imagecmsCtrl = new ImagecmsController();

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;

    case 'timeline/index':
        Genesis::renderView('timeline.index', $timelineCtrl->listAction());
        break;

    case 'cmstext/index':
        Genesis::renderView('cmstext.index', $cmstextCtrl->listAction());
        break;
    case 'cmstext/_new':
        Genesis::renderView('cmstext.form', $cmstextCtrl->__newAction());
        break;
    case 'cmstext/_edit':
        Genesis::renderView('cmstext.form', $cmstextCtrl->__editAction($_GET['id']));
        break;
    case 'cmstext/create':
        Genesis::renderView('cmstext.form', $cmstextCtrl->createAction(), true);
        break;
    case 'cmstext/update':
        Genesis::renderView('cmstext.form', $cmstextCtrl->updateAction($_GET['id']), true);
        break;


    case 'imagecms/index':
        Genesis::renderView('imagecms.index', $imagecmsCtrl->listAction());
        break;
    case 'imagecms/create':
        Genesis::renderView('imagecms.form', $imagecmsCtrl->createAction(), true);
        break;
    case 'imagecms/update':
        Genesis::renderView('imagecms.form', $imagecmsCtrl->updateAction($_GET['id']), true);
        break;


    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    