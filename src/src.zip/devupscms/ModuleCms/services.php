<?php
//ModuleCms

require '../../../admin/header.php';

use Genesis as g;
use Request as R;

header("Access-Control-Allow-Origin: *");


$cmstextCtrl = new CmstextController();
$imagecmsCtrl = new ImagecmsController();
$timelineCtrl = new TimelineController();

(new Request('hello'));

switch (R::get('path')) {

    case 'timeline._new':
        g::json_encode(TimelineController::renderForm());
        break;
    case 'timeline.create':
        g::json_encode($timelineCtrl->createAction());
        break;
    case 'timeline._edit':
        g::json_encode(TimelineController::renderForm(R::get("id")));
        break;
    case 'timeline.update':
        g::json_encode($timelineCtrl->updateAction(R::get("id")));
        break;
    case 'timeline._show':
        CmstextController::renderDetail(R::get("id"));
        break;
    case 'timeline._delete':
        g::json_encode($timelineCtrl->deleteAction(R::get("id")));
        break;
    case 'timeline._deletegroup':
        g::json_encode($timelineCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'timeline.datatable':
        g::json_encode($timelineCtrl->datatable(R::get('next'), R::get('per_page')));
        break;

    case 'cmstext._new':
        CmstextController::renderForm();
        break;
    case 'cmstext.create':
        g::json_encode($cmstextCtrl->createAction());
        break;
    case 'cmstext._edit':
        g::json_encode(CmstextController::renderForm(R::get("id")));
        break;
    case 'cmstext.update':
        g::json_encode($cmstextCtrl->updateAction(R::get("id")));
        break;
    case 'cmstext._show':
        CmstextController::renderDetail(R::get("id"));
        break;
    case 'cmstext._delete':
        g::json_encode($cmstextCtrl->deleteAction(R::get("id")));
        break;
    case 'cmstext._deletegroup':
        g::json_encode($cmstextCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'cmstext.datatable':
        g::json_encode($cmstextCtrl->datatable(R::get('next'), R::get('per_page')));
        break;
    case 'cmstext.uploadimage':
        g::json_encode($cmstextCtrl->uploadAction());
        break;
    case 'cmstext.loadimage':
        g::json_encode($cmstextCtrl->loadAction());
        break;
    case 'cmstext.deleteimage':
        g::json_encode($cmstextCtrl->deleteimageAction());
        break;

    case 'imagecms._new':
        g::json_encode(ImagecmsController::renderForm());
        break;
    case 'imagecms.create':
        g::json_encode($imagecmsCtrl->createAction());
        break;
    case 'imagecms._edit':
        g::json_encode(ImagecmsController::renderForm(R::get("id")));
        break;
    case 'imagecms.update':
        g::json_encode($imagecmsCtrl->updateAction(R::get("id")));
        break;
    case 'imagecms._show':
        ImagecmsController::renderDetail(R::get("id"));
        break;
    case 'imagecms._delete':
        g::json_encode($imagecmsCtrl->deleteAction(R::get("id")));
        break;
    case 'imagecms._deletegroup':
        g::json_encode($imagecmsCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'imagecms.datatable':
        g::json_encode($imagecmsCtrl->datatable(R::get('next'), R::get('per_page')));
        break;


    default:
        echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
        break;
}

