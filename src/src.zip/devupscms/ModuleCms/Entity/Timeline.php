<?php 
    /**
     * @Entity @Table(name="timeline")
     * */
    class Timeline extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="creationdate", type="datetime"  , nullable=true)
         * @var datetime
         **/
        private $creationdate;
        /**
         **/
        public static $ACTIVATES = [ 'no', 'yes'];
        /**
         * @Column(name="activate", type="integer"  , nullable=true)
         * @var integer
         **/
        private $activate; 
        
        /**
         * @ManyToOne(targetEntity="\Chapter")
         * , inversedBy="reporter"
         * @var \Chapter
         */
        public $chapter;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->chapter = new Chapter();
}

        public function getId()
        {
            return $this->id;
        }
        public function getCreationdate() {
            return $this->creationdate;
        }

        public function setCreationdate($creationdate) {
            $this->creationdate = $creationdate;
        }
        
        public function getActivate() {
            return $this->activate;
        }

        public function setActivate($activate) {
            $this->activate = $activate;
        }
        
        /**
         *  manyToOne
         *	@return \Chapter
         */
        function getChapter() {
            $this->chapter = $this->chapter->__show();
            return $this->chapter;
        }
        function setChapter(\Chapter $chapter) {
            $this->chapter = $chapter;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'creationdate' => $this->creationdate,
                                'activate' => $this->activate,
                                'chapter' => $this->chapter,
                ];
        }
        
}
