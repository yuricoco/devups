<?php 
    /**
     * @Entity @Table(name="cmstext")
     * */
    class Cmstext extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="titre", type="string" , length=255 , nullable=true)
         * @var string
         **/
        private $titre;
        /**
         * @Column(name="reference", type="string" , length=25 , nullable=true)
         * @var string
         **/
        private $reference;
        /**
         * @Column(name="content", type="text"  )
         * @var text
         **/
        private $content;
        /**
         **/
        public static $LANGS = [ 'en' => 'En', 'fr' => 'Fr'];
        /**
         * @Column(name="lang", type="string" , length=2 , nullable=true)
         * @var string
         **/
        private $lang = 'en' ;
        /**
         * @Column(name="creationdate", type="datetime"  )
         * @var datetime
         **/
        private $creationdate;

        /**
         * @Column(name="sommary", type="text", nullable=true  )
         * @var text
         * */
        private $sommary = "";

        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
}

        public function getId() {
            return $this->id;
        }
        public function getTitre() {
            return $this->titre;
        }

        public function setTitre($titre) {
            $this->titre = $titre;
        }
        
        public function getReference() {
            if(!$this->reference)
                return url_format($this->titre);
            return $this->reference;
        }

        public function setReference($reference) {
            $this->reference = $reference;
        }
        
        public function getContent() {
            return $this->content;
        }

        public function setContent($content) {
            $this->content = $content;
        }
        
        public function getLang() {
            return $this->lang;
        }

        public function setLang($lang) {
            $this->lang = $lang;
        }
        
        public function getCreationdate() {
            return $this->creationdate;
        }

        public function setCreationdate($creationdate) {
            $this->creationdate = $creationdate;
        }

        function getSommary() {

            return $this->sommary;

        }

        function setSommary($content =  "") {
            $paragraphe = str_replace("<p>", "", explode("</p>", $this->content)[0]);

            //$paragraphearray = explode("<body>", $paragraphe);

            //if (isset($paragraphearray[1]))
             //   $this->sommary = $paragraphearray[1];
            //else
                $this->sommary = $paragraphe;
//        $this->sommary = substr($this->sommary, 0, 255);
//        return $this->sommary;
        }


        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'titre' => $this->titre,
                                'reference' => $this->reference,
                                'content' => $this->content,
                                'lang' => $this->lang,
                                'creationdate' => $this->creationdate,
                ];
        }
        
}
