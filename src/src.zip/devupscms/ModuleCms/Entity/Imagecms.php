<?php

/**
 * @Entity @Table(name="imagecms")
 * */
class Imagecms extends \Imagemodel implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;

    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

    }

    public function getId()
    {
        return $this->id;
    }

    public function getWidth_size()
    {
        return $this->width_size;
    }

    public function setWidth_size($width_size)
    {
        $this->width_size = $width_size;
    }


    public function jsonSerialize()
    {
        return parent::jsonSerialize();
    }

}
