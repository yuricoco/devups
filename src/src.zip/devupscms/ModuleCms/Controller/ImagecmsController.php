<?php 


use DClass\devups\Datatable as Datatable;

class ImagecmsController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            ImagecmsForm::__renderFormWidget(Imagecms::find($id), 'update');
        else
            ImagecmsForm::__renderFormWidget(new Imagecms(), 'create');
    }

    public static function renderDetail($id) {
        ImagecmsForm::__renderDetailWidget(Imagecms::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $imagecms = new Imagecms();
        if($id){
            $action = "update&id=".$id;
            $imagecms = Imagecms::find($id);
            //$imagecms->collectStorage();
        }

        return ['success' => true,
            'form' => ImagecmsForm::__renderForm($imagecms, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Imagecms(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Imagecms(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $imagecms = Imagecms::find($id);

            return array( 'success' => true, 
                            'imagecms' => $imagecms,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($imagecms_form = null){
        extract($_POST);

        $imagecms = $this->form_fillingentity(new Imagecms(), $imagecms_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'imagecms' => $imagecms,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $imagecms->__insert();
        return 	array(	'success' => true,
                        'imagecms' => $imagecms,
                        'tablerow' => Datatable::getSingleRowRest($imagecms),
                        'detail' => '');

    }

    public function updateAction($id, $imagecms_form = null){
        extract($_POST);
            
        $imagecms = $this->form_fillingentity(new Imagecms($id), $imagecms_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'imagecms' => $imagecms,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $imagecms->__update();
        return 	array(	'success' => true,
                        'imagecms' => $imagecms,
                        'tablerow' => Datatable::getSingleRowRest($imagecms),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Imagecms::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Imagecms::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'imagecms' => new Imagecms(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $imagecms = Imagecms::find($id);

        return array('success' => true, // pour le restservice
                        'imagecms' => $imagecms,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
