<?php 


use DClass\devups\Datatable as Datatable;

class TimelineController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            TimelineForm::__renderFormWidget(Timeline::find($id), 'update');
        else
            TimelineForm::__renderFormWidget(new Timeline(), 'create');
    }

    public static function renderDetail($id) {
        TimelineForm::__renderDetailWidget(Timeline::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $timeline = new Timeline();
        if($id){
            $action = "update&id=".$id;
            $timeline = Timeline::find($id);
            //$timeline->collectStorage();
        }

        return ['success' => true,
            'form' => TimelineForm::__renderForm($timeline, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Timeline(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Timeline(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $timeline = Timeline::find($id);

            return array( 'success' => true, 
                            'timeline' => $timeline,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($timeline_form = null){
        extract($_POST);

        $timeline = $this->form_fillingentity(new Timeline(), $timeline_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'timeline' => $timeline,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }

        $timeline->setCreationdate(new DateTime());

        $id = $timeline->__insert();
        return 	array(	'success' => true,
                        'timeline' => $timeline,
                        'tablerow' => Datatable::getSingleRowRest($timeline),
                        'detail' => '');

    }

    public function updateAction($id, $timeline_form = null){
        extract($_POST);
            
        $timeline = $this->form_fillingentity(new Timeline($id), $timeline_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'timeline' => $timeline,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $timeline->__update();
        return 	array(	'success' => true,
                        'timeline' => $timeline,
                        'tablerow' => Datatable::getSingleRowRest($timeline),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Timeline::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Timeline::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'timeline' => new Timeline(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $timeline = Timeline::find($id);

        return array('success' => true, // pour le restservice
                        'timeline' => $timeline,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    /**
     * retourne un tableau d'instance de l'entité ou un json pour les requetes asynchrone (ajax)
     *
     * @param type $id
     * @return \Array
     */
    public static function listOrderedAction($lang = "fr")
    {
        $__lang = local();
        if (isset($_SESSION[USERAPP]))
            $__lang = userapp()->getLang();

        $timelines = [];
        $qb = new QueryBuilder(new Timeline());
        //$qb = new QueryBuilder(new Chapter());
        $listTimeline = $qb->select()
            ->leftjoin(Comicbook::class, Chapter::class)
            ->where("chapter.lang", '=', $__lang)
            ->andwhere("this.activate", '=', 1)
            ->andwhere("comicbook.ischronic", '=', 0)
            ->orderby("this.creationdate desc")
            ->limit(10)
//                ->getSqlQuery();
            ->__getAll();

        $listads = [
            '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- infeed1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7691146384467908"
     data-ad-slot="2093271254"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
            '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- infeed2 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7691146384467908"
     data-ad-slot="4178462821"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
            '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- infeed3 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7691146384467908"
     data-ad-slot="1735954705"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
        ];
        $iter = 0;
        foreach ($listTimeline as $i => $timeline) {
            $ads = "";

            if ($i % 3) {
                if (isset($listads[$iter]))
                    $ads = $listads[$iter];
                $iter++;
            }

            $iliked = 0;
            if (isset($_SESSION[USERID]))
                $iliked = Kolachapter::select()->where($timeline->chapter)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

            $timelines[] = [
                'timeline' => $timeline,
                'ads' => $ads,
                'firstpage' => 1,
                'iliked' => $iliked,
                'nbkolas' => Kolachapter::count($timeline->chapter),
                'nbcomments' => Comment::select()->where($timeline->chapter)->__countEl(false),
                'comments' => $timeline->chapter->__hasmany(Comment::class, false)->limit(15)->__getAll()
            ];
        }

        return array('success' => true, // pour le restservice
            'timelines' => $timelines,
            'url' => '#', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }

    public static function fluxrssgenerator(){



        $contenu = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
<rss version=\"2.0\">
    <channel>

        <title>Dernières sorties sur 3ag édition</title>
        <link>http://3ag-edition.com</link>
        <description>Sorties récentes des mangas</description>

        <item>
            <title>Sale temps !</title>
            <link>http://weather.com</link>
            <guid isPermaLink=\"False\">Le temps qu'il fait</guid>
            <description>Il ne fait vraiment pas beau aujourd'hui.</description>
            <pubDate>Tue, 9 Aug 2005 16:20:00 GMT</pubDate>
        </item>

        <item>
            <title>Un site web pour partager ses signets</title>
            <link>http://del.icio.us</link>
            <guid isPermaLink=\"true\">http://del.icio.us</guid>
            <description>Le site http://del.icio.us permet de partager vos signets et d'y accéder où que vous soyez.</description>
            <pubDate>Wed, 5 Aug 2005 19:30:00 GMT</pubDate>
        </item>

        <item>
            <title>Enfin un flux RSS !</title>
            <link>http://monsiteweb.com/rss.html</link>
            <guid isPermaLink=\"true\">http://monsiteweb.com/rss.html</guid>
            <description>Un flux RSS a été installé sur mon site. Vous pouvez le consulter avec votre logiciel favori.</description>
            <pubDate>Wed, 3 Aug 2005 15:17:00 GMT</pubDate>
        </item>

    </channel>
</rss>";

        $entityrooting = fopen(ROOT.'fluxrss.xml', 'w');

        fputs($entityrooting, $contenu);

        fclose($entityrooting);

    }

}
