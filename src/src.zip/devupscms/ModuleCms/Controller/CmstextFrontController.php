<?php
/**
 * Created by PhpStorm.
 * User: Aurelien Atemkeng
 * Date: 15/04/2019
 * Time: 3:20 PM
 */

class CmstextFrontController extends CmstextController
{


    public function showAction($id)
    {

        $cmstext = Cmstext::select()->where("this.reference", "/".$id)->__getOne();

        $suggestioncontents = Cmstext::select()->limit(12)->orderby(" RAND() ")->__getAll();

        if(!$cmstext->getId()){
            return [
                'success' => false,
                'cmstext' => $cmstext,
                'suggestioncontents' =>$suggestioncontents,
                "title" => gettranslation("menu.home"),
                "meta_seo_title" => "",
                "meta_seo_image" => "",
                "meta_seo_description" => "",
            ];
        }

        return array('success' => true,
            'cmstext' => $cmstext,
            'suggestioncontents' =>$suggestioncontents,
            "title" => $cmstext->getTitre(),
            "meta_seo_title" => $cmstext->getTitre(),
            "meta_seo_image" => "",
            "meta_seo_description" => $cmstext->getSommary(),
            'detail' => 'detail de l\'action.');

    }

}
