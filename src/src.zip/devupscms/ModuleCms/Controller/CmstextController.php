<?php 


use DClass\devups\Datatable as Datatable;

class CmstextController extends Controller{

    public function uploadAction(){

        $url = Dfile::init("image")
            ->addresize([800], "", "", false)
            ->addresize([230], "230_", "cmsimages/thumbs/", false)
//            ->addresize([100, 100], "admin_", $uploaddir . "mini/", false)
//            ->addresize([50], "50_", $uploaddir . "mini/", false)
            ->sanitize()
            //->setfile_name($_GET["imagename"].".jpg")
            ->moveto("cmsimages");

        return ["link" => SRC_FILE . "cmsimages/" . $url["file"]["hashname"]];
    }

    public function loadAction(){

        $pages = [];
        $uploaddir = "cmsimages/";
        $dirs = UPLOAD_DIR . $uploaddir;
        if(!file_exists($dirs)){
            return [];
        }
        $src_pages = scanDir::scan($dirs, ["jpg", "jpeg", "png"]);
        for($i = 0; $i < count($src_pages); $i++){

            $pagearray = explode($uploaddir, $src_pages[$i]);
            $pagearray[1] = str_replace("\\", "", $pagearray[1]);
            $pagearray[1] = str_replace("/", "", $pagearray[1]);

            $pages[] = ["name" => $pagearray[1],"url" => SRC_FILE . $uploaddir . $pagearray[1], "thumb" => SRC_FILE . $uploaddir . "thumbs/230_" . $pagearray[1]];

        }

        return $pages;
    }

    public function deleteimageAction(){
        Dfile::deleteFile($_GET["image"], "cmsimages/");
        Dfile::deleteFile("thumbs/230_" . $_GET["image"], "cmsimages/");
        return $_GET["image"];
    }

    public static function renderFormWidget($id = null) {
        if($id)
            CmstextForm::__renderFormWidget(Cmstext::find($id), 'update');
        else
            CmstextForm::__renderFormWidget(new Cmstext(), 'create');
    }

    public static function renderDetail($id) {
        CmstextForm::__renderDetailWidget(Cmstext::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $cmstext = new Cmstext();
        if($id){
            $action = "update&id=".$id;
            $cmstext = Cmstext::find($id);
            //$cmstext->collectStorage();
        }

        CmstextForm::__renderFormWidget($cmstext, $action);

//        return ['success' => true,
//            'form' => CmstextForm::__renderForm($cmstext, $action, true),
//        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Cmstext(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Cmstext(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $cmstext = Cmstext::find($id);

            return array( 'success' => true, 
                            'cmstext' => $cmstext,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($cmstext_form = null){
        extract($_POST);

        $cmstext = $this->form_fillingentity(new Cmstext(), $cmstext_form);
 

        $cmstext->setCreationdate(new DateTime());

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'cmstext' => $cmstext,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $cmstext->setSommary();
        $id = $cmstext->__insert();
        return 	array(	'success' => true,
                        'cmstext' => $cmstext,
                        //'tablerow' => Datatable::getSingleRowRest($cmstext),
                        'detail' => '');

    }

    public function updateAction($id, $cmstext_form = null){
        extract($_POST);
            
        $cmstext = $this->form_fillingentity(new Cmstext($id), $cmstext_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'cmstext' => $cmstext,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }

        $cmstext->setSommary();
        $cmstext->__update();
        return 	array(	'success' => true,
                        'cmstext' => $cmstext,
                        //'tablerow' => Datatable::getSingleRowRest($cmstext),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Cmstext::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Cmstext::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'cmstext' => new Cmstext(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $cmstext = Cmstext::find($id);

        return array('success' => true, // pour le restservice
                        'cmstext' => $cmstext,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
