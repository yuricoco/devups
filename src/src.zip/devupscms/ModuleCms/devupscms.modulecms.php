<?php 
    require 'Entity/Cmstext.php';
    //require 'Dao/CmstextDAO.php';
    require 'Form/CmstextForm.php';
    require 'Controller/CmstextController.php';
    //require 'Genesis/CmstextGenesis.php';

    require 'Entity/Imagecms.php';
    //require 'Dao/ImagecmsDAO.php';
    require 'Form/ImagecmsForm.php';
    require 'Controller/ImagecmsController.php';
    //require 'Genesis/ImagecmsGenesis.php';


    require 'Entity/Timeline.php';
    //require 'Dao/TimelineDAO.php';
    require 'Form/TimelineForm.php';
    require 'Controller/TimelineController.php';
    //require 'Genesis/TimelineGenesis.php';
