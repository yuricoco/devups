<?php
            //ModuleTranslation
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleTranslation</a> ');

    
        		$chapterdialogCtrl = new ChapterdialogController();		$chaptertranslateCtrl = new ChaptertranslateController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'chapterdialog/index':
        Genesis::renderView('chapterdialog.index',  $chapterdialogCtrl->listAction());
        break;					
    case 'chapterdialog/create':
        Genesis::renderView( 'chapterdialog.form', $chapterdialogCtrl->createAction(), true);
        break;					
    case 'chapterdialog/update':
        Genesis::renderView( 'chapterdialog.form',  $chapterdialogCtrl->updateAction($_GET['id']), true);
        break;


    case 'chaptertranslate/_edit':
        Genesis::renderView('chaptertranslate.form', $chaptertranslateCtrl->__editAction($_GET['id']));
        break;
    case 'chaptertranslate/_show':
        Genesis::renderView('chaptertranslate.show', $chaptertranslateCtrl->showAction($_GET['id']));
        break;
    case 'chaptertranslate/index':
        Genesis::renderView('chaptertranslate.index',  $chaptertranslateCtrl->listAction());
        break;					
    case 'chaptertranslate/create':
        Genesis::renderView( 'chaptertranslate.form', $chaptertranslateCtrl->createAction(), true);
        break;					
    case 'chaptertranslate/update':
        Genesis::renderView( 'chaptertranslate.form',  $chaptertranslateCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    