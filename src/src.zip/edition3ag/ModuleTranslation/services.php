<?php
//ModuleTranslation

require '../../../admin/header.php';

use Genesis as g;
use Request as R;

header("Access-Control-Allow-Origin: *");


$chapterdialogCtrl = new ChapterdialogController();
$chaptertranslateCtrl = new ChaptertranslateController();

(new Request('hello'));

switch (R::get('path')) {

    case 'chapterdialog._new':
        g::json_encode(ChapterdialogController::renderForm());
        break;
    case 'chapterdialog.create':
        g::json_encode($chapterdialogCtrl->createAction());
        break;
    case 'chapterdialog._edit':
        g::json_encode(ChapterdialogController::renderForm(R::get("id")));
        break;
    case 'chapterdialog.update':
        g::json_encode($chapterdialogCtrl->updateAction(R::get("id")));
        break;
    case 'chapterdialog._show':
        ChapterdialogController::renderDetail(R::get("id"));
        break;
    case 'chapterdialog._delete':
        g::json_encode($chapterdialogCtrl->deleteAction(R::get("id")));
        break;
    case 'chapterdialog._deletegroup':
        g::json_encode($chapterdialogCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'chapterdialog.datatable':
        g::json_encode($chapterdialogCtrl->datatable(R::get('next'), R::get('per_page')));
        break;

    case 'chaptertranslate.resettranslatedata':
        g::json_encode($chaptertranslateCtrl->resettranslatedataAction(R::get("id")));
        break;
    case 'chaptertranslate.validatetranslate':
        g::json_encode($chaptertranslateCtrl->validatetranslateAction(R::get("id")));
        break;
    case 'chaptertranslate._new':
        g::json_encode(ChaptertranslateController::renderForm());
        break;
    case 'chaptertranslate.create':
        g::json_encode($chaptertranslateCtrl->createAction());
        break;
    case 'chaptertranslate._edit':
        g::json_encode(ChaptertranslateController::renderForm(R::get("id")));
        break;
    case 'chaptertranslate.update':
        g::json_encode($chaptertranslateCtrl->updateAction(R::get("id")));
        break;
    case 'chaptertranslate._show':
        ChaptertranslateController::renderDetail(R::get("id"));
        break;
    case 'chaptertranslate._delete':
        g::json_encode($chaptertranslateCtrl->deleteAction(R::get("id")));
        break;
    case 'chaptertranslate._deletegroup':
        g::json_encode($chaptertranslateCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'chaptertranslate.datatable':
        g::json_encode($chaptertranslateCtrl->datatable(R::get('next'), R::get('per_page')));
        break;


    default:
        echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
        break;
}

