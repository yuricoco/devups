<?php 
    require 'Entity/Chapterdialog.php';
    //require 'Dao/ChapterdialogDAO.php';
    require 'Form/ChapterdialogForm.php';
    require 'Controller/ChapterdialogController.php';
    //require 'Genesis/ChapterdialogGenesis.php';

    require 'Entity/Chaptertranslate.php';
    //require 'Dao/ChaptertranslateDAO.php';
    require 'Form/ChaptertranslateForm.php';
    require 'Controller/ChaptertranslateController.php';
    //require 'Genesis/ChaptertranslateGenesis.php';
