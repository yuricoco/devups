<?php 
    /**
     * @Entity @Table(name="chapterdialog")
     * */
    class Chapterdialog extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="checked_at", type="datetime"  , nullable=true)
         * @var datetime
         **/
        private $checked_at;
        /**
         * @Column(name="status", type="integer"  )
         * @var integer
         **/
        private $status;
        /**
         * @Column(name="nbwords", type="integer"  )
         * @var integer
         **/
        private $nbwords;
        /**
         * @Column(name="started_at", type="datetime"  , nullable=true)
         * @var datetime
         **/
        private $started_at; 
        
        /**
         * @ManyToOne(targetEntity="\Abonne")
         * , inversedBy="reporter"
         * @var \Abonne
         */
        public $abonne;

        /**
         * @ManyToOne(targetEntity="\Chapter")
         * , inversedBy="reporter"
         * @var \Chapter
         */
        public $chapter;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->abonne = new Abonne();
	$this->chapter = new Chapter();
}

        public function getId() {
            return $this->id;
        }

        public function getChecked_at() {
                if(is_object($this->checked_at))
                        return $this->checked_at;
                else
                        return new DateTime($this->checked_at);
        }

        public function setChecked_at($checked_at) {
                    if(is_object($checked_at))
                            $this->checked_at = $checked_at;
                    else
                            $this->checked_at = new DateTime($checked_at);
        }
        public function getStatus() {
            return $this->status;
        }

        public function setStatus($status) {
            $this->status = $status;
        }
        
        public function getNbwords() {
            return $this->nbwords;
        }

        public function setNbwords($nbwords) {
            $this->nbwords = $nbwords;
        }
        

        public function getStarted_at() {
                if(is_object($this->started_at))
                        return $this->started_at;
                else
                        return new DateTime($this->started_at);
        }

        public function setStarted_at($started_at) {
                    if(is_object($started_at))
                            $this->started_at = $started_at;
                    else
                            $this->started_at = new DateTime($started_at);
        }
        /**
         *  manyToOne
         *	@return \Abonne
         */
        function getAbonne() {
            $this->abonne = $this->abonne->__show();
            return $this->abonne;
        }
        function setAbonne(\Abonne $abonne) {
            $this->abonne = $abonne;
        }
                        
        /**
         *  manyToOne
         *	@return \Chapter
         */
        function getChapter() {
            $this->chapter = $this->chapter->__show();
            return $this->chapter;
        }
        function setChapter(\Chapter $chapter) {
            $this->chapter = $chapter;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'checked_at' => $this->checked_at,
                                'status' => $this->status,
                                'nbwords' => $this->nbwords,
                                'started_at' => $this->started_at,
                                'abonne' => $this->abonne,
                                'chapter' => $this->chapter,
                ];
        }
        
}
