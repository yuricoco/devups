<?php

/**
 * @Entity @Table(name="chaptertranslate")
 * */
class Chaptertranslate extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="nbpages", type="integer"  )
     * @var integer
     **/
    private $nbpages;
    /**
     * @Column(name="nbwords", type="integer"  )
     * @var integer
     **/
    private $nbwords = 0;
    /**
     * @Column(name="creationdate", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $creationdate;
    /**
     * @Column(name="date_start", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $date_start;
    /**
     * @Column(name="date_end", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $date_end;
    /**
     * @Column(name="validated_at", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $validated_at;
    /**
     * @Column(name="lang", type="string" , length=2 , nullable=true)
     * @var string
     **/
    private $lang;

    public static $STATUSS = ['dr' => 'draft', 'pr' => 'in process', 'pe' => 'in pending', 'fi' => 'finish', 'va' => 'validated', 'ca' => 'canceled'];
    /**
     * @Column(name="status", type="string", length=2  )
     * @var integer
     **/
    private $status = "pe";


    /**
     * @ManyToOne(targetEntity="\Chapter")
     * , inversedBy="reporter"
     * @var \Chapter
     */
    public $chapter;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    public $user;

    /**
     * @ManyToOne(targetEntity="\Dvups_admin")
     * , inversedBy="reporter"
     * @var \Dvups_admin
     */
    public $dvups_admin;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->chapter = new Chapter();
        $this->user = new User();
        $this->dvups_admin = new Dvups_admin();
    }

    public function getId()
    {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getNbwords()
    {
        return $this->nbwords;
    }

    /**
     * @param int $nbwords
     */
    public function setNbwords($nbwords)
    {
        $this->nbwords = $nbwords;
    }

    public function getDate_start()
    {
        if (is_object($this->date_start))
            return $this->date_start;
        else
            return new DateTime($this->date_start);
    }

    public function setDate_start($date_start)
    {
        if (is_object($date_start))
            $this->date_start = $date_start;
        else
            $this->date_start = new DateTime($date_start);
    }

    public function getDate_end()
    {
        if (is_object($this->date_end))
            return $this->date_end;
        else
            return new DateTime($this->date_end);
    }

    public function setDate_end($date_end)
    {
        if (is_object($date_end))
            $this->date_end = $date_end;
        else
            $this->date_end = new DateTime($date_end);
    }

    /**
     * @return datetime
     */
    public function getValidated_at()
    {
        return $this->validated_at;
    }

    /**
     * @param datetime $validated_at
     */
    public function setValidated_at($validated_at)
    {
        $this->validated_at = $validated_at;
    }

    public function getLang()
    {
        return $this->lang;
    }

    public function setLang($lang)
    {
        $this->lang = $lang;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return int
     */
    public function getNbpages()
    {
        return $this->nbpages;
    }

    /**
     * @param int $nbpages
     */
    public function setNbpages($nbpages)
    {
        $this->nbpages = $nbpages;
    }

    /**
     * @return datetime
     */
    public function getCreationdate()
    {
        return $this->creationdate;
    }

    /**
     * @param datetime $creationdate
     */
    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    /**
     * @return Chapter
     */
    public function getChapter()
    {
        return $this->chapter;
    }

    /**
     * @param Chapter $chapter
     */
    public function setChapter($chapter)
    {
        $this->chapter = $chapter;
    }

    /**
     * @return User
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * @param User $user
     */
    public function setUser($user)
    {
        $this->user = $user;
    }

    /**
     * @return Dvups_admin
     */
    public function getDvupsAdmin()
    {
        return $this->dvups_admin;
    }

    /**
     * @param Dvups_admin $dvups_admin
     */
    public function setDvupsAdmin($dvups_admin)
    {
        $this->dvups_admin = $dvups_admin;
    }

    function validatetranslateAction()
    {
        $action = "";
        if ($this->status == "fi")
            return '<span onclick="model.validatetranslate(' . $this->getId() . ', this)" class="btn btn-info btn-sm">Validate translate</span>';

        if ($this->status == "dr")
            $action .= '<span  onclick="model.resettranslatedata(' . $this->getId() . ', this)" class="btn btn-warning btn-sm">Reset</span>';

        if ($this->status != "va")
            return $action.'<span class="btn btn-deficit btn-sm">Cancel</span>';

        return "";
    }

    public static function statusSearch($inputname)
    {
        return "<select name='$inputname' class='form-control' >
<option value=''>All</option>
<option value='pe'>In pending</option>
</select>";
    }

    function editAction (){
        return '<span data-toggle="modal" data-target="#chaptertranslatemodal" onclick="model._edit('.$this->getId().')" class="btn btn-primary btn-sm">Edit</span>' ;
    }

    function starttranslateAction()
    {
        if ($this->status == "pe")
            return '<span onclick="model.starttranslate(' . $this->getId() . ', this)" class="btn btn-deficit btn-sm">Start translation</span>';

        if($this->user->getId() == $_SESSION[USERID]){
            if ($this->status == "pr" )
                return '<span onclick="model.bindview(' . $this->getId() . ', this)" class="btn btn-warning btn-sm">Continue</span>';
            elseif($this->status == "fi" || $this->status == "va")
                return '<span onclick="model.bindview(' . $this->getId() . ', this)" class="btn btn-info btn-sm">Voir</span>';
        }

        return "";
    }

    public function getIconestatus()
    {
        if ($this->status == "pe") // draft
            return "<span class='btn '> " . gettranslation('status.inpending') . "</span>";
        elseif ($this->status == "pr") // publish
            return "<span class='btn btn-warning'><i class='glyphicon glyphicon-option-horizontal  '></i> " . gettranslation('status.inprocess') . "</span>";
        elseif ($this->status == "fi") // checking validate
            return "<span class='btn btn-info'> " . gettranslation('status.finished') . "</span> ";
        elseif ($this->status == "va") // checking validate
            return "<span class='btn btn-success'><i class='fa fa-check'></i> " . gettranslation('status.validated') . "</span> ";
        else
            return "<span class='btn btn-info'>en attente</span>";
    }

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'date_start' => $this->date_start,
            'date_end' => $this->date_end,
            'lang' => $this->lang,
            'status' => $this->status,
            'nbwords' => $this->nbwords,
            'chapter' => $this->chapter,
            'user' => $this->user->commentuser(),
        ];
    }

}
