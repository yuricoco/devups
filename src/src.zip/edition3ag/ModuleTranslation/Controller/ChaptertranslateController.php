<?php


use DClass\devups\Datatable as Datatable;

class ChaptertranslateController extends Controller
{

    public function resettranslatedataAction($id){
        $chaptertranslate = Chaptertranslate::find($id, false);
        $chapter = $chaptertranslate->chapter->__show(false);
        $pages = $chapter->getPages();
        $pagesjson = [];
        foreach ($pages as $page) {
            $pagesjson[] = [
                "name" => $page["page"],
                "double" => $page["double"],
                "bubbles" => [],
            ];
        }

        $chaptertranslatejson = [
            "_id" => $id,
            "pages" => $pagesjson,
        ];

        $file = fopen(ROOT . "data/chaptertranslate/" . $id . ".json", "w");
        fputs($file, json_encode($chaptertranslatejson));
        fclose($file);

        return ["success" => true];

    }

    public function validatetranslateAction($id)
    {

        $chaptertranslate = Chaptertranslate::find($id, false);
        $chaptertranslate->__update([
            "status" => "va",
            "validated_at" => date("Y-m-d H:i:s"),
        ], false, false, false)->exec();

        $chapter = $chaptertranslate->chapter->__show();
        //$idchap = Chaptertranslate::getattribut("chapter_id", $id);
        $chapter->__update([
            "intranslation" => "0",
            "translated" => 1,
        ])->exec();

        $alternatif = $chapter->comicbook->__get("alternatif");
        $notif = new Notification();
        $notif->setCreationdate(new DateTime());
        $notif->setEntity(Chaptertranslate::class);
        $notif->setEntityid($id);
        $notif->__insert();

        //todo create notification then user_notification for user
        $user = User::findrow($chaptertranslate->user->getId());

        $content = $alternatif . " "
            . gettranslation("title.chapter", $user->getLang()) . " "
            . $chapter->getNumber() . " "
            . gettranslation("notif.translatevalidated", $user->getLang());

        NotificationbroadcastedController::broadcast($user, null, $notif, $content, "my-account?root=chaptertranslatelist");

        return array('success' => true,
            'redirect' => "index.php?path=chaptertranslate/index",
            //'tablerow' => Datatable::getSingleRowRest($chaptertranslate),
            'detail' => '');
    }

    public function finishtranslateAction($id)
    {
        //Chaptertranslate::update("status", "fi", $id, false)->exec();

        $chaptertranslate = Chaptertranslate::find($id);
        $chaptertranslate->__update([
            "this.status" => "fi",
            "date_end" => date("Y-m-d H:i:s"),
        ], false, false, false)->exec();

        $chapter = $chaptertranslate->chapter;
        $alternatif = $chapter->comicbook->__get("alternatif");
        $notif = new Notification();
        $notif->setCreationdate(new DateTime());
        $notif->setEntity(Chaptertranslate::class);
        $notif->setEntityid($id);
        $notif->__insert();

        $admims = Dvups_admin::allrows();
        foreach ($admims as $admim) {
            $content = $chaptertranslate->user->getPseudo() . ' '
                . gettranslation("notif.finishedtranslateof") . ' ' . $alternatif . " "
                . gettranslation("title.chapter") . " "
                . $chapter->getNumber() . " ";

            NotificationbroadcastedController::broadcast(null, $admim, $notif, $content);
        }


        return array('success' => true,
            'detail' => '');
    }

    public function savetranslateAction($id)
    {

        extract($_POST);

        $file = fopen(ROOT . "data/chaptertranslate/" . $id . ".json", "w");
        fputs($file, $datajson);

        fclose($file);

        return array('success' => true,
            'detail' => '');

    }

    public function starttranslateAction($id)
    {

        $chaptertranslate = Chaptertranslate::find($id);
        $chaptertranslate->setStatus("pr");
        $chaptertranslate->setDate_start(new DateTime());
        $chaptertranslate->user = userapp();

        $chaptertranslate->__update();

        //todo : create notification for the administrator: user.pseudo have started the translate of chapter.title

        $chapter = $chaptertranslate->chapter;
        $alternatif = $chapter->comicbook->__get("alternatif");
        $notif = new Notification();
        $notif->setCreationdate(new DateTime());
        $notif->setEntity(Chaptertranslate::class);
        $notif->setEntityid($id);
        //$notif->setUrl($idcc);
        $notif->setContent($alternatif . " "
            . gettranslation("title.chapter") . " "
            . $chapter->getNumber() . " ");
        $notif->__insert();

        //todo create notification then user_notification for user
        $admims = Dvups_admin::allrows();
        foreach ($admims as $admim) {
            $content = $chaptertranslate->user->getPseudo()
                . gettranslation("notif.startedtranslateof") . ' ' . $alternatif . " "
                . gettranslation("title.chapter") . " "
                . $chapter->getNumber() . " ";

            NotificationbroadcastedController::broadcast(null, $admim, $notif, $content);
        }

        return array('success' => true,
            'tablerow' => Datatable::getSingleRowRest($chaptertranslate),
            'detail' => '');

    }


    public static function renderFormWidget($id = null)
    {
        if ($id)
            ChaptertranslateForm::__renderFormWidget(Chaptertranslate::find($id), 'update');
        else
            ChaptertranslateForm::__renderFormWidget(new Chaptertranslate(), 'create');
    }

    public static function renderDetail($id)
    {
        ChaptertranslateForm::__renderDetailWidget(Chaptertranslate::find($id));
    }

    public static function renderForm($id = null, $action = "create")
    {
        $chaptertranslate = new Chaptertranslate();
        if ($id) {
            $action = "update&id=" . $id;
            $chaptertranslate = Chaptertranslate::find($id);
            //$chaptertranslate->collectStorage();
        }

        return ['success' => true,
            'form' => ChaptertranslateForm::__renderForm($chaptertranslate, $action, true),
        ];
    }

    public function datatable($next, $per_page)
    {
        $lazyloading = $this->lazyloading(new Chaptertranslate(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10, $userid = null)
    {
        $qb = null;
        if ($userid) {
            $qb = Chaptertranslate::select()->where(new User($userid));//->andwhere("this.status", "!=", "draft");
        }
        $lazyloading = $this->lazyloading(new Chaptertranslate(), $next, $per_page, $qb, "this.id desc");

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }

    public function showAction($id)
    {

        $chaptertranslate = Chaptertranslate::find($id);
        $chaptertranslatejson = file_get_contents(ROOT . "data/chaptertranslate/" . $id . ".json");

        return array('success' => true,
            'chaptertranslate' => $chaptertranslate,
            'chaptertranslatejson' => $chaptertranslatejson,
            'detail' => 'detail de l\'action.');

    }

    public function createAction($chaptertranslate_form = null)
    {
        extract($_POST);

        $chaptertranslate = $this->form_fillingentity(new Chaptertranslate(), $chaptertranslate_form);


        if ($this->error) {
            return array('success' => false,
                'chaptertranslate' => $chaptertranslate,
                'action_form' => 'create',
                'error' => $this->error);
        }

        $id = $chaptertranslate->__insert();
        return array('success' => true,
            'chaptertranslate' => $chaptertranslate,
            'tablerow' => Datatable::getSingleRowRest($chaptertranslate),
            'detail' => '');

    }

    public function updateAction($id, $chaptertranslate_form = null)
    {
        extract($_POST);

        $chaptertranslate = $this->form_fillingentity(new Chaptertranslate($id), $chaptertranslate_form);


        if ($this->error) {
            return array('success' => false,
                'chaptertranslate' => $chaptertranslate,
                'action_form' => 'update&id=' . $id,
                'error' => $this->error);
        }

        $chaptertranslate->__update();
        return array('success' => true,
            'chaptertranslate' => $chaptertranslate,
            'tablerow' => Datatable::getSingleRowRest($chaptertranslate),
            'detail' => '');

    }

    public function deleteAction($id)
    {

        Chaptertranslate::delete($id);
        return array('success' => true, // pour le restservice
            'redirect' => 'index', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }


    public function deletegroupAction($ids)
    {

        Chaptertranslate::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
            'redirect' => 'index', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction()
    {

        return array('success' => true, // pour le restservice
            'chaptertranslate' => new Chaptertranslate(),
            'action_form' => 'create', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id)
    {

        $chaptertranslate = Chaptertranslate::find($id);

        return array('success' => true, // pour le restservice
            'chaptertranslate' => $chaptertranslate,
            'action_form' => 'update&id=' . $id, // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
