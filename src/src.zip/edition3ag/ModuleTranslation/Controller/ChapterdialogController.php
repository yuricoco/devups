<?php 


use DClass\devups\Datatable as Datatable;

class ChapterdialogController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            ChapterdialogForm::__renderFormWidget(Chapterdialog::find($id), 'update');
        else
            ChapterdialogForm::__renderFormWidget(new Chapterdialog(), 'create');
    }

    public static function renderDetail($id) {
        ChapterdialogForm::__renderDetailWidget(Chapterdialog::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $chapterdialog = new Chapterdialog();
        if($id){
            $action = "update&id=".$id;
            $chapterdialog = Chapterdialog::find($id);
            //$chapterdialog->collectStorage();
        }

        return ['success' => true,
            'form' => ChapterdialogForm::__renderForm($chapterdialog, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Chapterdialog(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Chapterdialog(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $chapterdialog = Chapterdialog::find($id);

            return array( 'success' => true, 
                            'chapterdialog' => $chapterdialog,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($chapterdialog_form = null){
        extract($_POST);

        $chapterdialog = $this->form_fillingentity(new Chapterdialog(), $chapterdialog_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'chapterdialog' => $chapterdialog,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $chapterdialog->__insert();
        return 	array(	'success' => true,
                        'chapterdialog' => $chapterdialog,
                        'tablerow' => Datatable::getSingleRowRest($chapterdialog),
                        'detail' => '');

    }

    public function updateAction($id, $chapterdialog_form = null){
        extract($_POST);
            
        $chapterdialog = $this->form_fillingentity(new Chapterdialog($id), $chapterdialog_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'chapterdialog' => $chapterdialog,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $chapterdialog->__update();
        return 	array(	'success' => true,
                        'chapterdialog' => $chapterdialog,
                        'tablerow' => Datatable::getSingleRowRest($chapterdialog),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Chapterdialog::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Chapterdialog::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'chapterdialog' => new Chapterdialog(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $chapterdialog = Chapterdialog::find($id);

        return array('success' => true, // pour le restservice
                        'chapterdialog' => $chapterdialog,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
