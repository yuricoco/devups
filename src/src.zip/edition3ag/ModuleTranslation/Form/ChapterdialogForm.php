<?php 

    class ChapterdialogForm extends FormManager{

        public static function formBuilder(\Chapterdialog $chapterdialog, $action = null, $button = false) {
            $entitycore = new Core($chapterdialog);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['checked_at'] = [
                "label" => 'Checked_at', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_DATE, 
                "value" => $chapterdialog->getChecked_at(), 
            ];

            $entitycore->field['status'] = [
                "label" => 'Status', 
			"type" => FORMTYPE_TEXT, 
                "value" => $chapterdialog->getStatus(), 
            ];

            $entitycore->field['nbwords'] = [
                "label" => 'Nbwords', 
			"type" => FORMTYPE_TEXT, 
                "value" => $chapterdialog->getNbwords(), 
            ];

            $entitycore->field['started_at'] = [
                "label" => 'Started_at', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_DATE, 
                "value" => $chapterdialog->getStarted_at(), 
            ];

                $entitycore->field['abonne'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $chapterdialog->getAbonne()->getId(),
                    "label" => 'Abonne',
                    "options" => FormManager::Options_Helper('id', Abonne::allrows()),
                ];

                $entitycore->field['chapter'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $chapterdialog->getChapter()->getId(),
                    "label" => 'Chapter',
                    "options" => FormManager::Options_Helper('id', Chapter::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/chapterdialogForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Chapterdialog $chapterdialog, $action = null, $button = false) {
            return FormFactory::__renderForm(ChapterdialogForm::formBuilder($chapterdialog, $action, $button));
        }
        
        public static function __renderFormWidget(\Chapterdialog $chapterdialog, $action_form = null) {
            include ROOT.Chapterdialog::classpath()."Form/ChapterdialogFormWidget.php";
        }

        public static function __renderDetailWidget(\Chapterdialog $chapterdialog){
            include ROOT . Chapterdialog::classpath() . "Form/ChapterdialogDetailWidget.php";
        }
    }
    