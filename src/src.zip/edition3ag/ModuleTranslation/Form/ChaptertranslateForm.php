<?php

class ChaptertranslateForm extends FormManager
{

    public static function formBuilder(\Chaptertranslate $chaptertranslate, $action = null, $button = false)
    {
        $entitycore = new Core($chaptertranslate);

        $entitycore->formaction = $action;
        $entitycore->formbutton = $button;

        //$entitycore->addcss('csspath');


        $entitycore->field['user'] = [
            "label" => 'User',
            FH_REQUIRE => false,
            "type" => FORMTYPE_SELECT,
            "value" => $chaptertranslate->user->getId(),
            "options" => FormManager::Options_Helper("pseudo", User::select()
                ->where("istranslator", 1)->__getAllRow()),
        ];

        $entitycore->field['lang'] = [
            "label" => 'Lang',
            FH_REQUIRE => false,
            "type" => FORMTYPE_TEXT,
            "value" => $chaptertranslate->getLang(),
        ];

        $entitycore->field['status'] = [
            "label" => 'Status',
            "type" => FORMTYPE_TEXT,
            "value" => $chaptertranslate->getStatus(),
        ];

//        $entitycore->field['nbwords'] = [
//            "label" => 'Number of words',
//            "type" => FORMTYPE_TEXT,
//            "value" => $chaptertranslate->getNbwords(),
//        ];

        $entitycore->field['status'] = [
            "label" => 'Status',
            "type" => FORMTYPE_RADIO,
            "value" => $chaptertranslate->getStatus(),
            "options" => Chaptertranslate::$STATUSS,
        ];


        $entitycore->addDformjs($action);
//            $entitycore->addjs('Ressource/js/chaptertranslateForm.js');

        return $entitycore;
    }

    public static function __renderForm(\Chaptertranslate $chaptertranslate, $action = null, $button = false)
    {
        return FormFactory::__renderForm(ChaptertranslateForm::formBuilder($chaptertranslate, $action, $button));
    }

    public static function __renderFormWidget(\Chaptertranslate $chaptertranslate, $action_form = null)
    {
        include ROOT . Chaptertranslate::classpath() . "Form/ChaptertranslateFormWidget.php";
    }

    public static function __renderDetailWidget(\Chaptertranslate $chaptertranslate)
    {
        include ROOT . Chaptertranslate::classpath() . "Form/ChaptertranslateDetailWidget.php";
    }
}
    