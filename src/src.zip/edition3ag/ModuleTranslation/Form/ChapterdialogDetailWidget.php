
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($chapterdialog, [
['label' => 'Checked_at', 'value' => 'checked_at'], 
['label' => 'Status', 'value' => 'status'], 
['label' => 'Nbwords', 'value' => 'nbwords'], 
['label' => 'Started_at', 'value' => 'started_at'], 
['label' => 'Abonne', 'value' => 'Abonne.id'], 
['label' => 'Chapter', 'value' => 'Chapter.id']
]); ?>

        </div>
			