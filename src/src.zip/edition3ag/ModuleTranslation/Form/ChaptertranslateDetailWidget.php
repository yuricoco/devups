
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($chaptertranslate, [
['label' => 'Date_start', 'value' => 'date_start'], 
['label' => 'Date_end', 'value' => 'date_end'], 
['label' => 'Lang', 'value' => 'lang'], 
['label' => 'Status', 'value' => 'status'], 
['label' => 'Chapterdialog', 'value' => 'Chapterdialog.id'], 
['label' => 'Abonne', 'value' => 'Abonne.id']
]); ?>

        </div>
			