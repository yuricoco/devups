//chaptertranslateCtrl

model.validatetranslate = function(id_chapd, $this){

    if(!confirm('This action will alert the administrator that you have finished the work, for him to validate. therefore you wouldn\'t be able to work on it anymore . \nAre you sure you want to proceed?')) return false;

    $($this).html(" ... ")

    $.get('services.php?path=chaptertranslate.validatetranslate&id='+id_chapd, function (response) {
        console.log(response);
        $($this).html(" ok ")
        $("#dv_table").find("#"+id).replaceWith(response.tablerow);
    });
}

model.resettranslatedata = function(id_chapd, $this){

    if(!confirm('This action will drop all information. \nAre you sure you want to proceed?')) return false;

    $($this).html(" ... ")

    $.get('services.php?path=chaptertranslate.resettranslatedata&id='+id_chapd, function (response) {
        console.log(response);
        $($this).html(" ok ")
        alert("Reseted")
    });
}


model._show = function (id) {

    this.baseurl = __env+"routings.php";

    $.get(this.baseurl+"?path=checkingform&id="+id, function (response) {
        databinding.bindmodal(response);
    });

}
