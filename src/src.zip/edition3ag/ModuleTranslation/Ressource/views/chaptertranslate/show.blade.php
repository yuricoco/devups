@extends('layout')
@section('title', 'Show')


@section('content')

    <link rel="stylesheet" href="<?= __env ?>web/css/checkingform.css">

    <div class="row">
        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li class="active">
                    <i class="fa fa-dashboard"></i> <?php echo CHEMINMODULE; ?> > Detail
                </li>
            </ol>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-3 ">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-12 ">
                                    <h5>Detail Chaptertranslate</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" col-md-offset-6 col-lg-3">
                    <?php if($chaptertranslate->getStatus() == "fi"){ ?>
                    <button class="btn btn-success" onclick="action.validate(<?= $_GET["id"] ?>)"><?= gettranslation("button.validate") ?></button>
                    <?php } ?>
                    <a href="index.php?path=chaptertranslate/index" target="_self" class="btn btn-default"><i class="fa fa-list"></i> Listing</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-lg-12 col-md-12">


            <div class="col-lg-3">
                <div id="sortable" >

                </div>
                <div id="dialogzone" >

                    <div class="">
                        <ul id="listbubble" class="">
                        </ul>
                    </div>

                    <div class="form-group">
                        <label class="btn btn-info btn-block " >Dialogue
                            <span id="titlepage" ></span>
                            <i class="fa fa-arrows-alt pull-right" ></i></label>
                        <textarea id="bubbletext" name="bubbletext" class="form-control" size='40' ></textarea>
                    </div>
                    <!--div class="form-group text-center">
                        <button id="addbtn" onclick="action.add()" type="submit" class="btn btn-default"><?= gettranslation("button.save") ?></button>
                        <button id="updatebtn" onclick="action.update()" type="submit" hidden class="btn btn-default"><?= gettranslation("button.update") ?></button>
                        <button onclick="action.cancel()" type="submit" class="btn btn-default" ><?= gettranslation("button.cancel") ?></button>
                    </div-->
                </div>

            </div>
            <div class="col-lg-9 col-md-12">

                <div id="pagecontainer" ></div>
            </div>

        </div>

    </div>

    <script>

        var chapterdialog = <?= json_encode($chaptertranslate) ?>;
        var datajson = <?= $chaptertranslatejson ?>;
        var chapter = chapterdialog.chapter;
        var pages = chapter.pages;
        var user = <?= json_encode(userapp()) ?>;
        console.log(datajson);

    </script>

@endsection

<?php function script(){ ?>

<script src="<?= CLASSJS ?>model.js"></script>
<script>
    model.entity = "chaptertranslate";
</script>
<script src="{{__env}}web/js/konva.min.js"></script>
<script src="<?= __env ?>web/js/dialogueCtrl.js"></script>

<?php } ?>