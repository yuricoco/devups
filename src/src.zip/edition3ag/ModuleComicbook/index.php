<?php
//ModuleComicbook

require '../../../admin/header.php';

global $views;
$views = __DIR__ . '/Ressource/views';


define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleComicbook</a> ');


$comicbookCtrl = new ComicbookController();
$chapterCtrl = new ChapterController();
$genderCtrl = new GenderController();
$chaptercheckingCtrl = new ChaptercheckingController();

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;

    case 'comicbook/index':
        Genesis::renderView('comicbook.index', $comicbookCtrl->listAction());
        break;
    case 'comicbook/create':
        Genesis::renderView('comicbook.form', $comicbookCtrl->createAction(), true);
        break;
    case 'comicbook/update':
        Genesis::renderView('comicbook.form', $comicbookCtrl->updateAction($_GET['id']), true);
        break;


    case 'chapterchecking/_show':
        Genesis::renderView('chapterchecking.show', $chaptercheckingCtrl->showAction($_GET['id']));
        break;
    case 'chapterchecking/index':
        Genesis::renderView('chapterchecking.index', $chaptercheckingCtrl->listAction());
        break;
    case 'chapterchecking/create':
        Genesis::renderView('chapterchecking.form', $chaptercheckingCtrl->createAction(), true);
        break;
    case 'chapterchecking/update':
        Genesis::renderView('chapterchecking.form', $chaptercheckingCtrl->updateAction($_GET['id']), true);
        break;

    case 'chapter/index':
        Genesis::renderView('chapter.index', $chapterCtrl->listAction());
        break;
    case 'chapter/create':
        Genesis::renderView('chapter.form', $chapterCtrl->createAction(), true);
        break;
    case 'chapter/update':
        Genesis::renderView('chapter.form', $chapterCtrl->updateAction($_GET['id']), true);
        break;


    case 'gender/index':
        Genesis::renderView('gender.index', $genderCtrl->listAction());
        break;
    case 'gender/create':
        Genesis::renderView('gender.form', $genderCtrl->createAction(), true);
        break;
    case 'gender/update':
        Genesis::renderView('gender.form', $genderCtrl->updateAction($_GET['id']), true);
        break;


    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    