
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($comicbook, [
['label' => 'Name', 'value' => 'name'], 
['label' => 'Alternatif', 'value' => 'alternatif'], 
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Readingdirection', 'value' => 'readingdirection'], 
['label' => 'Synopsis', 'value' => 'synopsis'], 
['label' => 'Banner', 'value' => 'banner'], 
['label' => 'Logo', 'value' => 'logo'], 
['label' => 'Imgclassement', 'value' => 'imgclassement'], 
['label' => 'Pteimage', 'value' => 'pteimage'], 
['label' => 'Ischronic', 'value' => 'ischronic'], 
['label' => 'Path', 'value' => 'path']
]); ?>

        </div>
			