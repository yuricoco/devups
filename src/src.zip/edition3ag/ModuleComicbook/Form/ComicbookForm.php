<?php

class ComicbookForm extends FormManager
{

    public static function formBuilder(\Comicbook $comicbook, $action = null, $button = false)
    {
        $entitycore = new Core($comicbook);

        $entitycore->formaction = $action;
        $entitycore->formbutton = $button;

        //$entitycore->addcss('csspath');


        $entitycore->field['name'] = [
            "label" => 'Name',
            "type" => FORMTYPE_TEXT,
            "value" => $comicbook->getName(),
        ];

        $entitycore->field['nameseo'] = [
            "label" => 'Name S.E.O',
            "type" => FORMTYPE_TEXT,
            "value" => $comicbook->getNameseo(),
        ];

        $entitycore->field['alternatif'] = [
            "label" => 'Alternatif',
            "type" => FORMTYPE_TEXT,
            "value" => $comicbook->getAlternatif(),
        ];

        $entitycore->field['readingdirection'] = [
            "label" => 'Readingdirection',
            "type" => FORMTYPE_RADIO,
            "value" => $comicbook->getReadingdirection(),
            "options" => ["left to right", "right to left"],
        ];

        $entitycore->field['synopsis'] = [
            "label" => 'Synopsis',
            "type" => FORMTYPE_TEXTAREA,
            "value" => $comicbook->getSynopsis(),
        ];

        $entitycore->field['banner'] = [
            "label" => 'Banner',
            "type" => FORMTYPE_FILE,
            "value" => $comicbook->getBanner(),
        ];

        $entitycore->field['logo'] = [
            "label" => 'Logo',
            "type" => FORMTYPE_FILE,
            "value" => $comicbook->getLogo(),
        ];

        $entitycore->field['ischronic'] = [
            "label" => 'Ischronic',
            "type" => FORMTYPE_RADIO,
            "value" => $comicbook->getIschronic(),
            "options" => ["no", "yes"],
        ];

        $entitycore->field['status'] = [
            "label" => 'Status',
            "type" => FORMTYPE_RADIO,
            "value" => $comicbook->getIschronic(),
            "options" => Comicbook::$STATUS,
        ];

        $entitycore->field['gender'] = [
            "label" => 'Gender',
            "type" => FORMTYPE_CHECKBOX,
            "values" => FormManager::Options_Helper('name', $comicbook->getGender()),
            "options" => FormManager::Options_ToCollect_Helper('name', new Gender(), $comicbook->getGender()),
        ];

        $entitycore->field['member'] = [
            "label" => 'Member',
            "type" => FORMTYPE_CHECKBOX,
            "values" => FormManager::Options_Helper('firstname', $comicbook->getMember()),
            "options" => FormManager::Options_ToCollect_Helper('firstname', new Member(), $comicbook->getMember()),
        ];

        $entitycore->addDformjs($action);
        $entitycore->addjs('Ressource/js/comicbookForm.js');

        return $entitycore;
    }

    public static function __renderForm(\Comicbook $comicbook, $action = null, $button = false)
    {
        return FormFactory::__renderForm(ComicbookForm::formBuilder($comicbook, $action, $button));
    }

    public static function __renderFormWidget(\Comicbook $comicbook, $action_form = null)
    {
        include ROOT . Comicbook::classpath() . "Form/ComicbookFormWidget.php";
    }

    public static function __renderDetailWidget(\Comicbook $comicbook)
    {
        include ROOT . Comicbook::classpath() . "Form/ComicbookDetailWidget.php";
    }
}
    