<?php 

    class ChaptercheckingForm extends FormManager{

        public static function formBuilder(\Chapterchecking $chapterchecking, $action = null, $button = false) {
            $entitycore = new Core($chapterchecking);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');

//                $entitycore->field['chapter'] = [
//                    "type" => FORMTYPE_SELECT,
//                    "value" => $chapterchecking->getChapter()->getId(),
//                    "label" => 'Chapter',
//                    "options" => FormManager::Options_Helper('title', Chapter::allrows()),
//                ];

            $entitycore->field['user'] = [
                "label" => 'User',
                FH_REQUIRE => false,
                "type" => FORMTYPE_SELECT,
                "value" => $chapterchecking->user->getId(),
                "options" => FormManager::Options_Helper("pseudo",
                    User::select()->where("ischecker", 1)->__getAllRow()),
            ];

            $entitycore->field['status'] = [
                "label" => 'Status',
                "type" => FORMTYPE_RADIO,
                "value" => $chapterchecking->getStatus(),
                "options" => Chapterchecking::$STATUSS,
            ];
            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/chaptercheckingForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Chapterchecking $chapterchecking, $action = null, $button = false) {
            return FormFactory::__renderForm(ChaptercheckingForm::formBuilder($chapterchecking, $action, $button));
        }
        
        public static function __renderFormWidget(\Chapterchecking $chapterchecking, $action_form = null) {
            include ROOT.Chapterchecking::classpath()."Form/ChaptercheckingFormWidget.php";
        }

        public static function __renderDetailWidget(\Chapterchecking $chapterchecking){
            include ROOT . Chapterchecking::classpath() . "Form/ChaptercheckingDetailWidget.php";
        }
    }
    