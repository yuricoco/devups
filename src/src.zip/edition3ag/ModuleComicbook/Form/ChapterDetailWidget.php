<div class="col-lg-12 col-md-12">

    <?= \DClass\devups\Datatable::renderentitydata($chapter, [
        ['label' => 'Cover', 'value' => 'cover'],
        ['label' => 'Comicbook', 'value' => 'Comicbook.name'],
        ['label' => 'Number', 'value' => 'number'],
        ['label' => 'Title', 'value' => 'title'],
        ['label' => 'Creationdate', 'value' => 'creationdate'],
        ['label' => 'Isnew', 'value' => 'isnew'],
        ['label' => 'Path', 'value' => 'path'],
        ['label' => 'Image', 'value' => 'cover'],
        ['label' => 'Status', 'value' => 'status'],
        ['label' => 'Lang', 'value' => 'lang'],
    ]); ?>

</div>
			