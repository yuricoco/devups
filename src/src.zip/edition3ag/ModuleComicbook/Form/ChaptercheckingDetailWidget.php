
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($chapterchecking, [
['label' => 'Title', 'value' => 'title'], 
['label' => 'Nbpages', 'value' => 'nbpages'], 
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Start_at', 'value' => 'start_at'], 
['label' => 'End_at', 'value' => 'end_at'], 
['label' => 'Status', 'value' => 'status'], 
['label' => 'Validate_at', 'value' => 'validate_at'], 
['label' => 'Chapter', 'value' => 'Chapter.id'], 
['label' => 'User', 'value' => 'User.id'], 
['label' => 'Dvups_admin', 'value' => 'Dvups_admin.id']
]); ?>

        </div>
			