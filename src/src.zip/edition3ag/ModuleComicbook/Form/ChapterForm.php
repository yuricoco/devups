<?php 

    class ChapterForm extends FormManager{

        public static function formBuilder(\Chapter $chapter, $action = null, $button = false) {
            $entitycore = new Core($chapter);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');

            $entitycore->field['comicbook'] = [
                "type" => FORMTYPE_SELECT,
                "value" => $chapter->comicbook->getId(),
                "label" => 'Comicbook',
                "placeholder" => 'Select a Comicbook',
                FH_DIRECTIVE => ["id" => 'comicbook_select'],
                "options" => FormManager::Options_Helper('alternatif', Comicbook::allrows()),
            ];

            $entitycore->field['number'] = [
                "label" => 'Number',
                "type" => FORMTYPE_TEXT,
                "value" => $chapter->getNumber(),
            ];

            $entitycore->field['title'] = [
                "label" => 'Title', 
			"type" => FORMTYPE_TEXT, 
                "value" => $chapter->getTitle(), 
            ];

            $entitycore->field['status'] = [
                "label" => 'Status', 
			"type" => FORMTYPE_RADIO, 
                "value" => $chapter->getStatus(),
                "options" => ["draft", 'publish'],
            ];

            $entitycore->field['lang'] = [
                "label" => 'Lang', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_RADIO,
                "value" => $chapter->getLang(), 
                "options" => ["fr" => "Fr", 'en' => "En"],
            ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/chapterForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Chapter $chapter, $action = null, $button = false) {
            return FormFactory::__renderForm(ChapterForm::formBuilder($chapter, $action, $button));
        }
        
        public static function __renderFormWidget(\Chapter $chapter, $action_form = null) {
            include ROOT.Chapter::classpath()."Form/ChapterFormWidget.php";
        }

        public static function __renderOneshotFormWidget(\Chapter $chapter, $action_form = null) {
            include ROOT.Chapter::classpath()."Form/ChapteroneshotForm.php";
        }

        public static function __renderDetailWidget(\Chapter $chapter){
            include ROOT . Chapter::classpath() . "Form/ChapterDetailWidget.php";
        }
        public static function __renderFormImage(\Chapter $chapter){
            include ROOT . Chapter::classpath() . "Ressource/views/chapter/form_image.blade.php";
        }
    }
    