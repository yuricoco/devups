<?php 

    class GenderForm extends FormManager{

        public static function formBuilder(\Gender $gender, $action = null, $button = false) {
            $entitycore = new Core($gender);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');


            $entitycore->field['name'] = [
                "label" => 'Name',
                "type" => FORMTYPE_TEXT,
                "value" => $gender->getName(),
            ];


            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/genderForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Gender $gender, $action = null, $button = false) {
            return FormFactory::__renderForm(GenderForm::formBuilder($gender, $action, $button));
        }
        
        public static function __renderFormWidget(\Gender $gender, $action_form = null) {
            include ROOT.Gender::classpath()."Form/GenderFormWidget.php";
        }

        public static function __renderDetailWidget(\Gender $gender){
            include ROOT . Gender::classpath() . "Form/GenderDetailWidget.php";
        }
    }
    