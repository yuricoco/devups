<?php //Form::addcss('Ressource/js/chapter.css')
 $comicbooks = Comicbook::allrows();
// ?>

<?= Form::open($chapter, ["action" => "$action_form", "method" => "post"]) ?>

<div class='form-group'>
    <label for='comicbook'>Comicbook</label>

    <?= Form::select('comicbook',
        FormManager::Options_Helper('alternatif',$comicbooks),
        $chapter->comicbook->getId(),
        ["placeholder" => 'Select a Comicbook', "id" => 'comicbook_select', 'class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='number'>Number</label>
    <?= Form::input('number', $chapter->getNumber(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='title'>Title</label>
    <?= Form::input('title', $chapter->getTitle(), ['class' => 'form-control']); ?>
</div>

<div id="chronic" hidden>
    <div class="form-group">
        <label>auteur *</label>
        <input require name='author' value='<?php echo $chapter->getChronic()->author; ?>' type='text' class='form-control' size='40' />
    </div>
    <div class="form-group">
        <label>artiste </label>
        <input  name='artist' value='<?php echo $chapter->getChronic()->artist; ?>' type='text' class='form-control' size='40' />
    </div>
    <div class="form-group">
        <label>apropos </label>
        <textarea  name='about' class='form-control' ><?php echo $chapter->getChronic()->about; ?></textarea>
    </div>
</div>

<div class='form-group'>
    <label for='status'>Status</label>
    <?= Form::radio('status', ["draft", 'publish'], $chapter->getStatus(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='lang'>Lang</label>
    <?= Form::radio('lang', ["fr" => "Fr", 'en' => "En"], $chapter->getLang(), ['class' => 'form-control']); ?>
</div>


<?= Form::submit("save", ['class' => 'btn btn-success']) ?>

<?= Form::close() ?>

<?= Form::addDformjs() ?>
<script>
    var comicbook = <?= json_encode($chapter->getComicbook()); ?>;
    var comicbooks = <?= json_encode($comicbooks); ?>;
</script>
<?= Form::addjs('Ressource/js/chapterForm.js') ?>
    