<?php
/**
 * Created by PhpStorm.
 * User: Aurelien Atemkeng
 * Date: 05/01/2019
 * Time: 11:40 PM
 */

//namespace edition3ag\ModuleComicbook\Entity;

/**
 * @Entity @Table(name="comicbook_member")
 * */
class Comicbook_member extends \Model
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    private $id;

    /**
     * @ManyToOne(targetEntity="\Comicbook")
     * , inversedBy="reporter"
     * @var \Comicbook
     */
    public $comicbook;

    /**
     * @ManyToOne(targetEntity="\Member")
     * , inversedBy="reporter"
     * @var \Member
     */
    public $member;

    public function __construct($id = null){

        if( $id ) { $this->id = $id; }

        $this->comicbook = new \Comicbook();
        $this->member = new \Member();
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return \Comicbook
     */
    public function getComicbook()
    {
        return $this->comicbook;
    }

    /**
     * @param \Comicbook $comicbook
     */
    public function setComicbook($comicbook)
    {
        $this->comicbook = $comicbook;
    }

    /**
     * @return \Member
     */
    public function getMember()
    {
        return $this->member;
    }

    /**
     * @param \Member $member
     */
    public function setMember($member)
    {
        $this->member = $member;
    }

}