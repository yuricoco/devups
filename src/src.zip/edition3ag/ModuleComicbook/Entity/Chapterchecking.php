<?php

/**
 * @Entity @Table(name="chapterchecking")
 * */
class Chapterchecking extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="nbpages", type="integer"  )
     * @var integer
     **/
    private $nbpages;
    /**
     * @Column(name="creationdate", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $creationdate;
    /**
     * @Column(name="started_at", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $started_at;
    /**
     * @Column(name="ended_at", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $ended_at;
    /**
     **/
    public static $STATUSS = ['dr' => 'draft', 'pr' => 'in process', 'pe' => 'in pending', 'fi' => 'finish', 'va' => 'validated', 'ca' => 'canceled'];
    /**
     * @Column(name="status", type="string", length=2  )
     * @var integer
     **/
    private $status = "pe";
    /**
     * @Column(name="validated_at", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $validated_at;

    /**
     * @ManyToOne(targetEntity="\Chapter")
     * , inversedBy="reporter"
     * @var \Chapter
     */
    public $chapter;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    public $user;

    /**
     * @ManyToOne(targetEntity="\Dvups_admin")
     * , inversedBy="reporter"
     * @var \Dvups_admin
     */
    public $dvups_admin;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->chapter = new Chapter();
        $this->user = new User();
        $this->dvups_admin = new Dvups_admin();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getNbpages()
    {
        return $this->nbpages;
    }

    public function setNbpages($nbpages)
    {
        $this->nbpages = $nbpages;
    }


    public function getCreationdate()
    {
        if (is_object($this->creationdate))
            return $this->creationdate;
        else
            return new DateTime($this->creationdate);
    }

    public function setCreationdate($creationdate)
    {
        if (is_object($creationdate))
            $this->creationdate = $creationdate;
        else
            $this->creationdate = new DateTime($creationdate);
    }

    public function getStarted_at()
    {
        if (is_object($this->started_at))
            return $this->started_at;
        else
            return new DateTime($this->started_at);
    }

    public function setStarted_at($started_at)
    {
        if (is_object($started_at))
            $this->started_at = $started_at;
        else
            $this->started_at = new DateTime($started_at);
    }

    public function getEnded_at()
    {
        if (is_object($this->ended_at))
            return $this->ended_at;
        else
            return new DateTime($this->ended_at);
    }

    public function setEnded_at($ended_at)
    {
        if (is_object($ended_at))
            $this->ended_at = $ended_at;
        else
            $this->ended_at = new DateTime($ended_at);
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($status)
    {
        $this->status = $status;
    }

    public static function statusSearch($inputname)
    {
        return "<select name='$inputname' class='form-control' >
<option value=''>All</option>
<option value='pe'>In pending</option>
</select>";
    }


    public function getValidated_at()
    {
        if (is_object($this->validated_at))
            return $this->validated_at;
        else
            return new DateTime($this->validated_at);
    }

    public function setValidated_at($validated_at)
    {
        if (is_object($validated_at))
            $this->validated_at = $validated_at;
        else
            $this->validated_at = new DateTime($validated_at);
    }

    /**
     *  manyToOne
     * @return \Chapter
     */
    function getChapter()
    {
        $this->chapter = $this->chapter->__show();
        return $this->chapter;
    }

    function setChapter(\Chapter $chapter)
    {
        $this->chapter = $chapter;
    }

    /**
     *  manyToOne
     * @return \User
     */
    function getUser()
    {
        $this->user = $this->user->__show();
        return $this->user;
    }

    function setUser(\User $user)
    {
        $this->user = $user;
    }

    /**
     *  manyToOne
     * @return \Dvups_admin
     */
    function getDvups_admin()
    {
        $this->dvups_admin = $this->dvups_admin->__show();
        return $this->dvups_admin;
    }

    function setDvups_admin(\Dvups_admin $dvups_admin)
    {
        $this->dvups_admin = $dvups_admin;
    }


    function validatecheckingAction()
    {
        $action = "";
        if ($this->status == "fi")
            return '<span onclick="model.validatechecking(' . $this->getId() . ', this)" class="btn btn-info btn-sm">Validate checking</span>';

        if ($this->status == "dr")
            $action .= '<span  onclick="model.resetcheckingdata(' . $this->getId() . ', this)" class="btn btn-warning btn-sm">Reset</span>';

        if ($this->status != "va")
            return $action.'<span class="btn btn-deficit btn-sm">Cancel</span>';

        return "";
    }

    function editAction (){
        return '<span data-toggle="modal" data-target="#chaptercheckingmodal" onclick="model._edit('.$this->getId().')" class="btn btn-primary btn-sm">Edit</span>' ;
    }

    function startcheckingAction()
    {
        if ($this->status == "pe")
            return '<span onclick="model.startchecking(' . $this->getId() . ', this)" class="btn btn-deficit btn-sm">Start checking</span>';

        if($this->user->getId() == $_SESSION[USERID]){
            if ($this->status == "pr" )
                return '<span onclick="model.bindview(' . $this->getId() . ', this)" class="btn btn-warning btn-sm">Continue</span>';
            elseif($this->status == "fi" || $this->status == "va")
                return '<span onclick="model.bindview(' . $this->getId() . ', this)" class="btn btn-info btn-sm">Voir</span>';
        }

        return "";
    }

    public function getIconestatus()
    {
        if ($this->status == "pe") // draft
            return "<span class='btn btn-deficit'><i class='fa fa-check'></i> " . gettranslation('status.inpending') . "</span>";
        elseif ($this->status == "pr") // publish
            return "<span class='btn btn-success'><i class='fa fa-check'></i> " . gettranslation('status.inprocess') . "</span>";
        elseif ($this->status == "fi") // checking validate
            return "<span class='btn btn-info'> " . gettranslation('status.finished') . "</span> ";
        elseif ($this->status == "va") // checking validate
            return "<span class='btn btn-success'> " . gettranslation('status.validated') . "</span> ";
        else
            return "<span class='btn btn-info'>en attente</span>";
    }

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'nbpages' => $this->nbpages,
            'creationdate' => $this->creationdate,
            'started_at' => $this->started_at,
            'ended_at' => $this->ended_at,
            'status' => $this->status,
            'validated_at' => $this->validated_at,
            'chapter' => $this->chapter,
            'user' => $this->user,
            'dvups_admin' => $this->dvups_admin,
        ];
    }

}
