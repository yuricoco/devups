<?php 
    /**
     * @Entity @Table(name="gender")
     * */
    class Gender extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;

        /**
         * @Column(name="name", type="string" , length=55 )
         * @var string
         **/
        private $name;
        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
}

        public function getId() {
            return $this->id;
        }

        /**
         * @return string
         */
        public function getName()
        {
            return $this->name;
        }

        /**
         * @param string $name
         */
        public function setName($name)
        {
            $this->name = $name;
        }
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                ];
        }
        
}
