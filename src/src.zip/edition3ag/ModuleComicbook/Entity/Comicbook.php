<?php

/**
 * @Entity @Table(name="comicbook")
 * */
class Comicbook extends \Model implements JsonSerializable
{

    public static $STATUS = ["process", "end", "suspended"];
    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="name", type="string" , length=55 )
     * @var string
     **/
    private $name;
    /**
     * @Column(name="nameseo", type="string" , length=55 )
     * @var string
     **/
    private $nameseo;
    /**
     * @Column(name="alternatif", type="string" , length=25 )
     * @var string
     **/
    private $alternatif;
    /**
     * @Column(name="creationdate", type="date"  )
     * @var date
     **/
    private $creationdate;
    /**
     * @Column(name="status", type="boolean"  )
     * @var boolean
     **/
    private $status = 0;
    /**
     * @Column(name="readingdirection", type="boolean"  )
     * @var boolean
     **/
    private $readingdirection = 0;
    /**
     * @Column(name="synopsis", type="text"  )
     * @var text
     **/
    private $synopsis;
    /**
     * @Column(name="banner", type="string" , length=55 , nullable=true)
     * @var string
     **/
    private $banner;
    /**
     * @Column(name="logo", type="string" , length=55 , nullable=true)
     * @var string
     **/
    private $logo;
    /**
     * @Column(name="imgclassement", type="string" , length=50 , nullable=true)
     * @var string
     **/
    private $imgclassement;
    /**
     * @Column(name="pteimage", type="string" , length=50 , nullable=true)
     * @var string
     **/
    private $pteimage;
    /**
     * @Column(name="ischronic", type="boolean"  )
     * @var boolean
     **/
    private $ischronic = 0;
    /**
     * @Column(name="path", type="string" , length=120 , nullable=true)
     * @var string
     **/
    private $path;

    public $gender;
    public $member;

    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->gender = EntityCollection::entity_collection('gender');
        $this->member = EntityCollection::entity_collection('member');

    }

    public function getId()
    {
        return $this->id;
    }

    /**
     * @return bool
     */
    public function isStatus()
    {
        return $this->status;
    }

    /**
     * @param bool $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    public function getNameseo()
    {
        return $this->nameseo;

        //return url_format($this->name);
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function setNameseo($name)
    {
        if(!$name)
            $name = $this->name;

        $str = htmlentities($name, ENT_NOQUOTES, 'utf-8');

        $str = preg_replace('#&([A-za-z])(?:acute|cedil|caron|circ|grave|orn|ring|slash|th|tilde|uml);#', '\1', $str);
        $str = preg_replace('#&([A-za-z]{2})(?:lig);#', '\1', $str); // pour les ligatures e.g. '&oelig;'
        $str = preg_replace('#&[^;]+;#', '', $str); // supprime les autres caractères
        $nameseo = str_replace(' ', '-', $str); // supprime les autres caractères

        $this->nameseo = $nameseo;
        //$this->nameseo = clean(remove_accents($name));
    }

    /**
     * @return string
     */
    public function getNamecanonical()
    {
        return $this->nameseo;
    }

    public function getAlternatif()
    {
        return $this->alternatif;
    }

    public function setAlternatif($alternatif)
    {
        $this->alternatif = $alternatif;
    }


    public function getCreationdate()
    {
        return $this->creationdate;
    }

    public function getDate()
    {
        if(is_object($this->creationdate))
            return $this->creationdate;
        else
            return new DateTime($this->creationdate);
    }

    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    public function getReadingdirection()
    {
        return $this->readingdirection;
    }

    public function setReadingdirection($readingdirection)
    {
        $this->readingdirection = $readingdirection;
    }

    public function getSynopsis()
    {
        return $this->synopsis;
    }

    public function setSynopsis($synopsis)
    {
        $this->synopsis = $synopsis;
    }

    public function getBanner()
    {
        return $this->banner;
    }

    public function showBanner()
    {
        return Dfile::show("banner.jpg", $this->path);
    }

    public function getBannerimage()
    {
        $url = Dfile::show("banner.jpg", $this->path);
        return Dfile::fileadapter($url, "banner.jpg");
    }

    public function setBanner($banner)
    {
        $this->banner = $banner;
    }

    public function getLogo()
    {
        return $this->logo;
    }

    public function showLogo()
    {
        return Dfile::show("logo.png", $this->path);
    }

    public function getLogoimage()
    {
        $url = Dfile::show("logo.png", $this->path);
        return Dfile::fileadapter($url, "logo.png");
    }

    public function setLogo($logo)
    {
        $this->logo = $logo;
    }

    public function getImgclassement()
    {
        return $this->imgclassement;
    }

    public function setImgclassement($imgclassement)
    {
        $this->imgclassement = $imgclassement;
    }

    public function getPteimage()
    {
        return $this->pteimage;
    }

    public function setPteimage($pteimage)
    {
        $this->pteimage = $pteimage;
    }

    public function getIschronic()
    {
        return $this->ischronic;
    }

    public function setIschronic($ischronic)
    {
        $this->ischronic = $ischronic;
    }

    public function getPath()
    {
        return $this->path;
    }

    public function setPath($path)
    {
        $this->path = $path;
    }

    /**
     * @return mixed
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * @param mixed $gender
     */
    public function setGender($gender)
    {
        $this->gender = $gender;
    }

    /**
     * @return array
     */
    public function getMember()
    {
        return $this->member;
    }

    /**
     * @param array $member
     */
    public function setMember($member)
    {
        $this->member = $member;
    }

    function collectGender(){
        $this->gender = $this->__hasmany('gender');
        return $this->gender;
    }

    function collectMember(){
        $this->member = $this->__hasmany('member');
        return $this->member;
    }

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'alternatif' => $this->alternatif,
            'creationdate' => $this->creationdate,
            'readingdirection' => $this->readingdirection,
            'synopsis' => $this->synopsis,
            'banner' => $this->banner,
            'logo' => $this->logo,
            'imgclassement' => $this->imgclassement,
            'pteimage' => $this->pteimage,
            'ischronic' => (bool) $this->ischronic,
            'path' => $this->path,
        ];
    }

}
