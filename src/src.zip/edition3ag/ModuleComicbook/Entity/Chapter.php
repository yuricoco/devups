<?php

/**
 * @Entity @Table(name="chapter")
 * */
class Chapter extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="chronic", type="text" , nullable=true )
     * @var string
     **/
    private $chronic;
    /**
     * @Column(name="title", type="string" , length=255 )
     * @var string
     **/
    private $title;
    /**
     * @Column(name="number", type="integer"  )
     * @var integer
     **/
    private $number;
    /**
     * @Column(name="creationdate", type="datetime"  , nullable=true)
     * @var datetime
     **/
    private $creationdate;
    /**
     * @Column(name="images", type="text"  , nullable=true)
     * @var text
     **/
    private $images;
    /**
     * @Column(name="isnew", type="boolean" , nullable=true)
     * @var text
     **/
    private $isnew = 1;
    /**
     * @Column(name="status", type="integer"  )
     * @var boolean
     **/
    private $status = 0;

    /**
     * @Column(name="lang", type="string" , length=2 , nullable=true)
     * @var string
     **/
    private $lang = "fr";
    /**
     * @Column(name="intranslation", type="boolean"  )
     * @var boolean
     **/
    private $intranslation = 0;
    /**
     * @Column(name="translated", type="boolean"  )
     * @var boolean
     **/
    private $translated = 0;
    /**
     * @Column(name="tranlatedto", type="string" , length=2 , nullable=true)
     * @var string
     **/
    private $tranlatedto;
    /**
     * @Column(name="path", type="string" , length=120 , nullable=true)
     * @var string
     **/
    private $path;
    /**
     * @Column(name="cover", type="string" , length=255 , nullable=true)
     * @var string
     **/
    private $cover;
    /**
     * @Column(name="cacheimage", type="string" , length=6 , nullable=true)
     * @var string
     **/
    private $cacheimage;

    /**
     * @ManyToOne(targetEntity="\Comicbook")
     * , inversedBy="reporter"
     * @var \Comicbook
     */
    public $comicbook;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    public $user;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->comicbook = new Comicbook();
        $this->user = new User();
    }

    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getCacheimage()
    {
        return $this->cacheimage;
    }

    /**
     * @param string $cacheimage
     */
    public function setCacheimage($cacheimage)
    {
        $this->cacheimage = $cacheimage;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function getTitleseo()
    {
        return $this->comicbook->getNameseo()."/".$this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    public function getChronic() {

        if ($this->chronic)
            return json_decode($this->chronic);
        else {
//                $this->chronic = "{author: '', artist : '', about: ''}";
            return json_decode('{"author": "", "artist" : "", "about": ""}');
//                return json_decode (json_encode(['author' => "", 'artist' => "", 'about' => ""]));
        }
    }

    public function setChronic($chronic) {
        $this->chronic = $chronic;
    }

    public function getNumber()
    {
        return $this->number;
    }

    public function setNumber($number)
    {
        $this->number = $number;
    }


    public function getCreationdate()
    {
        return $this->creationdate;
    }

    public function getDate()
    {
        if(is_object($this->creationdate))
            return $this->creationdate;
        else
            return new DateTime($this->creationdate);
    }

    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    public function getImages()
    {
        return $this->images;
    }

    public function setImages($images)
    {
        $this->images = $images;
    }

    public function getIsnew()
    {
        return $this->isnew;
    }
    public function getIsnewform()
    {
        $ch_new = '';
        $ch_old = '';

        ($this->isnew == '1') ? $ch_new = 'checked' : $ch_old = 'checked' ;

        return '  <label class="checkbox-inline">  
                  <input ' . $ch_new . ' type="radio" name="' . $this->id . '_nouveau" value="1" class="newer " >
                  yes
                </label> 
                <label class="checkbox-inline">  
                  <input ' . $ch_old . ' type="radio" name="' . $this->id . '_nouveau" value="0" class="newer " >
                  no
                </label> ';
    }

    public function setIsnew($isnew)
    {
        $this->isnew = $isnew;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function getStatusform()
    {
        $ch_publish = '';
        $ch_dust = '';

        ($this->status == '1') ? $ch_publish = 'checked' : $ch_dust = 'checked' ;

        return '  <label class="checkbox-inline">  
                  <input ' . $ch_publish . ' type="radio" name="' . $this->id . '_statu" value="1" class="statuer" >
                  publish
                </label> 
                <label class="checkbox-inline">  
                  <input ' . $ch_dust . ' type="radio" name="' . $this->id . '_statu" value="0" class="statuer" >
                  draft
                </label> ';
    }

    public function setStatus($status)
    {
        $this->status = $status;
    }

    public function getLang()
    {
        return $this->lang;
    }

    public function setLang($lang)
    {
        $this->lang = $lang;
    }

    public function getIntranslation()
    {
        return $this->intranslation;
    }

    public function setIntranslation($intranslation)
    {
        $this->intranslation = $intranslation;
    }

    public function getTranslated()
    {
        return $this->translated;
    }

    public function setTranslated($translated)
    {
        $this->translated = $translated;
    }

    public function getTranlatedto()
    {
        return $this->tranlatedto;
    }

    public function setTranlatedto($tranlatedto)
    {
        $this->tranlatedto = $tranlatedto;
    }

    /**
     * @return User
     */
    public function getUser()
    {
        $this->user = $this->user->__show();
        return $this->user;
    }

    /**
     * @param User $user
     */
    public function setUser($user)
    {
        $this->user = $user;
    }

    public function getPath()
    {
        return $this->path;
    }

    public function setPath($path)
    {
        $this->path = $path;
    }

    public function getCover()
    {
        return $this->cover;
    }

    function getCoverimage() {
        if(file_exists(UPLOAD_DIR. $this->path ."mini/mini_". $this->cover))
            return "<img src='".SRC_FILE . $this->path ."mini/mini_". $this->cover."' >";
        else
            return "<img src='".RESSOURCE2."default/no_image.jpg' >";
    }

    public function showCover() {
        return Dfile::show( "mini/mini_".$this->cover, $this->getPath())."?dummy=".$this->cacheimage;
    }

    public function setCover($cover)
    {
        $this->cover = $cover;
    }

    function getNbpages(){
        $uploaddir = $this->path;
        $dirs = UPLOAD_DIR . $uploaddir;
        if(!is_dir($dirs)){
            return 0;
        }
        $src_pages = scanDir::scan($dirs, ["jpg", "jpeg", "png"]);
        return count($src_pages);
    }

    function getPages(){
        $pages = [];
        $uploaddir = $this->path;
        $dirs = UPLOAD_DIR . $uploaddir;
        if(!is_dir($dirs)){
            return [];
        }
        $src_pages = scanDir::scan($dirs, ["jpg", "jpeg", "png"]);
        for($i = 0; $i < count($src_pages); $i++){
            $cover = false;
            $imagesize = getimagesize($src_pages[$i]);
            $pagearray = explode("chapter/" . $this->id."/", $src_pages[$i]);
            $pagearray[1] = str_replace("\\", "", $pagearray[1]);
            $pagearray[1] = str_replace("/", "", $pagearray[1]);

            if($this->cover == $pagearray[1])
                $cover = true;

            if ($imagesize[0] < $imagesize[1]) {
                $pages[] = ["cover" => $cover, "cache" => $this->cacheimage, "page" => $pagearray[1], "double" => false,
                    "show" => SRC_FILE . $uploaddir . $pagearray[1]."?dummy=".$this->cacheimage,
                    "showmini" => SRC_FILE . $uploaddir . "mini/mini_" . $pagearray[1]."?dummy=".$this->cacheimage
                ];
            }else{
                $pages[] = ["cover" => $cover, "cache" => $this->cacheimage, "page" => $pagearray[1], "double" => true,
                    "show" => SRC_FILE . $uploaddir . $pagearray[1]."?dummy=".$this->cacheimage,
                    "showmini" => SRC_FILE . $uploaddir . "mini/mini_" . $pagearray[1]."?dummy=".$this->cacheimage
                ];
            }
        }

        return $pages;
    }
    
    /**
     *  manyToOne
     * @return \Comicbook
     */
    function getComicbook()
    {
        $this->comicbook = $this->comicbook->__show();
        return $this->comicbook;
    }

    function setComicbook(\Comicbook $comicbook)
    {
        $this->comicbook = $comicbook;
    }

    function uploadimageAction (){
        return '<span data-toggle="modal" data-target="#chaptermodal" onclick="model._editcustom('.$this->getId().')" class="btn btn-primary btn-sm">Images</span>' ;

    }

    function startcheckingAction (){
        if($this->status == 0)
            return '<span onclick="model.startchecking('.$this->getId().', this)" class="btn btn-deficit btn-sm">Start checking</span>' ;

        return "";
    }

    function starttranslationAction (){
        if($this->intranslation == 0 && in_array($this->status, [1, 3]))
            return '<span onclick="model.starttranslation('.$this->getId().', this)" class="btn btn-exceed btn-sm">Start translation</span>' ;

        return "";
    }
    function readdraftAction (){
        return '<a href="'.d_url('read-online', $this->getId().'/1', $this->title).'" target="_blank" class="btn btn-deficit btn-sm">Read</a>' ;
    }
    function getReadlink (){
        return '<a href="'.d_url('read-online', $this->getId().'/1', $this->title).'" target="_blank" class="">'.$this->comicbook->getAlternatif() ." chap/ ".$this->number.'</a>' ;
    }
    function editAction (){
        return '<span onclick="model._edit('.$this->getId().')" data-toggle="modal" data-target="#chaptermodal" class="btn btn-default btn-sm"><i class="fa fa-edit"></i> '.gettranslation("button.edit").'</span>' ;
    }

    public function getIconestatus()
    {
        if ($this->status == 0 ){
            // draft
            if(!$this->user->getId())
                return "<span class='btn btn-deficit'><i class='fa fa-check'></i> Draft</span>";

            return '  <label class="checkbox-inline">  
                  <input type="radio" name="' . $this->id . '_statu" value="4" class="statuer" >
                  publish
                </label> 
                <label class="checkbox-inline">  
                  <input checked type="radio" name="' . $this->id . '_statu" value="0" class="statuer" >
                  draft
                </label> ';
        }
        elseif ($this->status == 1) // publish
            return "<span class='btn btn-success'><i class='fa fa-check'></i> Published</span>";
        elseif ($this->status == 2) // in checking
            return "<span class='btn btn-warning'><i class='fa fa-search'></i> In checking</span>";
        elseif ($this->status == 3) // checking validate
            return "<span class='btn btn-info'> Validate</span> ";
        elseif ($this->status == 4) // waiting for validation
            return "<span class='btn btn-info'> En Validation</span> ";
        else
            return "<span class='btn btn-info'>en attente</span>";
    }

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'number' => $this->number,
            'creationdate' => $this->creationdate,
            'images' => $this->images,
            'isnew' => $this->isnew,
            'status' => $this->status,
            'lang' => $this->lang,
            'pages' => $this->getPages(),
            'path' => $this->path,
            'cover' => $this->cover,
            'comicbook' => $this->comicbook,
        ];
    }

}
