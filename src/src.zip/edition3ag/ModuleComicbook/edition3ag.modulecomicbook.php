<?php
require 'Entity/Comicbook.php';
//require 'Dao/ComicbookDAO.php';
require 'Form/ComicbookForm.php';
require 'Controller/ComicbookController.php';
//require 'Genesis/ComicbookGenesis.php';

require 'Entity/Chapter.php';
//require 'Dao/ChapterDAO.php';
require 'Form/ChapterForm.php';
require 'Controller/ChapterController.php';
//require 'Genesis/ChapterGenesis.php';

require 'Entity/Gender.php';
//require 'Dao/GenderDAO.php';
require 'Form/GenderForm.php';
require 'Controller/GenderController.php';
require 'Entity/Comicbook_member.php';
require 'Entity/Comicbook_gender.php';
//require 'Genesis/GenderGenesis.php';


require 'Entity/Chapterchecking.php';
//require 'Dao/ChaptercheckingDAO.php';
require 'Form/ChaptercheckingForm.php';
require 'Controller/ChaptercheckingController.php';
//require 'Genesis/ChaptercheckingGenesis.php';
