<?php 


use DClass\devups\Datatable as Datatable;

class ComicbookController extends Controller{


    public static function detailAction($id) {

        $bandedessinee = Comicbook::find($id);
        $bandedessinee->collectMember();
        $bandedessinee->collectGender();
        $genrelist = [];
        $lastChapter = [];

        foreach ($bandedessinee->getGender() as $genre) {
            $genrelist[] = '<a class="bdgenre" href="#' . $genre->getId() . '" >' . $genre->getName() . '</a> ';
        }

        $__lang = local();
        if (isset($_SESSION[USERAPP]))
            $__lang = userapp()->getLang();

        $listChapitre = $bandedessinee->__hasmany(Chapter::class, false)
            ->andwhere("this.status", '=', 1)
            ->andwhere("chapter.lang", '=', $__lang)
            ->__getAll(false);

        if (count($listChapitre) >= 6) {
            for ($i = count($listChapitre); $i > count($listChapitre) - 6; $i--) {
                $lastChapter[] = $listChapitre[$i - 1];
            }
        } else {
            for ($i = count($listChapitre); $i > 0; $i--) {
                $lastChapter[] = $listChapitre[$i - 1];
            }
        }

        $iliked = 0;
        if(isset($_SESSION[USERID]))
            $iliked = Kolacomicbook::select()->where($bandedessinee)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

        return array('success' => true,
            'bd' => $bandedessinee,
            "title" => $bandedessinee->getName(),
            'iliked' => $iliked,
            'nbkolas' => Kolacomicbook::count($bandedessinee),
            'genrelist' => $genrelist,
            'listChapter' => $listChapitre,
            'lastChapter' => $lastChapter,
            "meta_seo_title" => $bandedessinee->getName(),
            "meta_seo_image" => $bandedessinee->showLogo(),
            "meta_seo_description" => $bandedessinee->getSynopsis(),
            'detail' => 'detail de l\'action.');
    }

    public static function listOrdonneAction() {

        $listBandedessinee = Comicbook::select()
            ->where("this.status", "=", 0)
            ->andwhere("this.ischronic", "=", 0)
            ->orderby("this.name")
            ->__getAll();

        $listLettre = [];
        foreach ($listBandedessinee as $bd) {
            $lettre = strtolower($bd->getName()[0]);
            if (!in_array($lettre, $listLettre))
                $listLettre[] = $lettre;

            $groupbd[$lettre][] = ["bd" => $bd, "nbchapter" => Chapter::count($bd)];
        }

        return array('success' => true, // pour le restservice
            'groupbd' => $groupbd,
            'listLettre' => $listLettre,
            'url' => '#', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }

    public static function renderFormWidget($id = null) {
        if($id)
            ComicbookForm::__renderFormWidget(Comicbook::find($id), 'update');
        else
            ComicbookForm::__renderFormWidget(new Comicbook(), 'create');
    }

    public static function renderDetail($id) {
        ComicbookForm::__renderDetailWidget(Comicbook::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $comicbook = new Comicbook();
        if($id){
            $action = "update&id=".$id;
            $comicbook = Comicbook::find($id);
            $comicbook->collectGender();
            $comicbook->collectMember();
        }

        return ['success' => true,
            'form' => ComicbookForm::__renderForm($comicbook, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Comicbook(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Comicbook(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $comicbook = Comicbook::find($id);

            return array( 'success' => true, 
                            'comicbook' => $comicbook,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($comicbook_form = null){
        extract($_POST);

        $comicbook = $this->form_fillingentity(new Comicbook(), $comicbook_form);

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'comicbook' => $comicbook,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }

        $comicbook->setCreationdate(new DateTime());
        $id = $comicbook->__insert();

        $path = "comicbook/".$id;
        Comicbook::Dfile("banner")
            ->addresize([400], "", "", false)
            ->addresize([100], "100_", "", false)
            ->saveoriginal(false)
            ->setfile_name("banner.jpg")
            ->moveto($path);

        Comicbook::Dfile("logo")
            ->addresize([400], "", "", false)
            ->addresize([100], "100_", "", false)
            ->saveoriginal(false)
            ->setfile_name("logo.png")
            ->moveto($path);

        $comicbook->__update([
            "path" => $path
        ])->exec();

        $comicbook =  Comicbook::find($id);

        return 	array(	'success' => true,
                        'comicbook' => $comicbook,
                        'tablerow' => Datatable::getSingleRowRest($comicbook),
                        'detail' => '');

    }

    public function updateAction($id, $comicbook_form = null){
        extract($_POST);
            
        $comicbook = $this->form_fillingentity(new Comicbook($id), $comicbook_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'comicbook' => $comicbook,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }

        $comicbook->setPath("comicbook/".$id);

        Comicbook::Dfile("banner")
            ->addresize([400], "", "", false)
            ->addresize([100], "100_", "", false)
            ->saveoriginal(false)
            ->setfile_name("banner.jpg")
            ->moveto($comicbook->getPath());

        Comicbook::Dfile("logo")
            ->addresize([400], "", "", false)
            ->addresize([100], "100_", "", false)
            ->saveoriginal(false)
            ->setfile_name("logo.png")
            ->moveto($comicbook->getPath());

        $comicbook->__update();
        return 	array(	'success' => true,
                        'comicbook' => $comicbook,
                        'tablerow' => Datatable::getSingleRowRest($comicbook),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Comicbook::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Comicbook::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'comicbook' => new Comicbook(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $comicbook = Comicbook::find($id);

        return array('success' => true, // pour le restservice
                        'comicbook' => $comicbook,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
