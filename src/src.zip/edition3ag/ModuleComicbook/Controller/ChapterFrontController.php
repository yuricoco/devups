<?php


use DClass\devups\Datatable as Datatable;

class ChapterFrontController extends ChapterController
{


    public function getnewchronicAction()
    {

        $lang = local();

        $nbnew = Chapter::select()->where(' this.lang = "'.$lang.'" and this.status = 1 and this.isnew = "1" and comicbook.ischronic = 1 ')->__countEl();
        if ($nbnew) {
            return "<span class='notif new-image'>$nbnew<span>";
        } else {
            return '';
        }
    }

    public static function getnewAndroid()
    {
        return Chapter::select()->where(' this.isnew = "1" and comicbook.ischronic = 1 ')->__countEl();
    }

    public static function read_onlineAction($idchap, $idpage)
    {
        $idpage = intval($idpage);
        $chapitre = Chapter::find($idchap);

        $pagesforjson = $chapitre->getPages();

        $nbpage = count($pagesforjson);
        if ($idpage == 0 && $idpage >= $nbpage)
            $idpage = 1;


        $scanpage = (object)$pagesforjson[$idpage - 1];

        for ($i = 0; $i < $nbpage; $i++) {
            $array[$i] = $i + 1;
        }
        $pages = $array;
        $comicbook = $chapitre->getComicbook();
        $listChapitre = Chapter::select()->where($comicbook)->orderby("this.id desc")->__getAll(false);

        $iliked = 0;
        if (isset($_SESSION[USERID]))
            $iliked = Kolachapter::select()->where($chapitre)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

        return array('success' => true,
            'pages' => $pages,
            'pagesforjson' => $pagesforjson,
            'chapter' => $chapitre,
            'iliked' => $iliked,
            'nbkolas' => Kolachapter::count($chapitre),
            'comicbook' => $comicbook,
            'chapitres' => $listChapitre,
            'scanpage' => $scanpage,
            'nbcomments' => Comment::count($chapitre),
            'comments' => CommentController::listCommentChapitreAction($chapitre->getId()),
            'detail' => 'detail de l\'action.');
    }

    /**
     * retourne un tableau d'instance de l'entité ou un json pour les requetes asynchrone (ajax)
     *
     * @param type $id
     * @return \Array
     */
    public static function listChronicOrderedAction($limit = 8, $lang = "fr")
    {

        $__lang = local();
        if (isset($_SESSION[USERAPP]))
            $__lang = userapp()->getLang();

        $chapters = [];

        $qb = new QueryBuilder(new Chapter());
        $listChapitre = $qb->select()
            ->where("this.status", 1)
            ->andwhere("this.lang", '=', $__lang)
            ->andwhere("comicbook.ischronic", '=', 1)
            ->orderby("this.id desc")
            ->limit($limit)
            ->__getAll();

        foreach ($listChapitre as $chapter) {

            $chapters[] = [
                'chapter' => $chapter,
                'firstpage' => 1,
                'nbcomments' => Comment::count($chapter)
            ];
        }

        return array('success' => true, // pour le restservice
            'chronics' => $chapters,
            'template' => ROOT . 'web/__lastchronicles.php', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }

    /**
     * retourne un tableau d'instance de l'entité ou un json pour les requetes asynchrone (ajax)
     *
     * @param type $id
     * @return \Array
     */
    public function listOrderedAction($lang = "fr")
    {
        $__lang = local();
        if (isset($_SESSION[USERAPP]))
            $__lang = userapp()->getLang();

        $chapters = [];
        $qb = new QueryBuilder(new Chapter());
        $listChapitre = $qb->select()
            ->where("this.lang", '=', $__lang)
            ->andwhere("this.status", '=', 1)
            ->andwhere("comicbook.ischronic", '=', 0)
            ->orderby("this.id desc")
            ->limit(10)
//                ->getSqlQuery();
            ->__getAll();

        $listads = [
            '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- infeed1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7691146384467908"
     data-ad-slot="2093271254"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
            '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- infeed2 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7691146384467908"
     data-ad-slot="4178462821"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
            '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- infeed3 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7691146384467908"
     data-ad-slot="1735954705"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>',
        ];
        $iter = 0;
        foreach ($listChapitre as $i => $chapter) {
            $ads = "";

            if ($i % 3) {
                if (isset($listads[$iter]))
                    $ads = $listads[$iter];
                $iter++;
            }

            $iliked = 0;
            if (isset($_SESSION[USERID]))
                $iliked = Kolachapter::select()->where($chapter)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

            $chapters[] = [
                'chapter' => $chapter,
                'ads' => $ads,
                'firstpage' => 1,
                'iliked' => $iliked,
                'nbkolas' => Kolachapter::count($chapter),
                'nbcomments' => Comment::select()->where($chapter)->__countEl(false),
                'comments' => $chapter->__hasmany(Comment::class, false)->limit(15)->__getAll()
            ];
        }

        return array('success' => true, // pour le restservice
            'chapters' => $chapters,
            'url' => '#', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }

    public static function renderFormWidget($id = null)
    {
        if ($id)
            ChapterForm::__renderFormWidget(Chapter::find($id), 'update');
        else
            ChapterForm::__renderFormWidget(new Chapter(), 'create');
    }

    public static function renderDetail($id)
    {
        ChapterForm::__renderDetailWidget(Chapter::find($id));
    }

    public static function renderForm($id = null, $action = "create")
    {
        $chapter = new Chapter();
        if ($id) {
            $action = "update&id=" . $id;
            $chapter = Chapter::find($id);
            //$chapter->collectStorage();
        }

        ChapterForm::__renderFormWidget($chapter, $action);
//        return ['success' => true,
//            'form' => ChapterForm::__renderForm($chapter, $action, true),
//        ];
    }

    public static function renderoneshotForm($id = null, $action = "create")
    {
        $chapter = new Chapter();
        if ($id) {
            $action = "update&id=" . $id;
            $chapter = Chapter::find($id);
            //$chapter->collectStorage();
        } else {

            $chapter->setComicbook(Comicbook::get(3));
            $numero = Chapter::select()->where($chapter->comicbook)->__countEl(false);
            $chapter->setNumber($numero + 1);
            $chapter->setUser(new User($_SESSION[USERID]));
        }

        ChapterForm::__renderOneshotFormWidget($chapter, $action);

    }

    public function datatable($next, $per_page)
    {
        $lazyloading = $this->lazyloading(new Chapter(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10)
    {

        $lazyloading = $this->lazyloading(new Chapter(), $next, $per_page, null, "this.id desc");

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }

    public function listoneshotAction($next = 1, $per_page = "all")
    {

        $lazyloading = $this->lazyloading(new Chapter(), $next, $per_page, Chapter::select()->where(new User($_SESSION[USERID])), "this.id desc");

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }

    public function showAction($id)
    {

        $chapter = Chapter::find($id);

        return array('success' => true,
            'chapter' => $chapter,
            'detail' => 'detail de l\'action.');

    }

    public function createAction($chapter_form = null)
    {
        extract($_POST);

        $chapter = $this->form_fillingentity(new Chapter(), $chapter_form);

        if ($this->error) {
            return array('success' => false,
                'chapter' => $chapter,
                'action_form' => 'create',
                'error' => $this->error);
        }
        $chapter->setCreationdate(new DateTime());
        if ((bool)$chapter->getComicbook()->getIschronic()) {
            $chapter->setChronic(json_encode(['author' => $author, 'artist' => $artist, 'about' => $about]));
        }
        $id = $chapter->__insert();

        $chapter->__update('this.path', "/comicbook/" . $chapter->comicbook->getId() . "/chapter/" . $id . "/")->exec();

        return array('success' => true,
            'chapter' => $chapter,
            'tablerow' => Datatable::getSingleRowRest($chapter),
            'detail' => '');

    }

    public function updateAction($id, $chapter_form = null)
    {
        extract($_POST);

        $chapter = $this->form_fillingentity(new Chapter($id), $chapter_form);


        if ($this->error) {
            return array('success' => false,
                'chapter' => $chapter,
                'action_form' => 'update&id=' . $id,
                'error' => $this->error);
        }
        if ((bool)$chapter->getComicbook()->getIschronic()) {
            $chapter->setChronic(json_encode(['author' => $author, 'artist' => $artist, 'about' => $about]));
        }

        $chapter->__update();
        return array('success' => true,
            'chapter' => $chapter,
            'tablerow' => Datatable::getSingleRowRest($chapter),
            'detail' => '');

    }

    public function deleteAction($id)
    {

        Chapter::delete($id);
        return array('success' => true, // pour le restservice
            'redirect' => 'index', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }


    public function deletegroupAction($ids)
    {

        Chapter::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
            'redirect' => 'index', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction()
    {

        return array('success' => true, // pour le restservice
            'chapter' => new Chapter(),
            'action_form' => 'create', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id)
    {

        $chapter = Chapter::find($id);

        return array('success' => true, // pour le restservice
            'chapter' => $chapter,
            'action_form' => 'update&id=' . $id, // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public static function numorder($nbcaract, $value)
    {
        $acte = "";
        $remaincarat = $nbcaract - strlen($value);
        for ($i = 0; $i < $remaincarat; $i++)
            $acte .= "0";
        //$acte = "0000";
        return $acte . $value;
    }

    public function orderpageAction($id)
    {
        $chapter = Chapter::find($id, false);
        $pageorder = json_decode($_POST["pageorder"], true);

        $basename = $chapter->comicbook->__get("alternatif")."_".$chapter->getNumber()."_";
        $time = date("His");

        $chapter->setCacheimage($time);
        $chapter->__update("cacheimage", $time)->exec();

        $checkingdata = false;
        $translatedata = false;
        $chapchk = $chapter->__hasone(Chapterchecking::class);

        if($chapchk->getId()){

            $contentfile = file_get_contents(ROOT . "data/chapterchecking/" . $chapchk->getId() . ".json");
            $checkingdata = json_decode($contentfile, true);

            $chaptrans = $chapter->__hasone(Chaptertranslate::class);
            if($chaptrans->getId()){

                $contentfile = file_get_contents(ROOT . "data/chaptertranslate/" . $chaptrans->getId() . ".json");
                $translatedata = json_decode($contentfile, true);
            }

        }

        foreach ($pageorder as $i => $order){
            $ext = ".".Dfile::getextension($order["page"]);
            $newname = $basename. self::numorder(3, $i)."_".$time.$ext;

            Dfile::d_rename($order["page"], $newname, $chapter->getPath());
            Dfile::d_rename("mini/mini_" . $order["page"], "mini/mini_" . $newname, $chapter->getPath());

            if($chapter->getCover() == $order["page"]){
                $chapter->__update("cover", $newname)->exec();
                $chapter->setCover($newname);
            }

            if($checkingdata){
                foreach ($checkingdata["pages"] as $i => $page){
                    if($page["name"] == $order["page"]){
                        $checkingdata["pages"][$i]["name"] = $newname;
                        //$checkingdata["pages"][$i]["double"] = $page["double"];
                        if($translatedata)
                            $translatedata["pages"][$i]["name"] = $newname;

                        break;
                    }
                }
            }

        }

        if($checkingdata){

            $file = fopen(ROOT . "data/chapterchecking/" . $chapchk->getId() . ".json", "w");
            fputs($file, json_encode($checkingdata));
            fclose($file);

            if($translatedata){

                $file = fopen(ROOT . "data/chaptertranslate/" . $chaptrans->getId() . ".json", "w");
                fputs($file, json_encode($translatedata));
                fclose($file);
            }

        }

        return ["success" => true,
            "images" => $chapter->getPages()
        ];

    }

}
