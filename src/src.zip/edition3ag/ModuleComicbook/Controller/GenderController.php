<?php 


use DClass\devups\Datatable as Datatable;

class GenderController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            GenderForm::__renderFormWidget(Gender::find($id), 'update');
        else
            GenderForm::__renderFormWidget(new Gender(), 'create');
    }

    public static function renderDetail($id) {
        GenderForm::__renderDetailWidget(Gender::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $gender = new Gender();
        if($id){
            $action = "update&id=".$id;
            $gender = Gender::find($id);
            //$gender->collectStorage();
        }

        return ['success' => true,
            'form' => GenderForm::__renderForm($gender, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Gender(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Gender(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $gender = Gender::find($id);

            return array( 'success' => true, 
                            'gender' => $gender,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($gender_form = null){
        extract($_POST);

        $gender = $this->form_fillingentity(new Gender(), $gender_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'gender' => $gender,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $gender->__insert();
        return 	array(	'success' => true,
                        'gender' => $gender,
                        'tablerow' => Datatable::getSingleRowRest($gender),
                        'detail' => '');

    }

    public function updateAction($id, $gender_form = null){
        extract($_POST);
            
        $gender = $this->form_fillingentity(new Gender($id), $gender_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'gender' => $gender,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $gender->__update();
        return 	array(	'success' => true,
                        'gender' => $gender,
                        'tablerow' => Datatable::getSingleRowRest($gender),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Gender::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Gender::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'gender' => new Gender(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $gender = Gender::find($id);

        return array('success' => true, // pour le restservice
                        'gender' => $gender,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
