<?php 


use DClass\devups\Datatable as Datatable;

class ChaptercheckingController extends Controller{

    public function validatecheckingAction($id) {

        $chapterchecking = Chapterchecking::find($id, false);
        $chapterchecking->__update([
            "status" => "va",
            "validated_at" => date("Y-m-d H:i:s"),
            ], false, false, false)->exec();

        $idchap= Chapterchecking::getattribut("chapter_id", $id);
        Chapter::update("this.status", 3, $idchap, false)->exec();

        $chapter = Chapter::find($idchap, false);
        $alternatif = $chapter->comicbook->__get("alternatif");
        $notif = new Notification();
        $notif->setCreationdate(new DateTime());
        $notif->setEntity(Chapterchecking::class);
        $notif->setEntityid($id);
        $notif->__insert();

        $user = User::findrow($chapterchecking->user->getId());
        //foreach ($users as $user){
            $content = $alternatif." "
                . gettranslation("title.chapter", $user->getLang())." "
                . $chapter->getNumber()." "
                . gettranslation("notif.checkingvalidated", $user->getLang());

            NotificationbroadcastedController::broadcast($user, null, $notif, $content);
        //}

        return 	array(	'success' => true,
            'redirect' => "index.php?path=chapterchecking/index",
            //'tablerow' => Datatable::getSingleRowRest($chapterchecking),
            'detail' => '');
    }

    public function finishcheckingAction($id) {
        //Chapterchecking::update("status", "fi", $id, false)->exec();

        $chapterchecking = Chapterchecking::find($id);
        $chapterchecking->__update([
            "this.status" => "fi",
            "ended_at" => date("Y-m-d H:i:s"),
        ])->exec();

        //todo : create notification for the administrator: user.pseudo have ended the checking of chapter.title. he is waiting for validation

        $chapter = $chapterchecking->chapter;
        $alternatif = $chapter->comicbook->__get("alternatif");
        $notif = new Notification();
        $notif->setCreationdate(new DateTime());
        $notif->setEntity(Chapterchecking::class);
        $notif->setEntityid($id);
        $notif->__insert();

        //todo create notification then user_notification for user
        $admims = Dvups_admin::allrows();
        foreach ($admims as $admim){
            $content = $chapterchecking->user->getPseudo()
                . gettranslation("notif.finishedcheckingof") .' '. $alternatif." "
                . gettranslation("title.chapter")." "
                . $chapter->getNumber()." ";

            NotificationbroadcastedController::broadcast(null, $admim, $notif, $content);
        }


        return 	array(	'success' => true,
            'detail' => '');
    }

    public function savecheckingAction($id) {

        extract($_POST);

        $file = fopen(ROOT."data/chapterchecking/".$id.".json", "w");
        fputs($file, $datajson);

        fclose($file);

        return 	array(	'success' => true,
            'detail' => '');

    }

    public function startcheckingAction($id) {

        $chapterchecking = Chapterchecking::find($id);
        $chapterchecking->setStatus("pr");
        $chapterchecking->setStarted_at(new DateTime());
        $chapterchecking->user = userapp();

        $chapterchecking->__update();

        //todo : create notification for the administrator: user.pseudo have started the checking of chapter.title

        $chapter = $chapterchecking->chapter;
        $alternatif = $chapter->comicbook->__get("alternatif");
        $notif = new Notification();
        $notif->setCreationdate(new DateTime());
        $notif->setEntity(Chapterchecking::class);
        $notif->setEntityid($id);
        //$notif->setUrl($idcc);
        $notif->setContent($alternatif." "
            . gettranslation("title.chapter")." "
            . $chapter->getNumber()." ");
        $notif->__insert();

        //todo create notification then user_notification for user
        $admims = Dvups_admin::allrows();
        foreach ($admims as $admim){
            $content = $chapterchecking->user->getPseudo()
                . gettranslation("notif.startedcheckingof") .' '. $alternatif." "
                . gettranslation("title.chapter")." "
                . $chapter->getNumber()." ";

            NotificationbroadcastedController::broadcast(null, $admim, $notif, $content);
        }

        return 	array(	'success' => true,
            'tablerow' => Datatable::getSingleRowRest($chapterchecking),
            'detail' => '');

    }

    public static function renderFormWidget($id = null) {
        if($id)
            ChaptercheckingForm::__renderFormWidget(Chapterchecking::find($id), 'update');
        else
            ChaptercheckingForm::__renderFormWidget(new Chapterchecking(), 'create');
    }

    public static function renderDetail($id) {
        ChaptercheckingForm::__renderDetailWidget(Chapterchecking::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $chapterchecking = new Chapterchecking();
        if($id){
            $action = "update&id=".$id;
            $chapterchecking = Chapterchecking::find($id);
            //$chapterchecking->collectStorage();
        }

        return ['success' => true,
            'form' => ChaptercheckingForm::__renderForm($chapterchecking, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Chapterchecking(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10, $userid = null){
        $qb = null;
        if($userid){
            $qb = Chapterchecking::select()->where(new User($userid));
        }
        $lazyloading = $this->lazyloading(new Chapterchecking(), $next, $per_page, $qb, "this.id desc");

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $chapterchecking = Chapterchecking::find($id);
            $chaptercheckingjson = file_get_contents(ROOT."data/chapterchecking/".$id.".json");

            return array( 'success' => true, 
                            'chapterchecking' => $chapterchecking,
                            'chaptercheckingjson' => $chaptercheckingjson,
                            'detail' => 'detail de l\'action.');

    }

    public function resetcheckingdataAction($id){
        $chapterchecking = Chapterchecking::find($id, false);
        $chapter = $chapterchecking->chapter->__show(false);
        $pages = $chapter->getPages();
        $pagesjson = [];
        foreach ($pages as $page) {
            $pagesjson[] = [
                "name" => $page["page"],
                "double" => $page["double"],
                "bubbles" => [],
            ];
        }

        $chaptercheckingjson = [
            "_id" => $id,
            "pages" => $pagesjson,
        ];

        $file = fopen(ROOT . "data/chapterchecking/" . $id . ".json", "w");
        //fputs($file, "");
        fputs($file, json_encode($chaptercheckingjson));
        fclose($file);

        return ["success" => true, "id" => $id, "title" => $chapter->getTitle()];

    }

    public function createAction($chapterchecking_form = null){
        extract($_POST);

        $chapterchecking = $this->form_fillingentity(new Chapterchecking(), $chapterchecking_form);
 

        $chapterchecking->setCreationdate(new DateTime());

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'chapterchecking' => $chapterchecking,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $chapterchecking->__insert();
        return 	array(	'success' => true,
                        'chapterchecking' => $chapterchecking,
                        'tablerow' => Datatable::getSingleRowRest($chapterchecking),
                        'detail' => '');

    }

    public function updateAction($id, $chapterchecking_form = null){
        extract($_POST);
            
        $chapterchecking = $this->form_fillingentity(new Chapterchecking($id), $chapterchecking_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'chapterchecking' => $chapterchecking,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $chapterchecking->__update();
        return 	array(	'success' => true,
                        'chapterchecking' => $chapterchecking,
                        'tablerow' => Datatable::getSingleRowRest($chapterchecking),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Chapterchecking::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Chapterchecking::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'chapterchecking' => new Chapterchecking(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $chapterchecking = Chapterchecking::find($id);

        return array('success' => true, // pour le restservice
                        'chapterchecking' => $chapterchecking,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
