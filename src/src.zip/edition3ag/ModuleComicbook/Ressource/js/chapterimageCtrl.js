//chapterCtrl

$("#scanpagecontainer").sortable();
$("#scanpagecontainer").disableSelection();

var imagetoupload = [];

$("#scanpagecontainer").on("click", ".delete", function () {
    var index = $(".rep-element").index($(this).parents(".rep-element"));
    console.log(index);
    var $repel = $(this).parents(".rep-element");
    var nameimg = $repel.data("nameimg");
    model._get('deleteimage&chapterimage=' + nameimg + '&id=' + idchap, function (response) {
        console.log(response);
        $repel.remove();
    });
});

$("#scanpagecontainer").on("click", ".remove", function () {
    var index = $(".rep-element").index($(this).parents(".rep-element"));
    console.log(index);
    $(this).parents(".rep-element").remove();
    imagetoupload = devups.removeElementInArray(imagetoupload, index);
});
// $("#scanpagecontainer").on("click", ".cancel-replacement", function () {
//     var index = $(".rep-element").index($(this).parents(".rep-element"));
//     console.log(index);
//     $(this).parents(".rep-element").remove();
//     imagetoupload = devups.removeElementInArray(imagetoupload, index);
// });
function cancelreplacement(el, index){
    if(index < 0){
        alert("no image to cancel replace!")
        return;
    }
    var $repel = $(el).parents(".rep-element");
    $repel.html(imagetoreplace[index].backup);
    imagetoreplace = devups.removeElementInArray(imagetoreplace, index);
}

$("#scanpagecontainer").on("click", ".setcover", function () {

    var $span = $(this);
    // coverid = chapterimage;
    // $scope.chapter.cover = chapterimage;
    //
    $span.html("loading ...");
    var nameimg = $span.data("nameimg");
    model._get('setchaptercover&chapterimage=' + nameimg + '&id=' + idchap, function (response) {
        $('#coverspan').replaceWith('<span data-nameimg="'+nameimg+'" class="btn btn-default btn-xs setcover"><i class="fa fa-image"></i> as cover</span>');
        $span.replaceWith('<span id="coverspan" class="btn btn-success btn-xs"><i class="fa fa-image"></i>cover</span>');
        $("#dv_table").find("#"+idchap).replaceWith(response.tablerow);

    });

});

var imagetoreplace = [];

$("#scanpagecontainer").on("change", ".filereplace", function () {
//$(".filereplace").change(function () {
    console.log("dslfsdfsfsdf");
    var $repel = $(this).parents(".rep-element");
    var $repelbackup = $repel.html(); // for canceling replacement

    var file = this.files[0];
    var oburl = window.URL.createObjectURL(file);

    imagetoreplace.push({image : file, backup : $repelbackup})

    $repel.find(".cancel").switchClass(".cancel", ".remove");
    $repel.html(`
            <progress class="progress"></progress><div class="blockimg">
<span onclick="cancelreplacement(this, ${imagetoreplace.length - 1})" class="btn btn-danger btn-xs">x cancel</span>
<span class="btn btn-info btn-sm" onclick="replaceimage(this, ${imagetoreplace.length - 1})" >replace</span>
<embed type="${file.type}" width="100%" src="${oburl}" /></div>`);
    //replace_image

})

function replaceimage(el, index){
    if(index < 0){
        alert("no image to replace!")
        return;
    }

    var $repel = $(el).parents(".rep-element");
    var file = imagetoreplace[index].image;

    devups.upload(file, model.baseurl+`?path=chapter.replace_image&toreplace=${$repel.data('nameimg')}&id=${idchap}`,
        function (loaded, total) {
            $repel.find(".progress")[0].value = loaded;
            $repel.find(".progress")[0].max = total;
        },
        function () {

            console.log("end all upload")
            //$(".saveupdate").html("Enregistrer");
            imagetoreplace = devups.removeElementInArray(imagetoreplace, index);
        },
        function (response) {
            console.log(response);
            var file = response.scanpage;

            var coverhtml = '<span data-nameimg="'+file.page+'" class="btn btn-default btn-xs setcover"><i class="fa fa-image"></i> as cover</span>';
            if(file.cover)
                coverhtml = '<span id="coverspan" class="btn btn-success btn-xs"><i class="fa fa-image"></i>cover</span>';

            $repel.html(`<div class="blockimg">
<span class="btn btn-danger delete btn-xs">x cancel</span>
${coverhtml}
<embed type="image/jpeg" width="100%" src="${file.showmini}?dummy=8484744" />
<input type="file" class="filereplace" accept=".jpg, .jpeg, .pdf" ></div>`);

            }, "json", "image"
    )
}

$("#mapfile").change(function () {
    console.log(this.files.length);
    if(this.files[0]){
        for(i = 0; i < this.files.length; i++) {

            var file = this.files[i];
            var oburl = window.URL.createObjectURL(file);
            //if(file.type == "application/pdf") pagecover
            $("#scanpagecontainer").append('<div class=\'rep-element\'>' +
                '<progress class="progress"></progress>' +
                '<div class="blockimg">' +
                '<span class="btn btn-danger remove btn-xs">x remove</span>' +
                '<embed type="'+file.type+'" width="100%" src="'+oburl+'" /></div></div>')

            imagetoupload.push(file);
        }
        $("#mapfile").val("");
    }
});

function bindimage(){
    console.log(images);
    for(i = 0; i < images.length; i++) {

        var file = images[i];
        var coverhtml = '<span data-nameimg="'+file.page+'" class="btn btn-default btn-xs setcover"><i class="fa fa-image"></i> as cover</span>';
        if(file.cover)
            coverhtml = '<span id="coverspan" class="btn btn-success btn-xs"><i class="fa fa-image"></i>cover</span>';
        //if(file.type == "application/pdf") pagecover
        $("#scanpagecontainer").append('<div data-nameimg="'+file.page+'" class=\'rep-element\'><div class="blockimg">' +
            '<span class="btn btn-danger delete btn-xs">x cancel</span>' +
            coverhtml +
            '<embed type="image/jpeg" width="100%" src="'+file.showmini+'" /><input type="file" class="filereplace" accept=".jpg, .jpeg, .pdf" ></div></div>')

    }
}
bindimage();

function reorderpages(){
    var pageorder = [];
    $.each($(".rep-element"), function (index, el) {
        pageorder.push({page: $(el).data('nameimg'), order: index})
    });

    console.log(pageorder)
    var fd = new FormData();
    fd.append('pageorder', JSON.stringify(pageorder))
    model._post("orderpage&id="+idchap, fd, function (response) {
        console.log(response);
        images = response.images;
        $("#scanpagecontainer").html("")
        bindimage();

        $(".orderimage").html("Order image");

    })
}

$(".orderimage").click(function () {
    var nbeltoupload = imagetoupload.length;
    var nbeluploaded = 0;

    if(nbeltoupload === 0 && images.length !== 0) {

        $(".orderimage").html("<i class='fa fa-spinner' ></i> Traitement en cours ...");

        reorderpages();
    }else{
        alert("you may upload the image first!")
    }

});


function uploadaction(){

}

$(".saveupdate").click(function () {
    var nbeltoupload = imagetoupload.length;
    var nbeluploaded = 0;

    $(".saveupdate").html("<i class='fa fa-spinner' ></i> Transfère en cours ...");

    if(nbeltoupload){
        var nbel = $(".rep-element").find(".delete").length;
        $.each(imagetoupload, function (index, file) {
            devups.upload(file, model.baseurl+`?path=chapter.uploadimage&id=${idchap}`,
                function (loaded, total) {
                    $(".progress").eq(index)[0].value = loaded;
                    $(".progress").eq(index)[0].max = total;
                },
                function () {
                    nbeluploaded++;
                    if(nbeluploaded === nbeltoupload){
                        console.log("end all upload")
                        $(".saveupdate").html("Enregistrer");
                    }
                },
                function (response) {
                    console.log(response);
                    $(".rep-element").eq(index + nbel).find(".progress").remove();
                    $(".rep-element").eq(index + nbel).attr("data-nameimg", response.scanpage.page);
                    $(".rep-element").eq(index + nbel).find(".remove").switchClass(".remove", ".cancel");
                    $(".blockimg").eq(index + nbel).append('<span data-nameimg="'+response.scanpage.page+'" class="btn btn-default btn-xs setcover"><i class="fa fa-image"></i> set as cover</span>');
                    $(".blockimg").eq(index + nbel).append(`<input type="file" class="filereplace" accept=".jpg, .jpeg, .pdf" >`);
                }, "json", "image"
            )
        })
        imagetoupload = [];
    }else {
        console.log("no image to upload")
    }

})