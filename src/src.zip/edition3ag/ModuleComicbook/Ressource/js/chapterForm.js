//chapterForm
function showchronicoption(comicbook){
    if(comicbook.ischronic)
        $("#chronic").show();
    else
        $("#chronic").hide();
}
console.log(comicbooks)
$("#comicbook_select").change(function () {

    var $this = $(this);
    // if ($(this).val() === '7') {
    //     $("#chronic").show();
    // } else {
    //     $("#chronic").hide();
    // }
    $.each(comicbooks, function (i, comicbook) {

        if(comicbook.id === $this.val()){
            showchronicoption(comicbook);
        }
    })
    //    });

    $.ajax({
        type: 'GET',
        url: 'services.php?path=chapter.get_numero',
        data: 'id=' + $(this).val(),
        dataType: 'json',
        success: function (response) {
            console.log(response);
            if (response.success) {
                $("input[name='chapter_form[number]']").val(response.numero);
            } else {
                $("input[name='chapter_form[number]']").val('0');
            }
        },
        error: function (resultat, statut, erreur) {
            console.log(erreur);
            console.log(resultat);
            $('#err').html(resultat.responseText);
            $('#log_erreur').append(resultat.responseText);
        }
    });

});

showchronicoption(comicbook);

