
model.starttranslation = function(id, $this){
    model.entity = "chapter";

    if(!confirm('This action will set this chapter available for users to work on. \nAre you sure you want to proceed?')) return false;

    $($this).html(" ... ");
    model._post('starttranslate&id='+id, null, function (response){
        console.log(response);
        $($this).html(" ok ");
        $("#dv_table").find("#"+id).replaceWith(response.tablerow);
    });
}

model.startchecking = function(id, $this){
    model.entity = "chapter";

    if(!confirm('This action will set this chapter available for users to work on. \nAre you sure you want to proceed?')) return false;

    $($this).html(" ... ");
    model._post('startchecking&id='+id, null, function (response){
        console.log(response);
        $($this).html(" ok ");
        $("#dv_table").find("#"+id).replaceWith(response.tablerow);
    });
}

model._editcustom = function(id){
    this._get('imageeditor&id='+id, function (response){
        model.modalbody.html(response);
    });
}

$("#dv_table").on("click", ".newer", function () {
    console.log($(this).parents('tr').attr("id"));
    console.log($(this).val());
    $("#blockspinner").fadeIn();
    $.get(model.baseurl+"?path=chapter.setnew&id=" + $(this).parents('tr').attr("id") + "&param=" + $(this).val(),
        function (response) {
            console.log(response);
            alert("change saved");
        });
});

$("#dv_table").on("click", ".statuer", function () {
    console.log($(this).parents('tr').attr("id"));
    console.log($(this).val());
    $("#blockspinner").fadeIn();
    var id = $(this).parents('tr').attr("id");
    model._get("setstatus&id=" + id + "&param=" + $(this).val(),
        function (response) {
            console.log(response);
            $("#dv_table").find("#"+id).replaceWith(response.tablerow);
            alert("change saved");
        });
});
