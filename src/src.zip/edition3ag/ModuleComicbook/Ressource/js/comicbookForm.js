//comicbookForm

// dform.submitform = function($this){
//
//     var form = $($this);
//     var actionarray = form.attr("action").split("/");
//     var action = actionarray[1];
//     var callback = function (response) { console.log(response); };
//     entityid = $(this).data("id");
//
//     if(entityid){
//         //action = actionarray[1];
//         //action = "update&id="+entityid;
//         callback = dform.callbackupdate;
//     }else{
//         callback = dform.callbackcreate;
//     }
//
//     var formdata = model._formdata(form);
//
//     console.log(model.formentity);
//     model.getformvalue("name")
//
//     model._post(action, formdata, callback);
//
// }
