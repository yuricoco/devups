<style>

    .pagecover {
        border: .5px solid #f33;
        box-shadow: 0px 0px 2px rgba(255, 0, 0, .3);
    }

    .toreplace {
        border: .5px solid #33F !important;
        box-shadow: 0px 0px 2px rgba(0, 0, 255, .3) !important;
    }

    .chapterimage small {
        position: absolute;
        bottom: 50px;
        left: 0;
        font-weight: bold;
        display: block;
        background: white;
        padding: 3px;
    }

    .rep-element {
        display: inline-block;
        vertical-align: bottom;
        width: 150px;
        overflow: visible;
        min-width: 150px;
        min-height: 150px;
        position: relative;
        margin: 3px;
    }

    .blockimg {
        width: 150px;
        background: #fff;
        padding: 3px;
    }

    .blockimg:hover {
        overflow: visible;
        box-shadow: 0px 0px 2px rgba(0, 0, 0, .3);
    }

    .blockspinner {
        position: absolute;
        min-height: 150px;
        z-index: 10;
    }

    .spinner {
        width: 40px;
        height: 40px;
        display: inline-block;
        position: relative;
        /*margin: 100px auto;*/
    }

    .sp-text {
        width: 300px;
        font-size: x-large;
    }

    .double-bounce1, .double-bounce2 {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #f33;
        opacity: 0.6;
        position: absolute;
        top: 0;
        left: 0;

        -webkit-animation: sk-bounce 2.0s infinite ease-in-out;
        animation: sk-bounce 2.0s infinite ease-in-out;
    }

    .double-bounce2 {
        -webkit-animation-delay: -1.0s;
        animation-delay: -1.0s;
    }

    .modal-dialog {
        width: 900px !important;
        margin: 30px auto;
    }

    .filereplace{
        opacity: .5;
        position: absolute;
        bottom: 0;
        height: calc(50px);
    }

    @-webkit-keyframes sk-bounce {
        0%, 100% {
            -webkit-transform: scale(0.0)
        }
        50% {
            -webkit-transform: scale(1.0)
        }
    }

    @keyframes sk-bounce {
        0%, 100% {
            transform: scale(0.0);
            -webkit-transform: scale(0.0);
        }
        50% {
            transform: scale(1.0);
            -webkit-transform: scale(1.0);
        }
    }

</style>


<div class="row">


    <div class="col-lg-12 col-md-12">
        <h4>
            <?= $chapter->getTitle(); ?>
        </h4>
    </div>

    <div class="col-lg-12 col-md-12">
        <div>

            <div class="form-group">
                <label>Images </label>

                <?= Form::file('images', "",
                    ['accept' => '.jpg, .jpeg, .pdf', "multiple" => 'true', 'class' => 'form-control', 'id' => 'mapfile'], 'image') ?>

            </div>
            <div class="form-group text-center">
                <button class="orderimage btn btn-info">Order image</button>
                <button class="saveupdate btn btn-success">Enregistrer</button>
            </div>
            <div id="scanpagecontainer" class="form-group"></div>
            <div class="form-group text-center">
                <button class="orderimage btn btn-info">Order image</button>
                <button class="saveupdate btn btn-success">Enregistrer</button>
            </div>
        </div>
    </div>

</div>

<script>
    var idchap = '<?= $chapter->getId() ?>';
    var images = <?= json_encode($chapter->getPages()) ?>;
</script>
<script src="<?php echo CLASSJS ?>devups.js"></script>
<script src="<?php echo JS ?>jquery-ui.js"></script>
<script src="<?= __env . Chapter::classpath() ?>Ressource/js/chapterimageCtrl.js"></script>
