<?php
//ModuleComicbook

require '../../../admin/header.php';

use Genesis as g;
use Request as R;

header("Access-Control-Allow-Origin: *");


global $views;
$views = __DIR__ . '/Ressource/views';

$comicbookCtrl = new ComicbookController();
$chapterCtrl = new ChapterController();
$genderCtrl = new GenderController();
$chaptercheckingCtrl = new ChaptercheckingController();

(new Request('hello'));

switch (R::get('path')) {

    case 'chapterchecking.resetcheckingdata':
        g::json_encode($chaptercheckingCtrl->resetcheckingdataAction(R::get("id")));
        break;
    case 'chapterchecking.validate':
        g::json_encode($chaptercheckingCtrl->validatecheckingAction(R::get("id")));
        break;
    case 'chapterchecking._new':
        g::json_encode(ChaptercheckingController::renderForm());
        break;
    case 'chapterchecking.create':
        g::json_encode($chaptercheckingCtrl->createAction());
        break;
    case 'chapterchecking._edit':
        g::json_encode(ChaptercheckingController::renderForm(R::get("id")));
        break;
    case 'chapterchecking.update':
        g::json_encode($chaptercheckingCtrl->updateAction(R::get("id")));
        break;
    case 'chapterchecking._show':
        ChaptercheckingController::renderDetail(R::get("id"));
        break;
    case 'chapterchecking._delete':
        g::json_encode($chaptercheckingCtrl->deleteAction(R::get("id")));
        break;
    case 'chapterchecking._deletegroup':
        g::json_encode($chaptercheckingCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'chapterchecking.datatable':
        g::json_encode($chaptercheckingCtrl->datatable(R::get('next'), R::get('per_page')));
        break;

    case 'comicbook._new':
        g::json_encode(ComicbookController::renderForm());
        break;
    case 'comicbook.create':
        g::json_encode($comicbookCtrl->createAction());
        break;
    case 'comicbook._edit':
        g::json_encode(ComicbookController::renderForm(R::get("id")));
        break;
    case 'comicbook.update':
        g::json_encode($comicbookCtrl->updateAction(R::get("id")));
        break;
    case 'comicbook._show':
        ComicbookController::renderDetail(R::get("id"));
        break;
    case 'comicbook._delete':
        g::json_encode($comicbookCtrl->deleteAction(R::get("id")));
        break;
    case 'comicbook._deletegroup':
        g::json_encode($comicbookCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'comicbook.datatable':
        g::json_encode($comicbookCtrl->datatable(R::get('next'), R::get('per_page')));
        break;

    case 'chapter.orderpage':
        g::json_encode($chapterCtrl->orderpageAction($_GET['id']));
        break;
    case 'chapter.starttranslate':
        g::json_encode($chapterCtrl->starttranslateAction($_GET['id']));
        break;
    case 'chapter.startchecking':
        g::json_encode($chapterCtrl->startcheckingAction($_GET['id']));
        break;
    case 'chapter.get_numero':
        g::json_encode($chapterCtrl->numeroAction($_GET['id']));
        break;
    case 'chapter.setstatus':
        g::json_encode($chapterCtrl->setstatueAction($_GET['id'], $_GET['param']));
        break;
    case 'chapter.setnew':
        g::json_encode($chapterCtrl->setnewAction($_GET['id'], $_GET['param']));
        break;
    case 'chapter.imageeditor':
        g::renderView('chapter.form_image', ["chapter" => Chapter::find($_GET["id"], false)]);
        break;
    case 'chapter.setchaptercover':
        g::json_encode($chapterCtrl->setcoverAction($_GET['chapterimage'], $_GET['id']));
        break;
    case 'chapter.__editimage':
        g::json_encode($chapterCtrl->__editimage($_GET['id']));
        break;
    case 'chapter.replace_image':
        g::json_encode($chapterCtrl->uploadimageAction($_GET['id'], $_GET["toreplace"]));
        break;
    case 'chapter.uploadimage':
        g::json_encode($chapterCtrl->uploadimageAction($_GET['id']));
        break;
    case 'chapter.deleteimage':
        g::json_encode($chapterCtrl->deleteimageAction($_GET['id'], $_GET['chapterimage']));
        break;
    case 'chapter._new':
        ChapterController::renderForm();
        break;
    case 'chapter.create':
        g::json_encode($chapterCtrl->createAction());
        break;
    case 'chapter._edit':
        ChapterController::renderForm(R::get("id"));
        break;
    case 'chapter.update':
        g::json_encode($chapterCtrl->updateAction(R::get("id")));
        break;
    case 'chapter._show':
        ChapterController::renderDetail(R::get("id"));
        break;
    case 'chapter._delete':
        g::json_encode($chapterCtrl->deleteAction(R::get("id")));
        break;
    case 'chapter._deletegroup':
        g::json_encode($chapterCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'chapter.datatable':
        g::json_encode($chapterCtrl->datatable(R::get('next'), R::get('per_page')));
        break;

    case 'gender._new':
        g::json_encode(GenderController::renderForm());
        break;
    case 'gender.create':
        g::json_encode($genderCtrl->createAction());
        break;
    case 'gender._edit':
        g::json_encode(GenderController::renderForm(R::get("id")));
        break;
    case 'gender.update':
        g::json_encode($genderCtrl->updateAction(R::get("id")));
        break;
    case 'gender._show':
        GenderController::renderDetail(R::get("id"));
        break;
    case 'gender._delete':
        g::json_encode($genderCtrl->deleteAction(R::get("id")));
        break;
    case 'gender._deletegroup':
        g::json_encode($genderCtrl->deletegroupAction(R::get("ids")));
        break;
    case 'gender.datatable':
        g::json_encode($genderCtrl->datatable(R::get('next'), R::get('per_page')));
        break;


    default:
        echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
        break;
}

