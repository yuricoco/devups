<?php 
    require 'Entity/Image.php';
    //require 'Dao/ImageDAO.php';
    require 'Form/ImageForm.php';
    require 'Controller/ImageController.php';
    //require 'Genesis/ImageGenesis.php';
