<?php
            //ModuleImage
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleImage</a> ');

    
        		$imageCtrl = new ImageController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'image/index':
        Genesis::renderView('image.index',  $imageCtrl->listAction());
        break;					
    case 'image/create':
        Genesis::renderView( 'image.form', $imageCtrl->createAction(), true);
        break;					
    case 'image/update':
        Genesis::renderView( 'image.form',  $imageCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    