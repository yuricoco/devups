<?php

/**
 * @Entity @Table(name="image")
 * */
class Image extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="width_size", type="string" , length=255 )
     * @var string
     **/
    private $width_size;
    /**
     * @Column(name="height_size", type="string" , length=255 )
     * @var string
     **/
    private $height_size;
    /**
     * @Column(name="title", type="string" , length=255 )
     * @var string
     **/
    private $title;
    /**
     * @Column(name="creationdate", type="datetime"  )
     * @var datetime
     **/
    private $creationdate;
    /**
     * @Column(name="author", type="string" , length=255 , nullable=true)
     * @var string
     **/
    private $author;
    /**
     * @Column(name="about", type="text" , nullable=true )
     * @var text
     **/
    private $about;
    /**
     * @Column(name="image", type="string" , length=255 )
     * @var string
     **/
    private $image;
    /**
     * @Column(name="path", type="string" , length=150 , nullable=true)
     * @var string
     **/
    private $path;
    /**
     * @Column(name="isnew", type="string" , length=1 , nullable=true)
     * @var string
     **/
    private $isnew;

    /**
     * @ManyToOne(targetEntity="\Abonne")
     * , inversedBy="reporter"
     * @var \Abonne
     */
    public $abonne;
    /**
     * @Column(name="status", type="integer"  )
     * @var boolean
     **/
    private $status = 0;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->abonne = new Abonne();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getWidth_size()
    {
        return $this->width_size;
    }

    public function setWidth_size($width_size)
    {
        $this->width_size = $width_size;
    }

    public function getHeight_size()
    {
        return $this->height_size;
    }

    public function setHeight_size($height_size)
    {
        $this->height_size = $height_size;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }
    
    function getStatus() {
        return $this->status;
    }

    function setStatus($status) {
        $this->status = $status;
    }

    public function getCreationdate()
    {
        if (is_object($this->creationdate))
            return $this->creationdate;
        else
            return new DateTime($this->creationdate);
    }

    public function setCreationdate($creationdate)
    {
        if (is_object($creationdate))
            $this->creationdate = $creationdate;
        else
            $this->creationdate = new DateTime($creationdate);
    }

    public function getAuthor()
    {
        return $this->author;
    }

    public function setAuthor($author)
    {
        $this->author = $author;
    }

    public function getAbout()
    {
        return $this->about;
    }

    public function setAbout($about)
    {
        $this->about = $about;
    }

    public function getImage()
    {
        return $this->image;
    }

    public function setImage($image)
    {
        $this->image = $image;
    }

    public function getPath()
    {
        return $this->path;
    }

    public function setPath($path)
    {
        $this->path = $path;
    }

    public function getIsnew()
    {
        return $this->isnew;
    }

    public function setIsnew($isnew)
    {
        $this->isnew = $isnew;
    }

    /**
     *  manyToOne
     * @return \Abonne
     */
    function getAbonne()
    {
        $this->abonne = $this->abonne->__show();
        return $this->abonne;
    }

    function setAbonne(\Abonne $abonne)
    {
        $this->abonne = $abonne;
    }

    function getCoverimage() {
        if(file_exists(UPLOAD_DIR. $this->path ."mini/150_". $this->image))
            return "<img src='".SRC_FILE . $this->path ."mini/150_". $this->image."' >";
        else
            return "<img src='".RESSOURCE2."default/no_image.jpg' >";
    }

    public function showSmallimage() {
        return Dfile::show( "mini/270_".$this->image, $this->path);
    }

    public function showImage($mini = "") {
        return Dfile::show( $mini.$this->image, $this->path);
    }

    public function getStatusform()
    {
        $ch_publish = '';
        $ch_dust = '';

        ($this->status == '1') ? $ch_publish = 'checked' : $ch_dust = 'checked' ;

        return '  <label class="checkbox-inline">  
                  <input ' . $ch_publish . ' type="radio" name="' . $this->id . '_statu" value="1" class="statuer" >
                  publish
                </label> 
                <label class="checkbox-inline">  
                  <input ' . $ch_dust . ' type="radio" name="' . $this->id . '_statu" value="0" class="statuer" >
                  draft
                </label> ';
    }
    
    public function postimage(){

        return [
            'image' => $this->image,
            'image80' => $this->showImage("mini/80_"),
            'image150' => $this->showImage("mini/150_"),
            'image270' => $this->showImage("mini/270_"),
            'image540' => $this->showImage("540_"),
            'showimage' => $this->showImage(),
            'title' => $this->title,
            'path' => $this->path,
        ];
    }

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'width_size' => $this->width_size,
            'height_size' => $this->height_size,
            'title' => $this->title,
            'creationdate' => $this->creationdate,
            'author' => $this->author,
            'about' => $this->about,
            'image' => $this->image,
            'showimage' => $this->showImage(),
            'image80' => $this->showImage("mini/80_"),
            'image150' => $this->showImage("mini/150_"),
            'image270' => $this->showImage("mini/270_"),
            'image540' => $this->showImage("540_"),
            'path' => $this->path,
            'isnew' => $this->isnew,
            'abonne' => $this->abonne,
        ];
    }

}
