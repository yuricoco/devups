<?php 


use DClass\devups\Datatable as Datatable;

class ImageController extends Controller{

    public function gallerypage(){
        
    }

        public function setstatueAction($id, $param)
    {

        $dbal = new DBAL();
        $dbal->executeDbal(" update image set status = '$param' where id = $id ");

    }
    
    public function getnewimageAction() {

        $nbnew = Image::select()->where_str(' this.isnew = "1" and this.status = 1 ')->__countEl();
        if ($nbnew) {
            return "<span class='notif new-image'>$nbnew<span>";
        } else {
            return '';
        }
    }

    public static function getnewimageAndroid() {
        return Chapter::select()->where_str(' this.isnew = "1" ')->__countEl();
    }

    public static function renderFormWidget($id = null) {
        if($id)
            ImageForm::__renderFormWidget(Image::find($id), 'update');
        else
            ImageForm::__renderFormWidget(new Image(), 'create');
    }

    public static function renderDetail($id) {
        ImageForm::__renderDetailWidget(Image::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $image = new Image();
        if($id){
            $action = "update&id=".$id;
            $image = Image::find($id);
            //$image->collectStorage();
        }

        return ['success' => true,
            'form' => ImageForm::__renderForm($image, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Image(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10, $gallery = false){

        $qb = null;
        if($gallery){
            $qb = Image::select()->where("this.status", 1);
        }
        
        $lazyloading = $this->lazyloading(new Image(), $next, $per_page, $qb, " image.id desc ");

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $image = Image::find($id);

            return array( 'success' => true, 
                            'image' => $image,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($image_form = null){
        extract($_POST);

        $image = new Image();

        $url = Image::Dfile("image")
            ->addresize([270, 270], "270_", "images/mini/")
            ->addresize([150, 150], "150_", "images/mini/")
            ->addresize([80], "80_", "images/mini/")
            ->sanitize()
            ->moveto("images/");

        if (!$url['success']) {
            return 	array(	'success' => false,
                'error' => $url);
        }

        $image->setHeight_size($url['file']["imagesize"][1]);
        $image->setWidth_size($url['file']["imagesize"][0]);
        $image->setPath("images/");
        $image->setImage($url['file']["hashname"]);
        $image->setTitle($url['file']["name"]);
        $image->setCreationdate(new DateTime());
        $image->setIsnew(1);

        $id = $image->__insert();

        return 	array(	'success' => true,
                        'image' => $image,
                        'tablerow' => Datatable::getSingleRowRest($image),
                        'detail' => '');

    }

    public function updateAction($id, $image_form = null){
        extract($_POST);
            
        $image = $this->form_fillingentity(new Image($id), $image_form);

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'image' => $image,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $image->__update();
        return 	array(	'success' => true,
                        'image' => $image,
                        'tablerow' => Datatable::getSingleRowRest($image),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Image::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Image::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'image' => new Image(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $image = Image::find($id);

        return array('success' => true, // pour le restservice
                        'image' => $image,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
