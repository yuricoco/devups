<?php
            //ModuleImage
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$imageCtrl = new ImageController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'image.setstatus':
            g::json_encode($imageCtrl->setstatueAction($_GET['id'], Request::get("param")));
            break;
        case 'image._new':
                g::json_encode(ImageController::renderForm());
                break;
        case 'image.create':
                g::json_encode($imageCtrl->createAction());
                break;
        case 'image._edit':
                g::json_encode(ImageController::renderForm(R::get("id")));
                break;
        case 'image.update':
                g::json_encode($imageCtrl->updateAction(R::get("id")));
                break;
        case 'image._show':
                ImageController::renderDetail(R::get("id"));
                break;
        case 'image._delete':
                g::json_encode($imageCtrl->deleteAction(R::get("id")));
                break;
        case 'image._deletegroup':
                g::json_encode($imageCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'image.datatable':
                g::json_encode($imageCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
            break;
     }

