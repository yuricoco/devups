<?php 

    class ImageForm extends FormManager{

        public static function formBuilder(\Image $image, $action = null, $button = false) {
            $entitycore = new Core($image);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');

            $entitycore->field['image'] = [
                "label" => 'Image', 
			"type" => FORMTYPE_FILE,
                "value" => $image->getImage(), 
            ];
            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/imageForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Image $image, $action = null, $button = false) {
            return FormFactory::__renderForm(ImageForm::formBuilder($image, $action, $button));
        }
        
        public static function __renderFormWidget(\Image $image, $action_form = null) {
            include ROOT.Image::classpath()."Form/ImageFormWidget.php";
        }

        public static function __renderDetailWidget(\Image $image){
            include ROOT . Image::classpath() . "Form/ImageDetailWidget.php";
        }
    }
    