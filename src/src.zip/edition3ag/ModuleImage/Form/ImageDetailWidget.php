
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($image, [
['label' => 'Width_size', 'value' => 'width_size'], 
['label' => 'Height_size', 'value' => 'height_size'], 
['label' => 'Title', 'value' => 'title'], 
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Author', 'value' => 'author'], 
['label' => 'About', 'value' => 'about'], 
['label' => 'Image', 'value' => 'image'], 
['label' => 'Path', 'value' => 'path'], 
['label' => 'Isnew', 'value' => 'isnew'], 
['label' => 'Abonne', 'value' => 'Abonne.id']
]); ?>

        </div>
			