
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($comment, [
['label' => 'Pseudo', 'value' => 'pseudo'], 
['label' => 'Email', 'value' => 'email'], 
['label' => 'Comment', 'value' => 'comment'], 
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Seen', 'value' => 'seen'], 
['label' => 'Chapter', 'value' => 'Chapter.id'], 
['label' => 'Abonne', 'value' => 'Abonne.id'], 
['label' => 'Image', 'value' => 'Image.id']
]); ?>

        </div>
			