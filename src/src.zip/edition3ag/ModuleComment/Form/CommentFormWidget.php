<?php //Form::addcss('Ressource/js/comment.css') ?>

<?= Form::open($comment, ["action" => "$action_form", "method" => "post"]) ?>

<div class='form-group'>
    <label for='pseudo'>Pseudo</label>
    <?= Form::input('pseudo', $comment->getPseudo(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='email'>Email</label>
    <?= Form::input('email', $comment->getEmail(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='comment'>Comment</label>
    <?= Form::textarea('comment', $comment->getComment(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='creationdate'>Creationdate</label>
    <?= Form::input('creationdate', $comment->getCreationdate(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='seen'>Seen</label>
    <?= Form::input('seen', $comment->getSeen(), ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='chapter'>Chapter</label>

    <?= Form::select('chapter',
        FormManager::Options_Helper('id', Chapter::allrows()),
        $comment->getChapter()->getId(),
        ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='abonne'>Abonne</label>

    <?= Form::select('abonne',
        FormManager::Options_Helper('id', Abonne::allrows()),
        $comment->getAbonne()->getId(),
        ['class' => 'form-control']); ?>
</div>
<div class='form-group'>
    <label for='image'>Image</label>

    <?= Form::select('image',
        FormManager::Options_Helper('id', Image::allrows()),
        $comment->getImage()->getId(),
        ['class' => 'form-control']); ?>
</div>


<?= Form::submit("save", ['class' => 'btn btn-success']) ?>

<?= Form::close() ?>

<?= Form::addDformjs() ?>
<?= Form::addjs('Ressource/js/commentForm.js') ?>
    