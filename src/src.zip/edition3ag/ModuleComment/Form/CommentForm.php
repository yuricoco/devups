<?php 

    class CommentForm extends FormManager{

        public static function formBuilder(\Comment $comment, $action = null, $button = false) {
            $entitycore = new Core($comment);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['pseudo'] = [
                "label" => 'Pseudo', 
			"type" => FORMTYPE_TEXT, 
                "value" => $comment->getPseudo(), 
            ];

            $entitycore->field['email'] = [
                "label" => 'Email', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $comment->getEmail(), 
            ];

            $entitycore->field['comment'] = [
                "label" => 'Comment', 
			"type" => FORMTYPE_TEXTAREA, 
                "value" => $comment->getComment(), 
            ];

            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate', 
			"type" => FORMTYPE_DATE, 
                "value" => $comment->getCreationdate(), 
            ];

            $entitycore->field['seen'] = [
                "label" => 'Seen', 
			"type" => FORMTYPE_RADIO, 
                "value" => $comment->getSeen(), 
            ];

                $entitycore->field['chapter'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $comment->getChapter()->getId(),
                    "label" => 'Chapter',
                    "options" => FormManager::Options_Helper('id', Chapter::allrows()),
                ];

                $entitycore->field['abonne'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $comment->getAbonne()->getId(),
                    "label" => 'Abonne',
                    "options" => FormManager::Options_Helper('id', Abonne::allrows()),
                ];

                $entitycore->field['image'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $comment->getImage()->getId(),
                    "label" => 'Image',
                    "options" => FormManager::Options_Helper('id', Image::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/commentForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Comment $comment, $action = null, $button = false) {
            return FormFactory::__renderForm(CommentForm::formBuilder($comment, $action, $button));
        }
        
        public static function __renderFormWidget(\Comment $comment, $action_form = null) {
            include ROOT.Comment::classpath()."Form/CommentFormWidget.php";
        }

        public static function __renderDetailWidget(\Comment $comment){
            include ROOT . Comment::classpath() . "Form/CommentDetailWidget.php";
        }
    }
    