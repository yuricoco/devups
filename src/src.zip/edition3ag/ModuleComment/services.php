<?php
            //ModuleComment
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$commentCtrl = new CommentController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'comment._new':
                g::json_encode(CommentController::renderForm());
                break;
        case 'comment.create':
                g::json_encode($commentCtrl->createAction());
                break;
        case 'comment._edit':
                g::json_encode(CommentController::renderForm(R::get("id")));
                break;
        case 'comment.update':
                g::json_encode($commentCtrl->updateAction(R::get("id")));
                break;
        case 'comment._show':
                CommentController::renderDetail(R::get("id"));
                break;
        case 'comment._delete':
                g::json_encode($commentCtrl->deleteAction(R::get("id")));
                break;
        case 'comment._deletegroup':
                g::json_encode($commentCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'comment.datatable':
                g::json_encode($commentCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
            break;
     }

