<?php
            //ModuleComment
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleComment</a> ');

    
        		$commentCtrl = new CommentController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'comment/index':
        Genesis::renderView('comment.index',  $commentCtrl->listAction());
        break;					
    case 'comment/create':
        Genesis::renderView( 'comment.form', $commentCtrl->createAction(), true);
        break;					
    case 'comment/update':
        Genesis::renderView( 'comment.form',  $commentCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    