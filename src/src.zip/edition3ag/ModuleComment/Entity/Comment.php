<?php

/**
 * @Entity @Table(name="comment")
 * */
class Comment extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="pseudo", type="string" , length=255 )
     * @var string
     **/
    private $pseudo;
    /**
     * @Column(name="email", type="string" , length=255 , nullable=true)
     * @var string
     **/
    private $email;
    /**
     * @Column(name="comment", type="text"  )
     * @var text
     **/
    private $comment;
    /**
     * @Column(name="creationdate", type="datetime"  )
     * @var datetime
     **/
    private $creationdate;
    /**
     * @Column(name="seen", type="boolean"  )
     * @var boolean
     **/
    private $seen = 0;

    /**
     * @ManyToOne(targetEntity="\Chapter")
     * , inversedBy="reporter"
     * @var \Chapter
     */
    public $chapter;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    public $user;

    public static function lastcomment(){
//        $nb =  User::select()->where("this._date", date("Y-m-d"))->__countEl();
//        return $nb;
        return Comment::select()->where("this.creationdate")
            ->between(getadmin()->getLastloginAt(), date("Y-m-d H:i:s"))
            ->__countEl();
    }

    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->chapter = new Chapter();
        $this->user = new User();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getPseudo()
    {
        return $this->pseudo;
    }

    public function setPseudo($pseudo)
    {
        $this->pseudo = $pseudo;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getComment()
    {
        return $this->comment;
    }

    public function setComment($comment)
    {
        $this->comment = $comment;
    }


    public function getCreationdate()
    {
        return $this->creationdate;
    }

    public function getDate()
    {
        if (is_object($this->creationdate))
            return $this->creationdate;
        else
            return new DateTime($this->creationdate);
    }

    public function setCreationdate($creationdate)
    {
        if (is_object($creationdate))
            $this->creationdate = $creationdate;
        else
            $this->creationdate = new DateTime($creationdate);
    }

    public function getSeen()
    {
        return $this->seen;
    }

    public function setSeen($seen)
    {
        $this->seen = $seen;
    }

    /**
     *  manyToOne
     * @return \Chapter
     */
    function getChapter()
    {
        $this->chapter = $this->chapter->__show();
        return $this->chapter;
    }

    function setChapter(\Chapter $chapter)
    {
        $this->chapter = $chapter;
    }

    /**
     *  manyToOne
     * @return \User
     */
    function getUser()
    {
        $this->user = $this->user->__show();
        return $this->user;
    }

    function setUser(\User $user)
    {
        $this->user = $user;
    }


    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'pseudo' => $this->pseudo,
            'email' => $this->email,
            'comment' => $this->comment,
            'date' => $this->getDate()->format("Y M d"),
            'seen' => $this->seen,
            'chapter' => $this->chapter,
        ];
    }

}
