<?php 


use DClass\devups\Datatable as Datatable;

class CommentController extends Controller{

    public static function listCommentChapitreAction($chapterid) {

        return Comment::select()->where("chapter_id", $chapterid)->limit(5)->__getAll(); //Detail de l'action ou message d'erreur ou de succes
    }

    public static function renderFormWidget($id = null) {
        if($id)
            CommentForm::__renderFormWidget(Comment::find($id), 'update');
        else
            CommentForm::__renderFormWidget(new Comment(), 'create');
    }

    public static function renderDetail($id) {
        CommentForm::__renderDetailWidget(Comment::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $comment = new Comment();
        if($id){
            $action = "update&id=".$id;
            $comment = Comment::find($id);
            //$comment->collectStorage();
        }

        return ['success' => true,
            'form' => CommentForm::__renderForm($comment, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Comment(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Comment(), $next, $per_page, null, " this.id desc ");

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $comment = Comment::find($id);

            return array( 'success' => true, 
                            'comment' => $comment,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($comment_form = null){
        extract($_POST);

        $comment = $this->form_fillingentity(new Comment(), $comment_form);

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'comment' => $comment,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }

        $comment->setCreationdate(date("Y-m-d H:i:s"));
        $id = $comment->__insert();
        return 	array(	'success' => true,
                        'comment' => $comment,
                        //'tablerow' => Datatable::getSingleRowRest($comment),
                        'detail' => '');

    }

    public function updateAction($id, $comment_form = null){
        extract($_POST);
            
        $comment = $this->form_fillingentity(new Comment($id), $comment_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'comment' => $comment,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $comment->__update();
        return 	array(	'success' => true,
                        'comment' => $comment,
                        'tablerow' => Datatable::getSingleRowRest($comment),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Comment::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Comment::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'comment' => new Comment(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $comment = Comment::find($id);

        return array('success' => true, // pour le restservice
                        'comment' => $comment,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
