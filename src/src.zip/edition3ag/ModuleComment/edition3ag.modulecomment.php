<?php 
    require 'Entity/Comment.php';
    //require 'Dao/CommentDAO.php';
    require 'Form/CommentForm.php';
    require 'Controller/CommentController.php';
    //require 'Genesis/CommentGenesis.php';
