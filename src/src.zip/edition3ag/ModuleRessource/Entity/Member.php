<?php

/**
 * @Entity @Table(name="member")
 * */
class Member extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="pseudo", type="string" , length=255 )
     * @var string
     **/
    private $pseudo;
    /**
     * @Column(name="firstname", type="string" , length=255 )
     * @var string
     **/
    private $firstname;
    /**
     * @Column(name="lastname", type="string" , length=255 )
     * @var string
     **/
    private $lastname;
    /**
     * @Column(name="email", type="string" , length=255 )
     * @var string
     **/
    private $email;
    /**
     * @Column(name="phonenumber", type="string" , length=25 , nullable=true)
     * @var string
     **/
    private $phonenumber;
    /**
     * @Column(name="creationdate", type="date"  )
     * @var date
     **/
    private $creationdate;
    /**
     * @Column(name="birthdate", type="date"  , nullable=true)
     * @var date
     **/
    private $birthdate;
    /**
     * @Column(name="sexe", type="boolean"  )
     * @var boolean
     **/
    private $sexe;

    /**
     * @ManyToOne(targetEntity="\Country")
     * , inversedBy="reporter"
     * @var \Country
     */
    public $country;

    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->country = new Country();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getPseudo()
    {
        return $this->pseudo;
    }

    public function setPseudo($pseudo)
    {
        $this->pseudo = $pseudo;
    }

    public function getFirstname()
    {
        return $this->firstname;
    }

    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;
    }

    public function getLastname()
    {
        return $this->lastname;
    }

    public function setLastname($lastname)
    {
        $this->lastname = $lastname;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getSexe()
    {
        return $this->sexe;
    }

    public function setSexe($sexe)
    {
        $this->sexe = $sexe;
    }

    /**
     * @return string
     */
    public function getPhonenumber()
    {
        return $this->phonenumber;
    }

    /**
     * @param string $phonenumber
     */
    public function setPhonenumber($phonenumber)
    {
        $this->phonenumber = $phonenumber;
    }

    /**
     * @return date
     */
    public function getCreationdate()
    {
        return $this->creationdate;
    }

    /**
     * @param date $creationdate
     */
    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    /**
     * @return date
     */
    public function getBirthdate()
    {
        return $this->birthdate;
    }

    /**
     * @param date $birthdate
     */
    public function setBirthdate($birthdate)
    {
        $this->birthdate = $birthdate;
    }

    /**
     *  manyToOne
     * @return \Country
     */
    function getCountry()
    {
        $this->country = $this->country->__show();
        return $this->country;
    }

    function setCountry(\Country $country)
    {
        $this->country = $country;
    }

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'pseudo' => $this->pseudo,
            'firstname' => $this->firstname,
            'lastname' => $this->lastname,
            'email' => $this->email,
            'sexe' => $this->sexe,
            'Country' => $this->country,
        ];
    }

}
