<?php 
    /**
     * @Entity @Table(name="abonne")
     * */
    class Abonne extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="pseudo", type="string" , length=255 )
         * @var string
         **/
        private $pseudo;
        /**
         * @Column(name="date_naissance", type="date"  , nullable=true)
         * @var date
         **/
        private $date_naissance;
        /**
         * @Column(name="sexe", type="boolean"  )
         * @var boolean
         **/
        private $sexe;
        /**
         * @Column(name="ischecker", type="boolean"  )
         * @var boolean
         **/
        private $ischecker;
        /**
         * @Column(name="istraductor", type="boolean"  )
         * @var boolean
         **/
        private $istraductor; 
        
        /**
         * @ManyToOne(targetEntity="\Country")
         * , inversedBy="reporter"
         * @var \Country
         */
        public $country;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->country = new Country();
}

        public function getId() {
            return $this->id;
        }
        public function getPseudo() {
            return $this->pseudo;
        }

        public function setPseudo($pseudo) {
            $this->pseudo = $pseudo;
        }
        

        public function getDate_naissance() {
                if(is_object($this->date_naissance))
                        return $this->date_naissance;
                else
                        return new DateTime($this->date_naissance);
        }

        public function setDate_naissance($date_naissance) {
                    if(is_object($date_naissance))
                            $this->date_naissance = $date_naissance;
                    else
                            $this->date_naissance = new DateTime($date_naissance);
        }
        public function getSexe() {
            return $this->sexe;
        }

        public function setSexe($sexe) {
            $this->sexe = $sexe;
        }
        
        public function getIschecker() {
            return $this->ischecker;
        }

        public function setIschecker($ischecker) {
            $this->ischecker = $ischecker;
        }
        
        public function getIstraductor() {
            return $this->istraductor;
        }

        public function setIstraductor($istraductor) {
            $this->istraductor = $istraductor;
        }
        
        /**
         *  manyToOne
         *	@return \Country
         */
        function getCountry() {
            $this->country = $this->country->__show();
            return $this->country;
        }
        function setCountry(\Country $country) {
            $this->country = $country;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'pseudo' => $this->pseudo,
                                'date_naissance' => $this->date_naissance,
                                'sexe' => $this->sexe,
                                'ischecker' => $this->ischecker,
                                'istraductor' => $this->istraductor,
                                'Country' => $this->country,
                ];
        }
        
}
