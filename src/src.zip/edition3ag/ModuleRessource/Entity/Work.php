<?php 
    /**
     * @Entity @Table(name="work")
     * */
    class Work extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="title", type="string" , length=25 )
         * @var string
         **/
        private $title;
        /**
         * @Column(name="creationdate", type="date"  )
         * @var date
         **/
        private $creationdate; 
        
        /**
         * @ManyToOne(targetEntity="\Abonne")
         * , inversedBy="reporter"
         * @var \Abonne
         */
        public $abonne;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->abonne = new Abonne();
}

        public function getId() {
            return $this->id;
        }
        public function getTitle() {
            return $this->title;
        }

        public function setTitle($title) {
            $this->title = $title;
        }
        

        public function getCreationdate() {
                if(is_object($this->creationdate))
                        return $this->creationdate;
                else
                        return new DateTime($this->creationdate);
        }

        public function setCreationdate($creationdate) {
                    if(is_object($creationdate))
                            $this->creationdate = $creationdate;
                    else
                            $this->creationdate = new DateTime($creationdate);
        }
        /**
         *  manyToOne
         *	@return \Abonne
         */
        function getAbonne() {
            $this->abonne = $this->abonne->__show();
            return $this->abonne;
        }
        function setAbonne(\Abonne $abonne) {
            $this->abonne = $abonne;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'title' => $this->title,
                                'creationdate' => $this->creationdate,
                                'abonne' => $this->abonne,
                ];
        }
        
}
