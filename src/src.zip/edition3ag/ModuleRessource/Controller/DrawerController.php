<?php 


use DClass\devups\Datatable as Datatable;

class DrawerController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            DrawerForm::__renderFormWidget(Drawer::find($id), 'update');
        else
            DrawerForm::__renderFormWidget(new Drawer(), 'create');
    }

    public static function renderDetail($id) {
        DrawerForm::__renderDetailWidget(Drawer::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $drawer = new Drawer();
        if($id){
            $action = "update&id=".$id;
            $drawer = Drawer::find($id);
            //$drawer->collectStorage();
        }

        return ['success' => true,
            'form' => DrawerForm::__renderForm($drawer, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Drawer(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Drawer(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $drawer = Drawer::find($id);

            return array( 'success' => true, 
                            'drawer' => $drawer,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($drawer_form = null){
        extract($_POST);

        $drawer = $this->form_fillingentity(new Drawer(), $drawer_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'drawer' => $drawer,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $drawer->__insert();
        return 	array(	'success' => true,
                        'drawer' => $drawer,
                        'tablerow' => Datatable::getSingleRowRest($drawer),
                        'detail' => '');

    }

    public function updateAction($id, $drawer_form = null){
        extract($_POST);
            
        $drawer = $this->form_fillingentity(new Drawer($id), $drawer_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'drawer' => $drawer,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $drawer->__update();
        return 	array(	'success' => true,
                        'drawer' => $drawer,
                        'tablerow' => Datatable::getSingleRowRest($drawer),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Drawer::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Drawer::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'drawer' => new Drawer(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $drawer = Drawer::find($id);

        return array('success' => true, // pour le restservice
                        'drawer' => $drawer,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
