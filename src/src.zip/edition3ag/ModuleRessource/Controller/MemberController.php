<?php 


use DClass\devups\Datatable as Datatable;

class MemberController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            MemberForm::__renderFormWidget(Member::find($id), 'update');
        else
            MemberForm::__renderFormWidget(new Member(), 'create');
    }

    public static function renderDetail($id) {
        MemberForm::__renderDetailWidget(Member::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $member = new Member();
        if($id){
            $action = "update&id=".$id;
            $member = Member::find($id);
            //$member->collectStorage();
        }

        return ['success' => true,
            'form' => MemberForm::__renderForm($member, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Member(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Member(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $member = Member::find($id);

            return array( 'success' => true, 
                            'member' => $member,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($member_form = null){
        extract($_POST);

        $member = $this->form_fillingentity(new Member(), $member_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'member' => $member,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $member->__insert();
        return 	array(	'success' => true,
                        'member' => $member,
                        'tablerow' => Datatable::getSingleRowRest($member),
                        'detail' => '');

    }

    public function updateAction($id, $member_form = null){
        extract($_POST);
            
        $member = $this->form_fillingentity(new Member($id), $member_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'member' => $member,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $member->__update();
        return 	array(	'success' => true,
                        'member' => $member,
                        'tablerow' => Datatable::getSingleRowRest($member),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Member::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Member::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'member' => new Member(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $member = Member::find($id);

        return array('success' => true, // pour le restservice
                        'member' => $member,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
