<?php 


use DClass\devups\Datatable as Datatable;

class AbonneController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            AbonneForm::__renderFormWidget(Abonne::find($id), 'update');
        else
            AbonneForm::__renderFormWidget(new Abonne(), 'create');
    }

    public static function renderDetail($id) {
        AbonneForm::__renderDetailWidget(Abonne::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $abonne = new Abonne();
        if($id){
            $action = "update&id=".$id;
            $abonne = Abonne::find($id);
            //$abonne->collectStorage();
        }

        return ['success' => true,
            'form' => AbonneForm::__renderForm($abonne, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Abonne(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Abonne(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $abonne = Abonne::find($id);

            return array( 'success' => true, 
                            'abonne' => $abonne,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($abonne_form = null){
        extract($_POST);

        $abonne = $this->form_fillingentity(new Abonne(), $abonne_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'abonne' => $abonne,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $abonne->__insert();
        return 	array(	'success' => true,
                        'abonne' => $abonne,
                        'tablerow' => Datatable::getSingleRowRest($abonne),
                        'detail' => '');

    }

    public function updateAction($id, $abonne_form = null){
        extract($_POST);
            
        $abonne = $this->form_fillingentity(new Abonne($id), $abonne_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'abonne' => $abonne,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $abonne->__update();
        return 	array(	'success' => true,
                        'abonne' => $abonne,
                        'tablerow' => Datatable::getSingleRowRest($abonne),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Abonne::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Abonne::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'abonne' => new Abonne(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $abonne = Abonne::find($id);

        return array('success' => true, // pour le restservice
                        'abonne' => $abonne,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
