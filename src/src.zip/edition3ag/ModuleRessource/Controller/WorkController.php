<?php 


use DClass\devups\Datatable as Datatable;

class WorkController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            WorkForm::__renderFormWidget(Work::find($id), 'update');
        else
            WorkForm::__renderFormWidget(new Work(), 'create');
    }

    public static function renderDetail($id) {
        WorkForm::__renderDetailWidget(Work::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $work = new Work();
        if($id){
            $action = "update&id=".$id;
            $work = Work::find($id);
            //$work->collectStorage();
        }

        return ['success' => true,
            'form' => WorkForm::__renderForm($work, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Work(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Work(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $work = Work::find($id);

            return array( 'success' => true, 
                            'work' => $work,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($work_form = null){
        extract($_POST);

        $work = $this->form_fillingentity(new Work(), $work_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'work' => $work,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $work->__insert();
        return 	array(	'success' => true,
                        'work' => $work,
                        'tablerow' => Datatable::getSingleRowRest($work),
                        'detail' => '');

    }

    public function updateAction($id, $work_form = null){
        extract($_POST);
            
        $work = $this->form_fillingentity(new Work($id), $work_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'work' => $work,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $work->__update();
        return 	array(	'success' => true,
                        'work' => $work,
                        'tablerow' => Datatable::getSingleRowRest($work),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Work::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Work::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'work' => new Work(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $work = Work::find($id);

        return array('success' => true, // pour le restservice
                        'work' => $work,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
