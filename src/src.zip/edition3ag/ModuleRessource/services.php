<?php
            //ModuleRessource
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$abonneCtrl = new AbonneController();
		$memberCtrl = new MemberController();
		$workCtrl = new WorkController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'abonne._new':
                g::json_encode(AbonneController::renderForm());
                break;
        case 'abonne.create':
                g::json_encode($abonneCtrl->createAction());
                break;
        case 'abonne._edit':
                g::json_encode(AbonneController::renderForm(R::get("id")));
                break;
        case 'abonne.update':
                g::json_encode($abonneCtrl->updateAction(R::get("id")));
                break;
        case 'abonne._show':
                AbonneController::renderDetail(R::get("id"));
                break;
        case 'abonne._delete':
                g::json_encode($abonneCtrl->deleteAction(R::get("id")));
                break;
        case 'abonne._deletegroup':
                g::json_encode($abonneCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'abonne.datatable':
                g::json_encode($abonneCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'member._new':
                g::json_encode(MemberController::renderForm());
                break;
        case 'member.create':
                g::json_encode($memberCtrl->createAction());
                break;
        case 'member._edit':
                g::json_encode(MemberController::renderForm(R::get("id")));
                break;
        case 'member.update':
                g::json_encode($memberCtrl->updateAction(R::get("id")));
                break;
        case 'member._show':
                MemberController::renderDetail(R::get("id"));
                break;
        case 'member._delete':
                g::json_encode($memberCtrl->deleteAction(R::get("id")));
                break;
        case 'member._deletegroup':
                g::json_encode($memberCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'member.datatable':
                g::json_encode($memberCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'work._new':
                g::json_encode(WorkController::renderForm());
                break;
        case 'work.create':
                g::json_encode($workCtrl->createAction());
                break;
        case 'work._edit':
                g::json_encode(WorkController::renderForm(R::get("id")));
                break;
        case 'work.update':
                g::json_encode($workCtrl->updateAction(R::get("id")));
                break;
        case 'work._show':
                WorkController::renderDetail(R::get("id"));
                break;
        case 'work._delete':
                g::json_encode($workCtrl->deleteAction(R::get("id")));
                break;
        case 'work._deletegroup':
                g::json_encode($workCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'work.datatable':
                g::json_encode($workCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
            break;
     }

