<?php 
    require 'Entity/Abonne.php';
    //require 'Dao/AbonneDAO.php';
    require 'Form/AbonneForm.php';
    require 'Controller/AbonneController.php';
    //require 'Genesis/AbonneGenesis.php';

    require 'Entity/Member.php';
    //require 'Dao/MemberDAO.php';
    require 'Form/MemberForm.php';
    require 'Controller/MemberController.php';
    //require 'Genesis/MemberGenesis.php';

    require 'Entity/Work.php';
    //require 'Dao/WorkDAO.php';
    require 'Form/WorkForm.php';
    require 'Controller/WorkController.php';
    //require 'Genesis/WorkGenesis.php';
