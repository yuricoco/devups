<?php
            //ModuleRessource
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleRessource</a> ');

    
        		$abonneCtrl = new AbonneController();		$memberCtrl = new MemberController();		$workCtrl = new WorkController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'abonne/index':
        Genesis::renderView('abonne.index',  $abonneCtrl->listAction());
        break;					
    case 'abonne/create':
        Genesis::renderView( 'abonne.form', $abonneCtrl->createAction(), true);
        break;					
    case 'abonne/update':
        Genesis::renderView( 'abonne.form',  $abonneCtrl->updateAction($_GET['id']), true);
        break;


    case 'member/index':
        Genesis::renderView('member.index',  $memberCtrl->listAction());
        break;					
    case 'member/create':
        Genesis::renderView( 'member.form', $memberCtrl->createAction(), true);
        break;					
    case 'member/update':
        Genesis::renderView( 'member.form',  $memberCtrl->updateAction($_GET['id']), true);
        break;


    case 'work/index':
        Genesis::renderView('work.index',  $workCtrl->listAction());
        break;					
    case 'work/create':
        Genesis::renderView( 'work.form', $workCtrl->createAction(), true);
        break;					
    case 'work/update':
        Genesis::renderView( 'work.form',  $workCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    