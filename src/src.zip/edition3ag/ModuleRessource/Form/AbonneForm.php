<?php 

    class AbonneForm extends FormManager{

        public static function formBuilder(\Abonne $abonne, $action = null, $button = false) {
            $entitycore = new Core($abonne);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['pseudo'] = [
                "label" => 'Pseudo', 
			"type" => FORMTYPE_TEXT, 
                "value" => $abonne->getPseudo(), 
            ];

            $entitycore->field['date_naissance'] = [
                "label" => 'Date_naissance', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_DATE, 
                "value" => $abonne->getDate_naissance(), 
            ];

            $entitycore->field['sexe'] = [
                "label" => 'Sexe', 
			"type" => FORMTYPE_RADIO, 
                "value" => $abonne->getSexe(), 
            ];

            $entitycore->field['ischecker'] = [
                "label" => 'Ischecker', 
			"type" => FORMTYPE_RADIO, 
                "value" => $abonne->getIschecker(), 
            ];

            $entitycore->field['istraductor'] = [
                "label" => 'Istraductor', 
			"type" => FORMTYPE_RADIO, 
                "value" => $abonne->getIstraductor(), 
            ];

                $entitycore->field['Country'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $abonne->getCountry()->getId(),
                    "label" => 'Country',
                    "options" => FormManager::Options_Helper('id', Country::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/abonneForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Abonne $abonne, $action = null, $button = false) {
            return FormFactory::__renderForm(AbonneForm::formBuilder($abonne, $action, $button));
        }
        
        public static function __renderFormWidget(\Abonne $abonne, $action_form = null) {
            include ROOT.Abonne::classpath()."Form/AbonneFormWidget.php";
        }

        public static function __renderDetailWidget(\Abonne $abonne){
            include ROOT . Abonne::classpath() . "Form/AbonneDetailWidget.php";
        }
    }
    