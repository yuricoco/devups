<?php 

    class MemberForm extends FormManager{

        public static function formBuilder(\Member $member, $action = null, $button = false) {
            $entitycore = new Core($member);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['pseudo'] = [
                "label" => 'Pseudo', 
			"type" => FORMTYPE_TEXT, 
                "value" => $member->getPseudo(), 
            ];

            $entitycore->field['firstname'] = [
                "label" => 'Firstname', 
			"type" => FORMTYPE_TEXT, 
                "value" => $member->getFirstname(), 
            ];

            $entitycore->field['lastname'] = [
                "label" => 'Lastname', 
			"type" => FORMTYPE_TEXT, 
                "value" => $member->getLastname(), 
            ];

            $entitycore->field['email'] = [
                "label" => 'Email', 
			"type" => FORMTYPE_TEXT, 
                "value" => $member->getEmail(), 
            ];

            $entitycore->field['tel'] = [
                "label" => 'Tel', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $member->getTel(), 
            ];

            $entitycore->field['date_ajout'] = [
                "label" => 'Date_ajout', 
			"type" => FORMTYPE_DATE, 
                "value" => $member->getDate_ajout(), 
            ];

            $entitycore->field['date_naissance'] = [
                "label" => 'Date_naissance', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_DATE, 
                "value" => $member->getDate_naissance(), 
            ];

            $entitycore->field['sexe'] = [
                "label" => 'Sexe', 
			"type" => FORMTYPE_RADIO, 
                "value" => $member->getSexe(), 
            ];

                $entitycore->field['Country'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $member->getCountry()->getId(),
                    "label" => 'Country',
                    "options" => FormManager::Options_Helper('id', Country::allrows()),
                ];

                $entitycore->field['abonne'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $member->getAbonne()->getId(),
                    "label" => 'Abonne',
                    "options" => FormManager::Options_Helper('id', Abonne::allrows()),
                ];

                $entitycore->field['image'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $member->getImage()->getId(),
                    "label" => 'Image',
                    "options" => FormManager::Options_Helper('id', Image::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/memberForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Member $member, $action = null, $button = false) {
            return FormFactory::__renderForm(MemberForm::formBuilder($member, $action, $button));
        }
        
        public static function __renderFormWidget(\Member $member, $action_form = null) {
            include ROOT.Member::classpath()."Form/MemberFormWidget.php";
        }

        public static function __renderDetailWidget(\Member $member){
            include ROOT . Member::classpath() . "Form/MemberDetailWidget.php";
        }
    }
    