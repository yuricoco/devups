<?php 

    class DrawerForm extends FormManager{

        public static function formBuilder(\Drawer $drawer, $action = null, $button = false) {
            $entitycore = new Core($drawer);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['pseudo'] = [
                "label" => 'Pseudo', 
			"type" => FORMTYPE_TEXT, 
                "value" => $drawer->getPseudo(), 
            ];

            $entitycore->field['firstname'] = [
                "label" => 'Firstname', 
			"type" => FORMTYPE_TEXT, 
                "value" => $drawer->getFirstname(), 
            ];

            $entitycore->field['lastname'] = [
                "label" => 'Lastname', 
			"type" => FORMTYPE_TEXT, 
                "value" => $drawer->getLastname(), 
            ];

            $entitycore->field['email'] = [
                "label" => 'Email', 
			"type" => FORMTYPE_TEXT, 
                "value" => $drawer->getEmail(), 
            ];

            $entitycore->field['tel'] = [
                "label" => 'Tel', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $drawer->getTel(), 
            ];

            $entitycore->field['date_ajout'] = [
                "label" => 'Date_ajout', 
			"type" => FORMTYPE_DATE, 
                "value" => $drawer->getDate_ajout(), 
            ];

            $entitycore->field['date_naissance'] = [
                "label" => 'Date_naissance', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_DATE, 
                "value" => $drawer->getDate_naissance(), 
            ];

            $entitycore->field['sexe'] = [
                "label" => 'Sexe', 
			"type" => FORMTYPE_RADIO, 
                "value" => $drawer->getSexe(), 
            ];

                $entitycore->field['Country'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $drawer->getCountry()->getId(),
                    "label" => 'Country',
                    "options" => FormManager::Options_Helper('id', Country::allrows()),
                ];

                $entitycore->field['abonne'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $drawer->getAbonne()->getId(),
                    "label" => 'Abonne',
                    "options" => FormManager::Options_Helper('id', Abonne::allrows()),
                ];

                $entitycore->field['image'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $drawer->getImage()->getId(),
                    "label" => 'Image',
                    "options" => FormManager::Options_Helper('id', Image::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/drawerForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Drawer $drawer, $action = null, $button = false) {
            return FormFactory::__renderForm(DrawerForm::formBuilder($drawer, $action, $button));
        }
        
        public static function __renderFormWidget(\Drawer $drawer, $action_form = null) {
            include ROOT.Drawer::classpath()."Form/DrawerFormWidget.php";
        }

        public static function __renderDetailWidget(\Drawer $drawer){
            include ROOT . Drawer::classpath() . "Form/DrawerDetailWidget.php";
        }
    }
    