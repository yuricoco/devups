
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($drawer, [
['label' => 'Pseudo', 'value' => 'pseudo'], 
['label' => 'Firstname', 'value' => 'firstname'], 
['label' => 'Lastname', 'value' => 'lastname'], 
['label' => 'Email', 'value' => 'email'], 
['label' => 'Tel', 'value' => 'tel'], 
['label' => 'Date_ajout', 'value' => 'date_ajout'], 
['label' => 'Date_naissance', 'value' => 'date_naissance'], 
['label' => 'Sexe', 'value' => 'sexe'], 
['label' => 'Country', 'value' => 'Country.id'],
['label' => 'Abonne', 'value' => 'Abonne.id'], 
['label' => 'Image', 'value' => 'Image.id']
]); ?>

        </div>
			