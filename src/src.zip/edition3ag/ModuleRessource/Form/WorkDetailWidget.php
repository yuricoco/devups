
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($work, [
['label' => 'Title', 'value' => 'title'], 
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Abonne', 'value' => 'Abonne.id']
]); ?>

        </div>
			