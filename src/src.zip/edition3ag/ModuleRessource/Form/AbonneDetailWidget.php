
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($abonne, [
['label' => 'Pseudo', 'value' => 'pseudo'], 
['label' => 'Date_naissance', 'value' => 'date_naissance'], 
['label' => 'Sexe', 'value' => 'sexe'], 
['label' => 'Ischecker', 'value' => 'ischecker'], 
['label' => 'Istraductor', 'value' => 'istraductor'], 
['label' => 'Country', 'value' => 'Country.id']
]); ?>

        </div>
			