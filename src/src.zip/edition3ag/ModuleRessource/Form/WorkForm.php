<?php 

    class WorkForm extends FormManager{

        public static function formBuilder(\Work $work, $action = null, $button = false) {
            $entitycore = new Core($work);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['title'] = [
                "label" => 'Title', 
			"type" => FORMTYPE_TEXT, 
                "value" => $work->getTitle(), 
            ];

            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate', 
			"type" => FORMTYPE_DATE, 
                "value" => $work->getCreationdate(), 
            ];

                $entitycore->field['abonne'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $work->getAbonne()->getId(),
                    "label" => 'Abonne',
                    "options" => FormManager::Options_Helper('id', Abonne::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/workForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Work $work, $action = null, $button = false) {
            return FormFactory::__renderForm(WorkForm::formBuilder($work, $action, $button));
        }
        
        public static function __renderFormWidget(\Work $work, $action_form = null) {
            include ROOT.Work::classpath()."Form/WorkFormWidget.php";
        }

        public static function __renderDetailWidget(\Work $work){
            include ROOT . Work::classpath() . "Form/WorkDetailWidget.php";
        }
    }
    