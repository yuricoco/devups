
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($storage, [
['label' => 'Name', 'value' => 'name']
]); ?>

        </div>
			