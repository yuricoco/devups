<?php 
    require 'Entity/Storage.php';
    require 'Form/StorageForm.php';
    require 'Controller/StorageController.php';
