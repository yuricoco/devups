<?php 
    require 'Entity/Kola.php';
require 'Controller/KolaController.php';

    require 'Entity/Kolacomicbook.php';
    //require 'Dao/KolacomicbookDAO.php';
    require 'Form/KolacomicbookForm.php';
    require 'Controller/KolacomicbookController.php';
    //require 'Genesis/KolacomicbookGenesis.php';

    require 'Entity/Kolachapter.php';
    //require 'Dao/KolachapterDAO.php';
    require 'Form/KolachapterForm.php';
    require 'Controller/KolachapterController.php';
    //require 'Genesis/KolachapterGenesis.php';

    require 'Entity/Kolapost.php';
    //require 'Dao/KolapostDAO.php';
    require 'Form/KolapostForm.php';
    require 'Controller/KolapostController.php';
    //require 'Genesis/KolapostGenesis.php';

    require 'Entity/Kolapostimage.php';
    //require 'Dao/KolapostimageDAO.php';
    require 'Form/KolapostimageForm.php';
    require 'Controller/KolapostimageController.php';
    //require 'Genesis/KolapostimageGenesis.php';

    require 'Entity/Kolapostcomment.php';
    //require 'Dao/KolapostcommentDAO.php';
    require 'Form/KolapostcommentForm.php';
    require 'Controller/KolapostcommentController.php';
    //require 'Genesis/KolapostcommentGenesis.php';
