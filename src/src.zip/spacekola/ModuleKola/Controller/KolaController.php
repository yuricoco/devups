<?php


use DClass\devups\Datatable as Datatable;

class KolaController extends Controller
{

    public function createforpostimageAction($userid, $postimageid)
    {
        $kola = Kolapostimage::init($userid);
        $kola->postimage = new Postimage($postimageid);
        $kola->__insert();
        return ['success' => true,
            'kola' => $kola,
            'nbkolas' => Kolapostimage::count($kola->postimage),
        ];
    }

    public function createforpostAction($userid, $postid)
    {
        $kola = Kolapost::init($userid);
        $kola->post = new Post($postid);
        $kola->__insert();
        return ['success' => true,
            'kola' => $kola,
            'nbkolas' => Kolapost::count($kola->post),
        ];
    }

    public function createforcomicbookAction($userid, $comicbookid)
    {
        $kola = Kolacomicbook::init($userid);
        $kola->comicbook = new Comicbook($comicbookid);
        $kola->__insert();

        return ['success' => true,
            'kola' => $kola,
            'nbkolas' => Kolacomicbook::count(new Comicbook($comicbookid)),
        ];
    }

    public function createforchapterAction($userid, $chapterid)
    {
        $kola = Kolachapter::init($userid);
        $kola->chapter = new Chapter($chapterid);
        $kola->__insert();
        return ['success' => true,
            'kola' => $kola,
            'nbkolas' => Kolachapter::count(new Chapter($chapterid)),
        ];
    }

    public function datatable($next, $per_page)
    {
        $lazyloading = $this->lazyloading(new Kola(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10)
    {

        $lazyloading = $this->lazyloading(new Kola(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }

    public function showAction($id)
    {

        $kola = Kola::find($id);

        return array('success' => true,
            'kola' => $kola,
            'detail' => 'detail de l\'action.');

    }

    public function createAction($kola_form = null)
    {
        extract($_POST);

        $kola = $this->form_fillingentity(new Kola(), $kola_form);


        $kola->setCreationdate(new DateTime());

        if ($this->error) {
            return array('success' => false,
                'kola' => $kola,
                'action_form' => 'create',
                'error' => $this->error);
        }

        $id = $kola->__insert();
        return array('success' => true,
            'kola' => $kola,
            'tablerow' => Datatable::getSingleRowRest($kola),
            'detail' => '');

    }

    public function updateAction($id, $kola_form = null)
    {
        extract($_POST);

        $kola = $this->form_fillingentity(new Kola($id), $kola_form);


        if ($this->error) {
            return array('success' => false,
                'kola' => $kola,
                'action_form' => 'update&id=' . $id,
                'error' => $this->error);
        }

        $kola->__update();
        return array('success' => true,
            'kola' => $kola,
            'tablerow' => Datatable::getSingleRowRest($kola),
            'detail' => '');

    }

    public function deleteAction($id)
    {

        Kola::delete($id);
        return array('success' => true, // pour le restservice
            'redirect' => 'index', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }


    public function deletegroupAction($ids)
    {

        Kola::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
            'redirect' => 'index', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction()
    {

        return array('success' => true, // pour le restservice
            'kola' => new Kola(),
            'action_form' => 'create', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id)
    {

        $kola = Kola::find($id);

        return array('success' => true, // pour le restservice
            'kola' => $kola,
            'action_form' => 'update&id=' . $id, // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
