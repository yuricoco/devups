<?php 


use DClass\devups\Datatable as Datatable;

class KolacomicbookController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            KolacomicbookForm::__renderFormWidget(Kolacomicbook::find($id), 'update');
        else
            KolacomicbookForm::__renderFormWidget(new Kolacomicbook(), 'create');
    }

    public static function renderDetail($id) {
        KolacomicbookForm::__renderDetailWidget(Kolacomicbook::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $kolacomicbook = new Kolacomicbook();
        if($id){
            $action = "update&id=".$id;
            $kolacomicbook = Kolacomicbook::find($id);
            //$kolacomicbook->collectStorage();
        }

        return ['success' => true,
            'form' => KolacomicbookForm::__renderForm($kolacomicbook, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Kolacomicbook(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Kolacomicbook(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $kolacomicbook = Kolacomicbook::find($id);

            return array( 'success' => true, 
                            'kolacomicbook' => $kolacomicbook,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($kolacomicbook_form = null){
        extract($_POST);

        $kolacomicbook = $this->form_fillingentity(new Kolacomicbook(), $kolacomicbook_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolacomicbook' => $kolacomicbook,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $kolacomicbook->__insert();
        return 	array(	'success' => true,
                        'kolacomicbook' => $kolacomicbook,
                        'tablerow' => Datatable::getSingleRowRest($kolacomicbook),
                        'detail' => '');

    }

    public function updateAction($id, $kolacomicbook_form = null){
        extract($_POST);
            
        $kolacomicbook = $this->form_fillingentity(new Kolacomicbook($id), $kolacomicbook_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolacomicbook' => $kolacomicbook,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $kolacomicbook->__update();
        return 	array(	'success' => true,
                        'kolacomicbook' => $kolacomicbook,
                        'tablerow' => Datatable::getSingleRowRest($kolacomicbook),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Kolacomicbook::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Kolacomicbook::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'kolacomicbook' => new Kolacomicbook(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $kolacomicbook = Kolacomicbook::find($id);

        return array('success' => true, // pour le restservice
                        'kolacomicbook' => $kolacomicbook,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
