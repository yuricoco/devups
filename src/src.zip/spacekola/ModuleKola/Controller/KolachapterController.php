<?php 


use DClass\devups\Datatable as Datatable;

class KolachapterController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            KolachapterForm::__renderFormWidget(Kolachapter::find($id), 'update');
        else
            KolachapterForm::__renderFormWidget(new Kolachapter(), 'create');
    }

    public static function renderDetail($id) {
        KolachapterForm::__renderDetailWidget(Kolachapter::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $kolachapter = new Kolachapter();
        if($id){
            $action = "update&id=".$id;
            $kolachapter = Kolachapter::find($id);
            //$kolachapter->collectStorage();
        }

        return ['success' => true,
            'form' => KolachapterForm::__renderForm($kolachapter, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Kolachapter(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Kolachapter(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $kolachapter = Kolachapter::find($id);

            return array( 'success' => true, 
                            'kolachapter' => $kolachapter,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($kolachapter_form = null){
        extract($_POST);

        $kolachapter = $this->form_fillingentity(new Kolachapter(), $kolachapter_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolachapter' => $kolachapter,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $kolachapter->__insert();
        return 	array(	'success' => true,
                        'kolachapter' => $kolachapter,
                        'tablerow' => Datatable::getSingleRowRest($kolachapter),
                        'detail' => '');

    }

    public function updateAction($id, $kolachapter_form = null){
        extract($_POST);
            
        $kolachapter = $this->form_fillingentity(new Kolachapter($id), $kolachapter_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolachapter' => $kolachapter,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $kolachapter->__update();
        return 	array(	'success' => true,
                        'kolachapter' => $kolachapter,
                        'tablerow' => Datatable::getSingleRowRest($kolachapter),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Kolachapter::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Kolachapter::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'kolachapter' => new Kolachapter(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $kolachapter = Kolachapter::find($id);

        return array('success' => true, // pour le restservice
                        'kolachapter' => $kolachapter,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
