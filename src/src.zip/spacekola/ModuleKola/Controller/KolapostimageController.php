<?php 


use DClass\devups\Datatable as Datatable;

class KolapostimageController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            KolapostimageForm::__renderFormWidget(Kolapostimage::find($id), 'update');
        else
            KolapostimageForm::__renderFormWidget(new Kolapostimage(), 'create');
    }

    public static function renderDetail($id) {
        KolapostimageForm::__renderDetailWidget(Kolapostimage::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $kolapostimage = new Kolapostimage();
        if($id){
            $action = "update&id=".$id;
            $kolapostimage = Kolapostimage::find($id);
            //$kolapostimage->collectStorage();
        }

        return ['success' => true,
            'form' => KolapostimageForm::__renderForm($kolapostimage, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Kolapostimage(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Kolapostimage(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $kolapostimage = Kolapostimage::find($id);

            return array( 'success' => true, 
                            'kolapostimage' => $kolapostimage,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($kolapostimage_form = null){
        extract($_POST);

        $kolapostimage = $this->form_fillingentity(new Kolapostimage(), $kolapostimage_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolapostimage' => $kolapostimage,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $kolapostimage->__insert();
        return 	array(	'success' => true,
                        'kolapostimage' => $kolapostimage,
                        'tablerow' => Datatable::getSingleRowRest($kolapostimage),
                        'detail' => '');

    }

    public function updateAction($id, $kolapostimage_form = null){
        extract($_POST);
            
        $kolapostimage = $this->form_fillingentity(new Kolapostimage($id), $kolapostimage_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolapostimage' => $kolapostimage,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $kolapostimage->__update();
        return 	array(	'success' => true,
                        'kolapostimage' => $kolapostimage,
                        'tablerow' => Datatable::getSingleRowRest($kolapostimage),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Kolapostimage::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Kolapostimage::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'kolapostimage' => new Kolapostimage(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $kolapostimage = Kolapostimage::find($id);

        return array('success' => true, // pour le restservice
                        'kolapostimage' => $kolapostimage,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
