<?php 


use DClass\devups\Datatable as Datatable;

class KolapostcommentController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            KolapostcommentForm::__renderFormWidget(Kolapostcomment::find($id), 'update');
        else
            KolapostcommentForm::__renderFormWidget(new Kolapostcomment(), 'create');
    }

    public static function renderDetail($id) {
        KolapostcommentForm::__renderDetailWidget(Kolapostcomment::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $kolapostcomment = new Kolapostcomment();
        if($id){
            $action = "update&id=".$id;
            $kolapostcomment = Kolapostcomment::find($id);
            //$kolapostcomment->collectStorage();
        }

        return ['success' => true,
            'form' => KolapostcommentForm::__renderForm($kolapostcomment, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Kolapostcomment(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Kolapostcomment(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $kolapostcomment = Kolapostcomment::find($id);

            return array( 'success' => true, 
                            'kolapostcomment' => $kolapostcomment,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($kolapostcomment_form = null){
        extract($_POST);

        $kolapostcomment = $this->form_fillingentity(new Kolapostcomment(), $kolapostcomment_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolapostcomment' => $kolapostcomment,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $kolapostcomment->__insert();
        return 	array(	'success' => true,
                        'kolapostcomment' => $kolapostcomment,
                        'tablerow' => Datatable::getSingleRowRest($kolapostcomment),
                        'detail' => '');

    }

    public function updateAction($id, $kolapostcomment_form = null){
        extract($_POST);
            
        $kolapostcomment = $this->form_fillingentity(new Kolapostcomment($id), $kolapostcomment_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolapostcomment' => $kolapostcomment,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $kolapostcomment->__update();
        return 	array(	'success' => true,
                        'kolapostcomment' => $kolapostcomment,
                        'tablerow' => Datatable::getSingleRowRest($kolapostcomment),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Kolapostcomment::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Kolapostcomment::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'kolapostcomment' => new Kolapostcomment(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $kolapostcomment = Kolapostcomment::find($id);

        return array('success' => true, // pour le restservice
                        'kolapostcomment' => $kolapostcomment,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
