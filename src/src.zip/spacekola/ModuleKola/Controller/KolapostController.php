<?php 


use DClass\devups\Datatable as Datatable;

class KolapostController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            KolapostForm::__renderFormWidget(Kolapost::find($id), 'update');
        else
            KolapostForm::__renderFormWidget(new Kolapost(), 'create');
    }

    public static function renderDetail($id) {
        KolapostForm::__renderDetailWidget(Kolapost::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $kolapost = new Kolapost();
        if($id){
            $action = "update&id=".$id;
            $kolapost = Kolapost::find($id);
            //$kolapost->collectStorage();
        }

        return ['success' => true,
            'form' => KolapostForm::__renderForm($kolapost, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Kolapost(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Kolapost(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $kolapost = Kolapost::find($id);

            return array( 'success' => true, 
                            'kolapost' => $kolapost,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($kolapost_form = null){
        extract($_POST);

        $kolapost = $this->form_fillingentity(new Kolapost(), $kolapost_form);
 

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolapost' => $kolapost,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $kolapost->__insert();
        return 	array(	'success' => true,
                        'kolapost' => $kolapost,
                        'tablerow' => Datatable::getSingleRowRest($kolapost),
                        'detail' => '');

    }

    public function updateAction($id, $kolapost_form = null){
        extract($_POST);
            
        $kolapost = $this->form_fillingentity(new Kolapost($id), $kolapost_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'kolapost' => $kolapost,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $kolapost->__update();
        return 	array(	'success' => true,
                        'kolapost' => $kolapost,
                        'tablerow' => Datatable::getSingleRowRest($kolapost),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Kolapost::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Kolapost::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'kolapost' => new Kolapost(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $kolapost = Kolapost::find($id);

        return array('success' => true, // pour le restservice
                        'kolapost' => $kolapost,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
