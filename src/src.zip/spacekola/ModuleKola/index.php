<?php
            //ModuleKola
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleKola</a> ');

    
        		$kolaCtrl = new KolaController();		$kolacomicbookCtrl = new KolacomicbookController();		$kolachapterCtrl = new KolachapterController();		$kolapostCtrl = new KolapostController();		$kolapostimageCtrl = new KolapostimageController();		$kolapostcommentCtrl = new KolapostcommentController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'kola/index':
        Genesis::renderView('kola.index',  $kolaCtrl->listAction());
        break;					
    case 'kola/create':
        Genesis::renderView( 'kola.form', $kolaCtrl->createAction(), true);
        break;					
    case 'kola/update':
        Genesis::renderView( 'kola.form',  $kolaCtrl->updateAction($_GET['id']), true);
        break;


    case 'kolacomicbook/index':
        Genesis::renderView('kolacomicbook.index',  $kolacomicbookCtrl->listAction());
        break;					
    case 'kolacomicbook/create':
        Genesis::renderView( 'kolacomicbook.form', $kolacomicbookCtrl->createAction(), true);
        break;					
    case 'kolacomicbook/update':
        Genesis::renderView( 'kolacomicbook.form',  $kolacomicbookCtrl->updateAction($_GET['id']), true);
        break;


    case 'kolachapter/index':
        Genesis::renderView('kolachapter.index',  $kolachapterCtrl->listAction());
        break;					
    case 'kolachapter/create':
        Genesis::renderView( 'kolachapter.form', $kolachapterCtrl->createAction(), true);
        break;					
    case 'kolachapter/update':
        Genesis::renderView( 'kolachapter.form',  $kolachapterCtrl->updateAction($_GET['id']), true);
        break;


    case 'kolapost/index':
        Genesis::renderView('kolapost.index',  $kolapostCtrl->listAction());
        break;					
    case 'kolapost/create':
        Genesis::renderView( 'kolapost.form', $kolapostCtrl->createAction(), true);
        break;					
    case 'kolapost/update':
        Genesis::renderView( 'kolapost.form',  $kolapostCtrl->updateAction($_GET['id']), true);
        break;


    case 'kolapostimage/index':
        Genesis::renderView('kolapostimage.index',  $kolapostimageCtrl->listAction());
        break;					
    case 'kolapostimage/create':
        Genesis::renderView( 'kolapostimage.form', $kolapostimageCtrl->createAction(), true);
        break;					
    case 'kolapostimage/update':
        Genesis::renderView( 'kolapostimage.form',  $kolapostimageCtrl->updateAction($_GET['id']), true);
        break;


    case 'kolapostcomment/index':
        Genesis::renderView('kolapostcomment.index',  $kolapostcommentCtrl->listAction());
        break;					
    case 'kolapostcomment/create':
        Genesis::renderView( 'kolapostcomment.form', $kolapostcommentCtrl->createAction(), true);
        break;					
    case 'kolapostcomment/update':
        Genesis::renderView( 'kolapostcomment.form',  $kolapostcommentCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    