<?php 
    /**
     * @Entity @Table(name="kolacomicbook")
     * */
    class Kolacomicbook extends \Kola implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id; 
        
        /**
         * @ManyToOne(targetEntity="\Comicbook")
         * , inversedBy="reporter"
         * @var \Comicbook
         */
        public $comicbook;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->comicbook = new Comicbook();
}

        public function getId() {
            return $this->id;
        }
        /**
         *  manyToOne
         *	@return \Comicbook
         */
        function getComicbook() {
            $this->comicbook = $this->comicbook->__show();
            return $this->comicbook;
        }
        function setComicbook(\Comicbook $comicbook) {
            $this->comicbook = $comicbook;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'comicbook' => $this->comicbook,
                ];
        }
        
}
