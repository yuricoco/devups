<?php 
    /**
     * @Entity @Table(name="kolachapter")
     * */
    class Kolachapter extends \Kola implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id; 
        
        /**
         * @ManyToOne(targetEntity="\Chapter")
         * , inversedBy="reporter"
         * @var \Chapter
         */
        public $chapter;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->chapter = new Chapter();
}

        public function getId() {
            return $this->id;
        }
        /**
         *  manyToOne
         *	@return \Chapter
         */
        function getChapter() {
            $this->chapter = $this->chapter->__show();
            return $this->chapter;
        }
        function setChapter(\Chapter $chapter) {
            $this->chapter = $chapter;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'chapter' => $this->chapter,
                ];
        }
        
}
