<?php 
    /**
     * @Entity @Table(name="kolapost")
     * */
    class Kolapost extends \Kola implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id; 
        
        /**
         * @ManyToOne(targetEntity="\Post")
         * , inversedBy="reporter"
         * @var \Post
         */
        public $post;


        
        public function __construct($id = null){
            parent::__construct($id);
                if( $id ) { $this->id = $id; }   
                          
	$this->post = new Post();
}

        public function getId() {
            return $this->id;
        }
        /**
         *  manyToOne
         *	@return \Post
         */
        function getPost() {
            $this->post = $this->post->__show();
            return $this->post;
        }
        function setPost(\Post $post) {
            $this->post = $post;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'post' => $this->post,
                ];
        }
        
}
