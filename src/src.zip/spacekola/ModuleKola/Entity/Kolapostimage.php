<?php 
    /**
     * @Entity @Table(name="kolapostimage")
     * */
    class Kolapostimage extends \Kola implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id; 
        
        /**
         * @ManyToOne(targetEntity="\Postimage")
         * , inversedBy="reporter"
         * @var \Postimage
         */
        public $postimage;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->postimage = new Postimage();
}

        public function getId() {
            return $this->id;
        }
        /**
         *  manyToOne
         *	@return \Postimage
         */
        function getPostimage() {
            $this->postimage = $this->postimage->__show();
            return $this->postimage;
        }
        function setPostimage(\Postimage $postimage) {
            $this->postimage = $postimage;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'postimage' => $this->postimage,
                ];
        }
        
}
