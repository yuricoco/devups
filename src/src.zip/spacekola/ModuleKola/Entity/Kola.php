<?php

class Kola extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="creationdate", type="datetime"  )
     * @var datetime
     **/
    protected $creationdate;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    protected $user;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->user = new User();
    }

    /**
     * @param $userid
     * @return $this
     * @throws ReflectionException
     */
    public static function init($userid){
        $reflection = new ReflectionClass(get_called_class());
        $entity = $reflection->newInstance();

        $entity->setUser(new User($userid));
        $entity->setCreationdate(new DateTime());

        return $entity;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getCreationdate()
    {
        return $this->creationdate;
    }

    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    /**
     *  manyToOne
     * @return \User
     */
    function getUser()
    {
        $this->user = $this->user->__show();
        return $this->user;
    }

    function setUser(\User $user)
    {
        $this->user = $user;
    }


    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'creationdate' => $this->creationdate,
            'user' => $this->user,
        ];
    }

}
