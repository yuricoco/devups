<?php 
    /**
     * @Entity @Table(name="kolapostcomment")
     * */
    class Kolapostcomment extends \Kola implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id; 
        
        /**
         * @ManyToOne(targetEntity="\Postcomment")
         * , inversedBy="reporter"
         * @var \Postcomment
         */
        public $postcomment;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->postcomment = new Postcomment();
}

        public function getId() {
            return $this->id;
        }
        /**
         *  manyToOne
         *	@return \Postcomment
         */
        function getPostcomment() {
            $this->postcomment = $this->postcomment->__show();
            return $this->postcomment;
        }
        function setPostcomment(\Postcomment $postcomment) {
            $this->postcomment = $postcomment;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'postcomment' => $this->postcomment,
                ];
        }
        
}
