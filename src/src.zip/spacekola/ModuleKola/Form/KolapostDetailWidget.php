
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($kolapost, [
['label' => 'Post', 'value' => 'Post.id']
]); ?>

        </div>
			