<?php 

    class KolaForm extends FormManager{

        public static function formBuilder(\Kola $kola, $action = null, $button = false) {
            $entitycore = new Core($kola);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['user'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $kola->getUser()->getId(),
                    "label" => 'User',
                    "options" => FormManager::Options_Helper('firstname', User::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/kolaForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Kola $kola, $action = null, $button = false) {
            return FormFactory::__renderForm(KolaForm::formBuilder($kola, $action, $button));
        }
        
        public static function __renderFormWidget(\Kola $kola, $action_form = null) {
            include ROOT.Kola::classpath()."Form/KolaFormWidget.php";
        }

        public static function __renderDetailWidget(\Kola $kola){
            include ROOT . Kola::classpath() . "Form/KolaDetailWidget.php";
        }
    }
    