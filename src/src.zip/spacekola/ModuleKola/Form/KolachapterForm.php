<?php 

    class KolachapterForm extends FormManager{

        public static function formBuilder(\Kolachapter $kolachapter, $action = null, $button = false) {
            $entitycore = new Core($kolachapter);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['chapter'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $kolachapter->getChapter()->getId(),
                    "label" => 'Chapter',
                    "options" => FormManager::Options_Helper('id', Chapter::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/kolachapterForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Kolachapter $kolachapter, $action = null, $button = false) {
            return FormFactory::__renderForm(KolachapterForm::formBuilder($kolachapter, $action, $button));
        }
        
        public static function __renderFormWidget(\Kolachapter $kolachapter, $action_form = null) {
            include ROOT.Kolachapter::classpath()."Form/KolachapterFormWidget.php";
        }

        public static function __renderDetailWidget(\Kolachapter $kolachapter){
            include ROOT . Kolachapter::classpath() . "Form/KolachapterDetailWidget.php";
        }
    }
    