<?php 

    class KolapostForm extends FormManager{

        public static function formBuilder(\Kolapost $kolapost, $action = null, $button = false) {
            $entitycore = new Core($kolapost);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['post'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $kolapost->getPost()->getId(),
                    "label" => 'Post',
                    "options" => FormManager::Options_Helper('id', Post::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/kolapostForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Kolapost $kolapost, $action = null, $button = false) {
            return FormFactory::__renderForm(KolapostForm::formBuilder($kolapost, $action, $button));
        }
        
        public static function __renderFormWidget(\Kolapost $kolapost, $action_form = null) {
            include ROOT.Kolapost::classpath()."Form/KolapostFormWidget.php";
        }

        public static function __renderDetailWidget(\Kolapost $kolapost){
            include ROOT . Kolapost::classpath() . "Form/KolapostDetailWidget.php";
        }
    }
    