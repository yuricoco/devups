<?php 

    class KolapostcommentForm extends FormManager{

        public static function formBuilder(\Kolapostcomment $kolapostcomment, $action = null, $button = false) {
            $entitycore = new Core($kolapostcomment);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['postcomment'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $kolapostcomment->getPostcomment()->getId(),
                    "label" => 'Postcomment',
                    "options" => FormManager::Options_Helper('id', Postcomment::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/kolapostcommentForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Kolapostcomment $kolapostcomment, $action = null, $button = false) {
            return FormFactory::__renderForm(KolapostcommentForm::formBuilder($kolapostcomment, $action, $button));
        }
        
        public static function __renderFormWidget(\Kolapostcomment $kolapostcomment, $action_form = null) {
            include ROOT.Kolapostcomment::classpath()."Form/KolapostcommentFormWidget.php";
        }

        public static function __renderDetailWidget(\Kolapostcomment $kolapostcomment){
            include ROOT . Kolapostcomment::classpath() . "Form/KolapostcommentDetailWidget.php";
        }
    }
    