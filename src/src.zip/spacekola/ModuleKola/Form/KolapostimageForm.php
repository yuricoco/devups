<?php 

    class KolapostimageForm extends FormManager{

        public static function formBuilder(\Kolapostimage $kolapostimage, $action = null, $button = false) {
            $entitycore = new Core($kolapostimage);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['postimage'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $kolapostimage->getPostimage()->getId(),
                    "label" => 'Postimage',
                    "options" => FormManager::Options_Helper('id', Postimage::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/kolapostimageForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Kolapostimage $kolapostimage, $action = null, $button = false) {
            return FormFactory::__renderForm(KolapostimageForm::formBuilder($kolapostimage, $action, $button));
        }
        
        public static function __renderFormWidget(\Kolapostimage $kolapostimage, $action_form = null) {
            include ROOT.Kolapostimage::classpath()."Form/KolapostimageFormWidget.php";
        }

        public static function __renderDetailWidget(\Kolapostimage $kolapostimage){
            include ROOT . Kolapostimage::classpath() . "Form/KolapostimageDetailWidget.php";
        }
    }
    