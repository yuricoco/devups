<?php 

    class KolacomicbookForm extends FormManager{

        public static function formBuilder(\Kolacomicbook $kolacomicbook, $action = null, $button = false) {
            $entitycore = new Core($kolacomicbook);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['comicbook'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $kolacomicbook->getComicbook()->getId(),
                    "label" => 'Comicbook',
                    "options" => FormManager::Options_Helper('id', Comicbook::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/kolacomicbookForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Kolacomicbook $kolacomicbook, $action = null, $button = false) {
            return FormFactory::__renderForm(KolacomicbookForm::formBuilder($kolacomicbook, $action, $button));
        }
        
        public static function __renderFormWidget(\Kolacomicbook $kolacomicbook, $action_form = null) {
            include ROOT.Kolacomicbook::classpath()."Form/KolacomicbookFormWidget.php";
        }

        public static function __renderDetailWidget(\Kolacomicbook $kolacomicbook){
            include ROOT . Kolacomicbook::classpath() . "Form/KolacomicbookDetailWidget.php";
        }
    }
    