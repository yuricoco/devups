<?php
            //ModuleKola
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$kolaCtrl = new KolaController();
		$kolacomicbookCtrl = new KolacomicbookController();
		$kolachapterCtrl = new KolachapterController();
		$kolapostCtrl = new KolapostController();
		$kolapostimageCtrl = new KolapostimageController();
		$kolapostcommentCtrl = new KolapostcommentController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'kola._new':
                g::json_encode(KolaController::renderForm());
                break;
        case 'kola.create':
                g::json_encode($kolaCtrl->createAction());
                break;
        case 'kola._edit':
                g::json_encode(KolaController::renderForm(R::get("id")));
                break;
        case 'kola.update':
                g::json_encode($kolaCtrl->updateAction(R::get("id")));
                break;
        case 'kola._show':
                KolaController::renderDetail(R::get("id"));
                break;
        case 'kola._delete':
                g::json_encode($kolaCtrl->deleteAction(R::get("id")));
                break;
        case 'kola._deletegroup':
                g::json_encode($kolaCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'kola.datatable':
                g::json_encode($kolaCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'kolacomicbook._new':
                g::json_encode(KolacomicbookController::renderForm());
                break;
        case 'kolacomicbook.create':
                g::json_encode($kolacomicbookCtrl->createAction());
                break;
        case 'kolacomicbook._edit':
                g::json_encode(KolacomicbookController::renderForm(R::get("id")));
                break;
        case 'kolacomicbook.update':
                g::json_encode($kolacomicbookCtrl->updateAction(R::get("id")));
                break;
        case 'kolacomicbook._show':
                KolacomicbookController::renderDetail(R::get("id"));
                break;
        case 'kolacomicbook._delete':
                g::json_encode($kolacomicbookCtrl->deleteAction(R::get("id")));
                break;
        case 'kolacomicbook._deletegroup':
                g::json_encode($kolacomicbookCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'kolacomicbook.datatable':
                g::json_encode($kolacomicbookCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'kolachapter._new':
                g::json_encode(KolachapterController::renderForm());
                break;
        case 'kolachapter.create':
                g::json_encode($kolachapterCtrl->createAction());
                break;
        case 'kolachapter._edit':
                g::json_encode(KolachapterController::renderForm(R::get("id")));
                break;
        case 'kolachapter.update':
                g::json_encode($kolachapterCtrl->updateAction(R::get("id")));
                break;
        case 'kolachapter._show':
                KolachapterController::renderDetail(R::get("id"));
                break;
        case 'kolachapter._delete':
                g::json_encode($kolachapterCtrl->deleteAction(R::get("id")));
                break;
        case 'kolachapter._deletegroup':
                g::json_encode($kolachapterCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'kolachapter.datatable':
                g::json_encode($kolachapterCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'kolapost._new':
                g::json_encode(KolapostController::renderForm());
                break;
        case 'kolapost.create':
                g::json_encode($kolapostCtrl->createAction());
                break;
        case 'kolapost._edit':
                g::json_encode(KolapostController::renderForm(R::get("id")));
                break;
        case 'kolapost.update':
                g::json_encode($kolapostCtrl->updateAction(R::get("id")));
                break;
        case 'kolapost._show':
                KolapostController::renderDetail(R::get("id"));
                break;
        case 'kolapost._delete':
                g::json_encode($kolapostCtrl->deleteAction(R::get("id")));
                break;
        case 'kolapost._deletegroup':
                g::json_encode($kolapostCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'kolapost.datatable':
                g::json_encode($kolapostCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'kolapostimage._new':
                g::json_encode(KolapostimageController::renderForm());
                break;
        case 'kolapostimage.create':
                g::json_encode($kolapostimageCtrl->createAction());
                break;
        case 'kolapostimage._edit':
                g::json_encode(KolapostimageController::renderForm(R::get("id")));
                break;
        case 'kolapostimage.update':
                g::json_encode($kolapostimageCtrl->updateAction(R::get("id")));
                break;
        case 'kolapostimage._show':
                KolapostimageController::renderDetail(R::get("id"));
                break;
        case 'kolapostimage._delete':
                g::json_encode($kolapostimageCtrl->deleteAction(R::get("id")));
                break;
        case 'kolapostimage._deletegroup':
                g::json_encode($kolapostimageCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'kolapostimage.datatable':
                g::json_encode($kolapostimageCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'kolapostcomment._new':
                g::json_encode(KolapostcommentController::renderForm());
                break;
        case 'kolapostcomment.create':
                g::json_encode($kolapostcommentCtrl->createAction());
                break;
        case 'kolapostcomment._edit':
                g::json_encode(KolapostcommentController::renderForm(R::get("id")));
                break;
        case 'kolapostcomment.update':
                g::json_encode($kolapostcommentCtrl->updateAction(R::get("id")));
                break;
        case 'kolapostcomment._show':
                KolapostcommentController::renderDetail(R::get("id"));
                break;
        case 'kolapostcomment._delete':
                g::json_encode($kolapostcommentCtrl->deleteAction(R::get("id")));
                break;
        case 'kolapostcomment._deletegroup':
                g::json_encode($kolapostcommentCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'kolapostcomment.datatable':
                g::json_encode($kolapostcommentCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
            break;
     }

