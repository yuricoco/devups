<?php 

    class UserForm extends FormManager{

        public static function formBuilder(\User $user, $action = null, $button = false) {
            $entitycore = $user->scan_entity_core();
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                


            $entitycore->field['activated'] = [
                "label" => 'Activated', 
			"type" => FORMTYPE_RADIO, 
                "value" => $user->getActivated(), 
            ];


            return $entitycore;
        }
        
        public static function __renderForm(\User $user, $action = null, $button = false) {
            return FormFactory::__renderForm(UserForm::formBuilder($user, $action, $button));
        }
        
    }
    