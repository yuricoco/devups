<div class='form-group'>
<label for='selected'>Selected</label>
	<b><?= $userunit->getSelected(); ?></b>
 </div>
<div class='form-group'>
<label for='unit'>Unit</label>
	<?= '<b>'.$userunit->getUnit()->getId().'</b>'; ?>
 </div>
<div class='form-group'>
<label for='user'>User</label>
	<?= '<b>'.$userunit->getUser()->getId().'</b>'; ?>
 </div>
