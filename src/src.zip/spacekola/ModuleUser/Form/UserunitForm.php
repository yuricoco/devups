<?php 

    class UserunitForm extends FormManager{

        public static function formBuilder(\Userunit $userunit, $action = null, $button = false) {
            $entitycore = new Core($userunit);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['selected'] = [
                "label" => 'Selected', 
			"type" => FORMTYPE_TEXT, 
                "value" => $userunit->getSelected(), 
            ];

                $entitycore->field['unit'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $userunit->getUnit()->getId(),
                    "label" => 'Unit',
                    "options" => FormManager::Options_Helper('id', Unit::allrows()),
                ];

                $entitycore->field['user'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $userunit->getUser()->getId(),
                    "label" => 'User',
                    "options" => FormManager::Options_Helper('firstname', User::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            
            return $entitycore;
        }
        
        public static function __renderForm(\Userunit $userunit, $action = null, $button = false) {
            return FormFactory::__renderForm(UserunitForm::formBuilder($userunit, $action, $button));
        }
        
        public static function __renderFormWidget(\Userunit $userunit, $action_form = null) {
            include ROOT.Userunit::classpath()."Form/UserunitFormWidget.php";
        }

        public static function __renderDetailWidget(\Userunit $userunit){
            include ROOT . Userunit::classpath() . "Form/UserunitDetailWidget.php";
        }
    }
    