<?php 

	class PaysDAO extends DBAL{
			
		public function __construct() {
			parent::__construct(new Country());
		}
		
		public function create(Country $pays) {
			parent::__construct($pays);
			if($id = parent::createDbal()){
				return $id;
			}else {
				return FALSE;
			}
		}
		
		public function update(Country $pays) {
			parent::__construct($pays);
			if(parent::updateDbal()){
				return TRUE;
			}else {
				return FALSE;
			}
		}
		
		public function findAllBaseEntity() {
			//parent::__construct(new Pays());
			if($liste = parent::findAllDbal()){
				return $liste;
			}else {
				return FALSE;
			}
		}
		
		public function findAll() {
			if($liste = parent::findAllDbalEntireEntity()){
                return $liste;
			}else {
				return FALSE;
			}
		}
		 
		/**
		 * @var \Country
		 */
		public function findById($id) {
			$pays = new Country();
			$pays->setId($id);
			
			parent::__construct($pays);
			if($row = parent::findByIdDbal()){
				$instancePays = $row;
				return $instancePays;
			}else {
				return null;
			}
		}
		
		public function delete(Country $pays) {
			parent::__construct($pays);
			if(parent::deleteDbal()){
				return TRUE;
			}else {
				return FALSE;
			}
		}
			   
		/*public function findElementWhereXisY($x, $value = null) {
			if($row = parent::findElementWhereXisY($x, $value)){
				$listeInstance = $this->instance($row);
				return $listeInstance;
			}else {
				return array();
			}
		}*/
		
		/**
		* disparaitra dans les prochaines versions
		*/
		private function instance($arraybd){
			$retour = $arraybd;
			if($arraybd != null){
				foreach ( $arraybd as $row){
					$liste[] = $this->constructFromDataBase($row);
				}
				$retour = $liste;
			}
			return $retour;
		}
		/**
		*	listentity est un parametre qui est utilisé lors de la presence d'une relation n:n dans les attributs de l'entité
		* 	je n'ai pas encore rendu son fonctionnement generique tant dans la generation du projet par le rad prodbuild que
		*	dans le developpement. 
		*/
		public function constructFromDataBase(Country $pays, $listentity = null){
			 /*
			$continentDao = new ContinentDAO(); 
			$continent = $continentDao->findById($pays->getContinent()->getId());
			$pays->setContinent($continent);*/
			return $pays;
		}
		
	}