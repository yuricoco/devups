<?php

class UserDAO extends DBAL {

    public function __construct() {
        parent::__construct(new User());
    }

    public function findByConnectic($login, $pwd) {

        $qb = new QueryBuilder(new User());
        $row = $qb->select()->where('email', "=", $login)->andwhere('password', "=", sha1($pwd))->__getOne();

        if (!$row->getId())
            return array('success' => false, "err" => 'Login ou mot de passe incorrect.');
        else {
            return $row;
        }
    }

}
