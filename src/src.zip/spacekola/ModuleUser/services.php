<?php
            //ModuleUser
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$userCtrl = new UserController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'user._new':
                g::json_encode(UserController::renderForm());
                break;
        case 'user.create':
                g::json_encode($userCtrl->createAction());
                break;
        case 'user._edit':
                g::json_encode(UserController::renderForm(R::get("id")));
                break;
        case 'user.update':
                g::json_encode($userCtrl->updateAction(R::get("id")));
                break;
        case 'user._show':
                g::json_encode(UserController::renderDetail(R::get("id")));
                break;
        case 'user._delete':
                g::json_encode($userCtrl->deleteAction(R::get("id")));
                break;
        case 'user._deletegroup':
                g::json_encode($userCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'user.datatable':
                g::json_encode($userCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : page note found", 'route' => R::get('path')]);
            break;
     }

