<?php
            //ModuleUser
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleUser</a> ');

    
        		$userCtrl = new UserController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'user/index':
        Genesis::renderView('user.index',  $userCtrl->listAction());
        break;					
    case 'user/create':
        Genesis::renderView( 'user.form', $userCtrl->createAction(), true);
        break;					
    case 'user/update':
        Genesis::renderView( 'user.form',  $userCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    