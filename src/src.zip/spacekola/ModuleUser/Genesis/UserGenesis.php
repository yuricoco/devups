<?php 
				
	class UserGenesis{
		
		static function genesis($view, $controllers, \UserController $userCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('user.index',  $userCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'user.form',  $userCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'user.form', $userCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'user.form',  $userCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'user.form',  $userCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'user.show', $userCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'user.show', $userCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \UserController $userCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					echo json_encode($userCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($userCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($userCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($userCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($userCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
