<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RegistrationController
 *
 * @author azankang
 */
class RegistrationController extends Controller {

    private static function generateusername($param) {
        $username = remove_accents($param);
        $username = str_replace(" ", ".", $username);

        $user = User::select()->where("user.username", $username)->__getOne();

        if ($user->getId()) {
            $list = "1234567890";
            mt_srand((double) microtime() * 10000);
            $generate = "";
            while (strlen($generate) < 3) {
                $generate .= $list[mt_rand(0, strlen($list) - 1)];
            }

            if (strlen($username) > 6)
                $alias = substr($username, 0, -(strlen($username) - 6));
            else
                $alias = $username;

            return $alias . $generate;
        }


        return $username;
    }

    public static function generatecode() {

        $datetime = new DateTime();

        if (__prod)
            $generate = sha1($datetime->getTimestamp());
        else
            $generate = sha1('12345');

        return substr($generate, 0, 5);
    }

    public static function acte($nbcaract, $emptycarat, $value) {
        $acte = "";
        $remaincarat = $nbcaract - strlen($value);
        for($i = 0; $i < $remaincarat; $i++)
            $acte .= $emptycarat;
        $acte = "0000";
        return $acte;
    }
    
    public static function acte1($nbcaract, $emptycarat, $value) {
        $acte = "";
        $remaincarat = $nbcaract - strlen($value);
        for($i = 0; $i < $remaincarat; $i++)
            $acte .= $emptycarat;
        
        return $acte.$value;
    }

    public function updateprofile($id){

    }

    public function register($id = null, $action_form = "registration") {
        extract($_POST);

        //die(var_dump($id, $_SESSION[USERID]));
        $anyerror = false;
        $error = User::errorlist();
        // check if username is free
        $userhydrate = $this->form_generat(new User($id), $user_form);

        if(false)
            $userhydrate = new User();

        $userhydrate->setPseudounic(clean(remove_accents($userhydrate->getPseudo())));
        if(!$id){

            $qb = new QueryBuilder(new User());
            $nbuser = $qb->select()
                ->where('user.email', "=", $userhydrate->getEmail())
                ->orwhere('user.phonenumber', "=", $userhydrate->getPhonenumber())
                ->orwhere('user.pseudounic', "=", $userhydrate->getPseudounic())
                ->__countEl();

            if($nbuser){
                $nbuser = User::select()
                    ->where('user.email', "=", $userhydrate->getEmail())
                    ->__countEl();

                if($nbuser)
                    return ["success" => false, "detail" => "email address already use"];

                $nbuser = User::select()
                    ->where('user.phonenumber', "=", $userhydrate->getPhonenumber())
                    ->__countEl();

                if($nbuser)
                    return ["success" => false, "detail" => "phonenumber already use"];

                $nbuser = User::select()
                    ->where('user.pseudounic', "=", $userhydrate->getPseudounic())
                    ->__countEl();

                if($nbuser)
                    return ["success" => false, "detail" => "pseudo already use"];
            }

            //$userhydrate->setPassword($user_form['password']);
//            $userhydrate->setPassword(sha1($user_form['password']));
            $userhydrate->setCreationdate(new DateTime());

            $activationcode = RegistrationController::generatecode();
            $userhydrate->setActivationcode($activationcode);
            $userhydrate->setBirthdate($user_form['year'] . '-' . $user_form['month'] . '-' . $user_form['day']);

            // send mail with activation code $codeactivation
            //RegistrationController::sendmail($activationcode, $userhydrate);
            // send sms with activation code $codeactivation
            //RegistrationController::sendsms($activationcode, $phonenumberhydrate, $userhydrate);
            $userhydrate->setLang(local());

        }else{

        }

        $userhydrate->__save();

        if($id){
            $_SESSION[USERAPP] = serialize(User::find($id));
            $_SESSION[USERID] = $id;

            return ["success" => true, "detail" => $userhydrate->getPseudo()." updated successfully"];
        }

        return ["success" => true, "redirect" => d_url("connexion", $id)];

    }

    public function complation($id) {
        extract($_POST);

        $user = $this->form_generat(new User($id), $user_form);
        //$user = userapp();
        $activationcode = RegistrationController::generatecode();
        $user->setActivationcode($activationcode);

        $user->__update();
        
        $_SESSION[USERAPP] = serialize($user);

        $phonenumber = $user->getPhonenumber();
        // send mail with activation code $codeactivation
        //RegistrationController::sendmail($activationcode, $user);
        // send sms with activation code $codeactivation
        //RegistrationController::sendsms($activationcode, $phonenumber, $user);
        
        return 1;
    }

    public static function resendactivationcode() {

        $user = userapp();
        $activationcode = RegistrationController::generatecode();
        $user->setActivationcode($activationcode);

        $user->__update();

        $_SESSION[USERAPP] = serialize($user);

        $phonenumber = $user->getPhonenumber();
        // send mail with activation code $codeactivation
        RegistrationController::sendmail($activationcode, $user);
        // send sms with activation code $codeactivation
        RegistrationController::sendsms($activationcode, $phonenumber, $user);

        return 1;
    }

    /**
     * implementation of swiftmailler
     * 
     * @param type $activationcode
     * @param \User $userhydrate
     */
    public static function sendsms($activationcode, $phonenumber, $userhydrate) {
        // create curl resource 
        if (!__prod)
            return 0;

        $message = "::: Spacekola ::: || Bonjour " . $userhydrate->getUsername() . " Votre code d'activation:\n " . $activationcode;

        $smssend = new Smssend();
        $smssend->setUser($userhydrate);
        $smssend->setCreationdate(new DateTime());
        $smssend->setPhonecode($phonenumber->getCountrycode());
        $smssend->setPhonenumber($phonenumber->getPhonenumber());
        $smssend->setMessage($message);

        $ch = curl_init();

        // set url 
        curl_setopt($ch, CURLOPT_URL, kola_sms );

        //return the transfer as a string 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(
                array(
                    "tel" => $phonenumber->getPhonenumber(), 
                    "message" => $message,
                    "key" => kola_sms_key,
                    "date" => date("Y-m-d H:i:s"),
                    ))
                );

        // $output contains the output string 
//        $output = curl_exec($ch);
        $output = json_decode(curl_exec($ch));       

        // close curl resource to free up system resources 
        curl_close($ch);
        
        if ($output->statut) {
            $smssend->setState(true);
            $smssend->setMessage($message . " " . $output->message);
        } else {
            $smssend->setState(false);
        }
        $smssend->__insert();
        
    }

    /**
     * implementation of swiftmailler
     * 
     * @param type $activationcode
     * @param \User $userhydrate
     */
    public static function sendmail($activationcode, $userhydrate) {

        // create curl resource 
        if (!__prod)
            return 0;

        include __DIR__ . '/../Ressource/emailtemplate/mail.php';

        $mail = $userhydrate->getEmail(); // Déclaration de l'adresse de destination.

        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $mail)) { // On filtre les serveurs qui présentent des bogues.
            $passage_ligne = "\r\n";
        } else {
            $passage_ligne = "\n";
        }

//=====Déclaration des messages au format texte et au format HTML.
//        $message_txt = "Salut à tous, voici un e-mail envoyé par un script PHP.";
//        $message_html = "<html><head></head><body><b>Salut à tous</b>, code d'activation: $activationcode voici un e-mail envoyé par un <i>script PHP</i>.</body></html>";
        $message_html = getmailtemplate($activationcode, $userhydrate);
//==========
//=====Lecture et mise en forme de la pièce jointe.
//       $image_src = ROOT . "web/images/email/spacekola.jpg";
//       $fichier = fopen($image_src, "r");
//       $attachement = fread($fichier, filesize($image_src));
//        $attachement = chunk_split(base64_encode($attachement));
//        fclose($fichier);
//==========
//=====Création de la boundary.
        $boundary = "-----=" . md5(rand());
        $boundary_alt = "-----=" . md5(rand());
//==========
//=====Définition du sujet.
        $sujet = "Bienvenu sur spacekola. Votre code d'activation.";
//=========
//=====Création du header de l'e-mail.
        $header = "From: \"spacekola\"<no-reply@spacekola.com>" . $passage_ligne;
        $header .= "Reply-to: \"spacekola\" <no-reply@spacekola.com>" . $passage_ligne;
        $header .= "MIME-Version: 1.0" . $passage_ligne;
        $header .= "Content-Type: multipart/mixed;" . $passage_ligne . " boundary=\"$boundary\"" . $passage_ligne;
//==========
//=====Création du message.
        $message = $passage_ligne . "--" . $boundary . $passage_ligne;
        $message .= "Content-Type: multipart/alternative;" . $passage_ligne . " boundary=\"$boundary_alt\"" . $passage_ligne;
        $message .= $passage_ligne . "--" . $boundary_alt . $passage_ligne;

//=====Ajout du message au format texte.
//        $message .= "Content-Type: text/plain; charset=\"ISO-8859-1\"" . $passage_ligne;
//        $message .= "Content-Transfer-Encoding: 8bit" . $passage_ligne;
//        $message .= $passage_ligne . $message_txt . $passage_ligne;
//==========

        $message .= $passage_ligne . "--" . $boundary_alt . $passage_ligne;

//=====Ajout du message au format HTML.
        $message .= "Content-Type: text/html; charset=\"ISO-8859-1\"" . $passage_ligne;
        $message .= "Content-Transfer-Encoding: 8bit" . $passage_ligne;
        $message .= $passage_ligne . $message_html . $passage_ligne;
//==========
//=====On ferme la boundary alternative.
        $message .= $passage_ligne . "--" . $boundary_alt . "--" . $passage_ligne;
//==========

        $message .= $passage_ligne . "--" . $boundary . $passage_ligne;

//=====Ajout de la pièce jointe.
//        $message .= "Content-Type: image/jpeg; name=\"image.jpeg\"" . $passage_ligne;
//        $message .= "Content-Transfer-Encoding: base64" . $passage_ligne;
//        $message .= "Content-Disposition: attachment; filename=\"spacekola.jpeg\"" . $passage_ligne;
//        $message .= $passage_ligne . $attachement . $passage_ligne . $passage_ligne;
//        $message .= $passage_ligne . "--" . $boundary . "--" . $passage_ligne;
//========== 
//=====Envoi de l'e-mail.
        $result = mail($mail, $sujet, $message, $header);

//==========
// Send the message
//        $result = $mailer->send($message);
        if ($result) {
            $userhydrate->setMailsend($result);
            $userhydrate->__update();
        }
    }

    public static function activateaccount() {
//        global $appuser;
        $appuser = userapp();

        if ($appuser->getisActivated())
            return ["success" => true, "url" => "activity"];
        else {
            $code = sha1($_POST['activationcode']);
            if (substr($code, 0, 5) == $appuser->getActivationcode()) {

                $appuser->setIsActivated(true);
                $appuser->setResettingpassword(false);
                //$appuser->setLocked(false);
                $appuser->__update();
                $_SESSION[USERAPP] = serialize($appuser);

                return ["success" => true, "url" => "account"];
            }
        }

        return [
            "success" => false,
            'error' => "Activation code not valide. ensure that there is no space"
        ];
    }

    public static function step3Action() {
        extract($_POST);

        $userapp = userapp();

        $userapp->setRegistered(4);
        $userapp->setEnabled(true);

        (new DBAL())->executeDbal("update user set registered = 4, enabled = 1 where id = " . $_SESSION[USERID]);

        updatesession($userapp);

        return ['success' => true];
    }

    public static function step2Action() {
        extract($_POST);

        $userapp = userapp();

        $userapp->setRegistered(3);
        $userinterests = [];
        (new DBAL())->executeDbal("update user set registered = 3 where id = " . $userapp->getId());

        updatesession($userapp);

        if (!isset($interest_ids))
            return ['success' => true];

        foreach ($interest_ids as $id) {
            $userinterest = new Userinterest();
            $userinterest->setUser($userapp);
            $userinterest->setInterestcenter(new Interestcenter($id));
            $userinterests[] = $userinterest;
        }

        if ($userinterests) {
            $sql = (new DBAL())->insertserialiseDbal(new Userinterest(), $userinterests);
            (new DBAL())->executeDbal($sql);
        }


        return ['success' => true];
    }

    public static function step1Action() {
        extract($_POST);

        $userapp = userapp();
        if ($userapp->getUsername() != $user_form['username']) {

            $user = User::select()->where("user.username", $user_form['username'])->__getOne();

            if ($user->getId())
                return ['success' => false, "error" => "this username is already use"];
        }

        $userhydrate = Controller::form_generat($userapp, $user_form);
        $userhydrate->setUsername($user_form['username']); // next step
        $userhydrate->setUsername_canonical(clean(remove_accents($user_form['username']))); // next step
        $userhydrate->setRegistered(2); // next step

        if (!isset($user_form['professionalstatut_id'])) {
            $userhydrate->setProfessionalstatut(new Professionalstatut());
        }

        $userhydrate->__update();
        updatesession($userhydrate);
        return [
            'success' => true,
            'user' => $userhydrate
        ];
    }

}
