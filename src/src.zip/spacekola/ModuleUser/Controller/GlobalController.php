<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GlobalController
 *
 * @author azankang
 */
class GlobalController extends Controller {

    //put your code here
    public static function initNavigationAction() {

        $groups = Group::select()->where("user_id", "=", $_SESSION[USERID])
            ->orderby(" group.id desc")->limit(3)->__getAll();
        $pages = Page::select()->where("user_id", "=", $_SESSION[USERID])
            ->orderby(" page.id desc")->limit(3)->__getAll();

        return ['pages' => $pages, 'groups' => $groups];
    }

    public static function birthdate($lang = __default_lang) {
        for ($i = 1; $i <= 31; $i++) {
            $days[$i] = $i;
        }
        $y = (int) date('Y') - 6;
        for ($i = 1910; $i <= $y; $i++) {
            $years[$i] = $i;
        }

        $lang = local();

        if ($lang == "en") {

            $months = [
                1 => 'january', 2 => 'february',
                3 => 'march', 4 => 'april',
                5 => 'may', 6 => 'jun',
                7 => 'july', 8 => 'august',
                9 => 'september', 10 => 'october',
                11 => 'november', 12 => 'december',
            ];
        } else {

            $months = [
                1 => 'janvier', 2 => 'février',
                3 => 'mars', 4 => 'avril',
                5 => 'mai', 6 => 'juin',
                7 => 'juillet', 8 => 'août',
                9 => 'septembre', 10 => 'octobre',
                11 => 'novembre', 12 => 'décembre',
            ];
        }

        return [
            'days' => $days,
            'months' => $months,
            'years' => $years,
        ];
    }

}
