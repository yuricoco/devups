<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LoginController
 *
 * @author azankang
 */
class LoginController {

    static function logout() {

        unset($_SESSION[USERID]);
        unset($_SESSION[USERAPP]);
        unset($_SESSION["setting"]);
        session_destroy();

        if (isset($_COOKIE[USERCOOKIE])) {
            setcookie(USERCOOKIE, null, -1, null, null, false, true);
            setcookie(USERNAME, null, -1, null, null, false, true);
            setcookie(USERPASS, null, -1, null, null, false, true);
        }

        if (isset($_GET['extern']))
            return ["success" => true];

        header("location: " .  d_url("home") );
    }

    private static function setcookie($pseudo, $pass) {

        setcookie(USERCOOKIE, 1, time() + 365 * 24 * 3600, null, null, false, true); // On écrit un cookie
        setcookie(USERNAME, $pseudo, time() + 365 * 24 * 3600, null, null, false, true); // On écrit un cookie
        setcookie(USERPASS, $pass, time() + 365 * 24 * 3600, null, null, false, true); // On écrit un autre cookie...
    }

    public static function resetactivationcode() {
        extract($_POST);

        $user = User::select()
            ->where('user.email', $user_form["email"])
            ->orwhere('user.phonenumber', $user_form["phonenumber"])
            ->__getOne();

        if ($user->getId()) {
            return LoginController::initialiseUserParam($user);
        } else {
            return array("success" => false,
                "error" => 'No user found');
        }
    }

    private static function initialiseUserParam(\User $user) {

        $activationcode = RegistrationController::generatecode();

        $user->setIsActivated(false);
        //$user->setLocked(true);
        $user->setResettingpassword(true);
        $user->setActivationcode($activationcode);
        $user->__update();

        $_SESSION[USERID] = $user->getId();
        $_SESSION[USERAPP] = serialize($user);
        //$_SESSION[LANG] = $user->getLocale();

        //updatesession($user);

//        RegistrationController::sendsms($activationcode, $user->getPhonenumber(), $user);
//        RegistrationController::sendmail($activationcode, $user);

        return array('success' => true, 'url' => "" . __env . "resetpassword");

    }

    public static function resetpassword() {
        extract($_POST);
        $userapp = userapp();

        $code = sha1($user_form['activationcode']);
        if (substr($code, 0, 5) == $userapp->getActivationcode()) {

            //$userapp->setSalt(sha1($_POST['password']));
            $userapp->setPassword(sha1($user_form['password']));
//            $userapp->setDevupspwd(sha1($_POST['password']));
//            $userapp->setLocked(false);
            $userapp->setIsActivated(true);
            $userapp->setResettingpassword(false);
            //$userapp->setCredentials_expired(false);
            //$userapp->setPassword_requested_at(new \DateTime());
            $userapp->__update();

            $_SESSION[USERAPP] = serialize($userapp);
            //updatesession($userapp);
            if (isset($_COOKIE[USERCOOKIE]))
                LoginController::setcookie($userapp->getPseudounic(), $userapp->getPassword());

            return ["success" => true, "url" => "" .  d_url("my-account") . "", $_POST];
        } else {
            return ["success" => false, "error" => "Unvalid activation code"];
        }
    }

    public static function changepwAction() {

        $user = User::find($_SESSION[USERID]);
        extract($_POST);

        if(!$user_form['oldpassword'] || !$user_form['password'] || !$user_form['confirmpassword'])
            return array('success' => false,
                'error' => gettranslation("form.field.allimportant"));

        if($user_form['password'] != $user_form['confirmpassword'])
            return array('success' => false,
                'error' => gettranslation("password.notconfirm", local()));

        if (sha1($user_form['oldpassword']) == $user->getPassword()) {
            $user->__update("password", sha1($user_form['password']))->exec();
            return array('success' => true,
                'redirect' => 'profile&detail=password updated successfully',
                'detail' => '');
        } else {
            return array('success' => false,
                'error' => gettranslation("password.incorrect", local()));
        }
    }

    public static function setLastLoginDateAction() {

        $dbal = new DBAL();
        $sql = " update user set last_login = NOW() where id = ? ";
        $dbal->executeDbal($sql, [$_SESSION[USERID]]);
    }

    static function restartsessionAction() {

        $qb = new QueryBuilder(new User());
        $user = $qb->select()
            ->where('user.password', "=", $_COOKIE[USERPASS])
            ->andwhere('user.pseudounic', "=", $_COOKIE[USERNAME])
            ->__getOne();

        if ($user->getId()) {

            $_SESSION[USERAPP] = serialize($user);
            $_SESSION[USERID] = $user->getId();
            $_SESSION[LANG] = $user->getLang();
            //LoginController::setLastLoginDateAction();

//            if(!$user->getActivated())
//                return array(
//                    'success' => true, 'url' => __env."activeaccount");

            //return $user;
        }
//        else {
//            return new User();
//        }
    }

    static function connexionAction($extern = false) {
        extract($_POST);

        $password = sha1($user_form["password"]);

        $qb = new QueryBuilder(new User());
        $user = $qb->select()
                ->where('user.password', "=", $password)
                ->andwhere('user.pseudounic', "=", clean(remove_accents($user_form["login"])))
                ->orwhere('user.phonenumber', "=", $user_form["login"])
                ->__getOne();

        if ($user->getId()) {

            $_SESSION[USERAPP] = serialize($user);
            $_SESSION[USERID] = $user->getId();

            if (isset($remember_me)) {
                //set cookie
                LoginController::setcookie($user->getPseudounic(), $user->getPassword());
            }

            return array(
                'success' => true, 'url' => d_url("my-account"),
                "user" => $user,
                "redirect" => d_url("my-account"),
                //"userserialize" => $_SESSION[USERAPP]
            );
        }else {
            return array("success" => false,
                "user" => $user,
                "error" => ["login"=> 'erreur de connexion. Login ou mot de passe incorrecte']);
        }
    }

    function connextionextr($id, $password) {
        $user = new User($id);
        $user->setPassword($password);
        $user->setLocale('en');

        if ($user->getId()) {

            $_SESSION[USERAPP] = serialize($user);
            $_SESSION[USERID] = $user->getId();
            $_SESSION[LANG] = $user->getLocale();

            if (!$user->getActivated())
                return array(
                    'success' => true, 'url' => __env . "activeaccount");

            return array(
                'success' => true, 'url' => "" . __env . "");
        }else {
            return array("success" => false,
//                "phonenumber" => $phonenumber,
                "user" => $user,
                "error" => 'erreur de connexion. Login ou mot de passe incorrecte');
        }
    }

}
