<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use DClass\devups\Datatable;

/**
 * Description of UserController
 *
 * @author azankang
 */
class UserController extends Controller{

    public static function getprofileAction($id){
        if($id == $_SESSION[USERID])
            $user = userapp();
        else
            $user = User::find($id);

        $following = Follow::select()->where("follower", $id)->__countEl();
        $followers = Follow::select()->where("following", $id)->__countEl();
        $ifollow = Follow::select()->where("following", $id)->andwhere("follower", $_SESSION[USERID])->__countEl();

        return [
            "userprofile" => $user,
            "ifollow" => (int) $ifollow,
            "followers" => $followers,
            "following" => $following,
            "postcollections" => PostController::i()->getcollectionAction($user->getId()),
        ];

    }

    public static function updateimageprofileAction($userid){
        extract($_POST);

        $url = Dfile::init("image")
            ->addresize([25, 25], "25_")
            ->addresize([45, 45], "45_")
            ->addresize([90, 90], "90_")
            ->addresize([100], "100_", null, false)
            ->setfile_name("profile.jpg")
            ->moveto("users/$userid");

        return $url;
    }

    public static function beenAction($userid){
        $dbal = new DBAL();

        if($_GET["been"] == "drawer")
            $dbal->executeDbal("update `user` set isdrawer = 1 where id = $userid ");
        elseif($_GET["been"] == "traductor")
            $dbal->executeDbal("update `user` set istranslator = 1 where id = $userid ");
        else{
            $dbal->executeDbal("update `user` set ischecker = 1 where id = $userid ");

//            $nbchck = Chapterchecking::select()->where("this.status", "pe")->__countEl();
//            if($nbchck){
//                $content = str_replace("{nb}", $nbchck, gettranslation("notif.chaptertocheck"));
//                NotificationbroadcastedController::broadcast(new User($userid), null, null, $content, "my-account?root=checkinglist");
//            }

        }

        $abonne = User::find($userid);
        $_SESSION[USERAPP] = serialize($abonne);

        return true;
    }


    public function datatable($next, $per_page)
    {
        $lazyloading = $this->lazyloading(new User(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction() {
        
        $pagination = $this->lazyloading(new User(), 1, 10, null, "user.id desc");

        return array('success' => true, // pour le restservice
            'lazyloading' => $pagination, // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    
    static function connexionAction($login, $password) {
        extract($_POST);
        $dbal = new DBAL(new User());
        $user = User::select()->where(['user.username', 'user.devupspwd'], [$login, sha1($password)])->__getOne();
        if($user){
            
            $api_token = base_convert(sha1(uniqid(mt_rand(), true)), 16, 36) ;
            
            $dbal = new DBAL();
            
            $sql = "update `user` set api_token = ? where id = ? ";
            $arrayvalues = [$api_token, $user->getId()];
            $dbal->executeDbal($sql, $arrayvalues);
            
            return array("success" => true, 
//                "username" => $user,
                "username" => $user->getUsername(),
//                "email" => $user->getEmail(),
                "api_token" => $api_token . 's' . $user->getId());
        }else{
            return array("success" => false, "detail" => 'erreur de connexion. Login ou mot de passe incorrecte');
        }
        
        
    }
    
    public static function verifyToken($token) {
        
        $userid = substr($token, strrpos($token, 's')+1, strlen($token));
        $api_token = substr($token, 0, strrpos($token, 's'));
    
//        if(!isset($_SESSION[USERID])){
            $dbal = new DBAL(new User());
            $user = User::select()->where(['user.id', 'user.api_token'], [$userid, $api_token])->__getOne();
            if($user){
                $_SESSION[USERID] = $userid;
//                return true;
            }else{
                echo json_encode([
                    'statu' => false,
                ]);
            }
//        }
        
//        return $_SESSION[USERID];
            
    }
    
    static function onkeyupsearchAction($name) {
        
        $critere = " user.username LIKE '%$name%' and user.id != ".$_SESSION[USERID]." ";


        $qb = User::select()->where($critere);

        $users = $qb->orderby("user.username")
            ->limit(10)
            ->__getAll();

        $nbresult = $qb->__countEl();
                
        return array("success" => true, "users" => $users, "nbresult" => $nbresult);
        
    }
    
    static function showonlyAction($id) {

        return User::find($id);
        
    }
    
    static function sessionuserAction() {
        if(isset($_GET['id'])){
            $user = User::find($_GET['id']);
            return [
            "success" => true, 
            "user" => $user,
            "lang"  => $user->getLocale()
            ];
        }
//        $dbal = new DBAL(new User());
//        $user = userapp();
        
        return [
            "success" => true, 
            "user" => userapp(),
            "lang"  => getlang()
            ];
        
    }
    
    static function showAction($id) {
        //$dbal = new DBAL(new User());
        
        $user = User::find($id);
        $phonenumber = $user->getPhonenumber();
        
        return array("user" => $user, "phonenumber" => $phonenumber);
        
    }
    
    static function showpostuserAction($id) {
        
        $dbal = new DBAL(new Postuser());
        
        $postuser = Postuser::find($id);
        
        return $postuser;
        
    }
    
    static function updateUsernameAction($iduser) {
        extract($_POST);
        
        $sql = "update user set username = ? where id = ?";
        
        $dbal = new DBAL();
        $arrayvalues = [$username, $iduser];
        
        return $dbal->executeDbal($sql, $arrayvalues);
        
    }

    static function updateLangAction($userid) {
        extract($_POST);

        $user = userapp();

        $sql = "update user set lang = ? where id = ?";

        $dbal = new DBAL();
        $arrayvalues = [$fieldvalue, $userid];

        $user->setLang($fieldvalue);
        $_SESSION[USER] = serialize($user);

        return ["success" => $dbal->executeDbal($sql, $arrayvalues), $sql, $fieldvalue] ;

    }

    static function updateAboutmeAction($userid, $field) {
        extract($_POST);

        $user = userapp();

        $sql = "update user set $field = ? where id = ?";

        $dbal = new DBAL();
        $arrayvalues = [$fieldvalue, $userid];

        if($field == "aboutme")
            $user->setAboutme($fieldvalue);
        else
            $user->setLocation($fieldvalue);

        $_SESSION[USER] = serialize($user);

        return [$dbal->executeDbal($sql, $arrayvalues), $sql, $fieldvalue] ;

    }
    
    static function updateEmailAction() {
        extract($_POST);
        
        $sql = "update user set email = ?, email_canonical = ? where id = ?";
        
        $dbal = new DBAL();
        $arrayvalues = [$email, $email, $iduser];
        
        return $dbal->executeDbal($sql, $arrayvalues);
        
    }
    
    static function updateGeneralInformationAction() {
        extract($_POST);
        
        $sql = "update user set lastname = ?, firstname = ?, birthdate = ?, sex = ?, status = ?, locale = ?  where id = ?";
        
        $dbal = new DBAL();
        $arrayvalues = [$lastname, $firstname, $birthdate, $sex, $status, $locale, $iduser];
        
        return $dbal->executeDbal($sql, $arrayvalues);
        
    }
    
    static function sendEmailInvitationAction() {
        extract($_POST);
        $dbal = new DBAL(new Usermailinvitation());
        $usermailinvitation = $dbal->findOneElementWhereXisY("usermailinvitation.email", $email);
        if(!$usermailinvitation->getId()){
            
            $sql = "insert into usermailinvitation (user_id, name, email, hasregistered, creationdate) values ( ?, ?, ?, ?, NOW())";
        
            $arrayvalues = [$userid, $name, $email, 0];
            $dbal->executeDbal($sql, $arrayvalues, 1);
            
            return array("sendmail" => true);
            
        }
        
        return array("sendmail" => false);
        
    }
    
    public static function isRelation($friend=null, $appuser=null)
    {
        $qb = new QueryBuilder(new \Relation()); 
        $userelation = $qb->select()
                ->where($appuser)
                ->andwhere($friend)
                ->__getOne(false);
//        $dbal = new DBAL(new Relation());
//        $userelation = $dbal->findOneElementWhereXisY([$appuser, $friend]);
        
        if(is_null($userelation->getId()))
        {
            return false;
        }
        return true;
    }
        
    public static function hasFriendAsk(\User $user=null, \Friend $friend=null)
    {
        $qb = new QueryBuilder(new \FriendAsk()); 
        return $qb->select()
                ->where($user)
                ->andwhere($friend)
                ->__getOne();
        
    }
    
    public static function appuserasfriend() {
        $dbal = new DBAL(new Friend());        
        return Friend::select()->where(new User($_SESSION[USERID]))->__getOne();
    }

    public static function findiduserAction($id) {
        
        $appuser = userapp();         
        $appuserasfriend = UserController::appuserasfriend();
        
        $user = User::find($id);
        $dbal = new DBAL(new Friend());        
        $friend = Friend::select()->where($user)->__getOne();
        
        if(!is_null($user))
        {
            $elt = array();
            $elt['user'] = $user;
            if (UserController::isRelation($friend, $appuser))
            {
                $elt['isfriend'] = true;
            }
            else {
                $elt['isfriend'] = false;
                $friendask = UserController::hasFriendAsk($appuser, $friend);
                if ($friendask->getId())
                {
                    $elt['hasAsked'] = true;
                }
                else {
                    $elt['hasAsked'] = false;
                    
                    $friendask = UserController::hasFriendAsk($user, $appuserasfriend);
                    if ($friendask->getId())
                    {
                        $elt['isAsking'] = true;
                    }
                    else {
                        $elt['isAsking'] = false;
                    }
                }
                
                $elt['friendAsk'] = $friendask;
            }
            
            return  array(
                "success"=>true,
                "user"=> $elt,
                "details"=>"user d' id ".$id);
        }
        
            return  array(
                "success"=>false,
                "user"=> null,
                "details"=>"l'utilisateur d'id "+$id+" n'existe pas"); 
        
    }
    
}
