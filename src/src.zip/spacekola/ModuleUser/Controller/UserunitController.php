<?php 


use DClass\devups\Datatable as Datatable;

class UserunitController extends Controller{


    public static function settingold($id = null) {

        $user = unserialize($_SESSION[USERAPP]);
        $unittypes = Unittype::allrows();
        $collection = [];
        foreach ($unittypes as $unittype) {
            $costitems = [];
            $collection[] = [
                "unittype" => $unittype,
                "unittypename" => $unittype->getName(),
                'userunits' => $user->__hasmany(Userunit::class, false)
                    ->andwhere("unit.unittype_id", $unittype->getId())->__getAll(false),
            ];
        }
        $usersetting = unserialize($_SESSION["setting"]);
        //dv_dump($usersetting);
        return array('success' => true,
            'collectionunit' => $collection,
            'usersetting' => $usersetting,
            'detail' => 'detail de l\'action.');
    }

    public static function setting($id = null) {

        $user = unserialize($_SESSION[USERAPP]);
        $unittypes = Unittype::select()->where("this._use", "yes")->__getAllRow();
        $collection = [];
        foreach ($unittypes as $unittype) {
            $costitems = [];
            $collection[] = [
                "unittype" => $unittype,
                "unittypename" => $unittype->getLabel(),
                'units' => $unittype->__hasmany(Unit::class),
            ];
        }
        $metric = "";
        $field = "";
        if($user->getUnitsystem() == "m")
            $metric = "checked";
        else
            $field = "checked";

        //$user = unserialize($_SESSION[USERAPP]);
        //dv_dump($usersetting);
        return array('success' => true,
            'collectionunit' => $collection,
            'user' => $user,
            'field' => $field,
            'metric' => $metric,
            'detail' => 'detail de l\'action.');
    }

    public static function renderFormWidget($id = null) {
        if($id)
            UserunitForm::__renderFormWidget(Userunit::find($id), 'update');
        else
            UserunitForm::__renderFormWidget(new Userunit(), 'create');
    }

    public static function renderDetail($id) {
        UserunitForm::__renderDetailWidget(Userunit::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $userunit = new Userunit();
        if($id){
            $action = "update&id=".$id;
            $userunit = Userunit::find($id);
            //$userunit->collectStorage();
        }

        return ['success' => true,
            'form' => UserunitForm::__renderForm($userunit, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Userunit(), $next, $per_page);
        return ['success' => true,
            'tablebody' => Datatable::getTableRest($lazyloading),
            'tablepagination' => Datatable::pagination($lazyloading)
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Userunit(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $userunit = Userunit::find($id);

            return array( 'success' => true, 
                            'userunit' => $userunit,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($userunit_form = null){
        extract($_POST);
        $this->err = array();

        $userunit = $this->form_fillingentity(new Userunit(), $userunit_form);
 

        if ( $id = $userunit->__insert()) {
            return 	array(	'success' => true, // pour le restservice
                            'userunit' => $userunit,
                            'tablerow' => Datatable::getSingleRowRest($userunit),
                            'redirect' => 'index', // pour le web service
                            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
        } else {
            return 	array(	'success' => false, // pour le restservice
                            'userunit' => $userunit,
                            'action_form' => 'create', // pour le web service
                            'detail' => 'error data not persisted'); //Detail de l'action ou message d'erreur ou de succes
        }

    }

    public function updatesettingAction($systemunit, $userunit_form = null){
        extract($_POST);

        $user = unserialize($_SESSION[USERAPP]);
        $user->setUnitsystem($systemunit);
        $user->__update("this.unitsystem", $systemunit)->exec();
        $_SESSION[USERAPP] = serialize($user);

        $unittypes = Unittype::allrows();
        $collection = [];
        foreach ($unittypes as $unittype) {
            $costitems = [];
            $collection[$unittype->getName()] = $unittype->__hasmany(Unit::class, false)
                ->andwhere("unit.system", $systemunit)
                ->__getOne(false);
//                $collection[$unittype->getName()] = $user->__hasmany(Userunit::class, false)
//                        ->andwhere("unit.unittype_id", $unittype->getId())
//                        //->andwhere("this.selected", "y")
//                        ->andwhere("unit.system", $user-)
//                    ->__getOne(false);
        }
        $_SESSION["setting"] = serialize($collection);

        //$unittype = Unittype::select()->where("name", $unitypename)->__getOne();
//        $usersetting = unserialize($_SESSION["setting"]);
//        $collection = [];
//        //foreach ($unittypes as $unittype) {
//
//            Userunit::update()
//                ->leftjoin(Unittype::class, Unit::class)
//                ->set("selected", "n")
//                ->where("unittype.name", $unitypename)
//                ->andwhere("user.id", $_SESSION[USERID])->exec();
//
//            Userunit::update("selected", "y", $userunit_form[$unitypename])->exec();
//
//            $usersetting[$unitypename] = Userunit::find($userunit_form[$unitypename], false);
//
//        //}
//
//        $_SESSION["setting"] = serialize($usersetting);

        return 	array('success' => true, // pour le restservice
                            'redirect' => 'index', // pour le web service
                            'unitsystem' => $systemunit, // pour le web service
                            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }
    public function updateAction($id, $userunit_form = null){
        extract($_POST);

        $userunit = $this->form_fillingentity(new Userunit($id), $userunit_form);


        if ($userunit->__update()) {
            return 	array('success' => true, // pour le restservice
                            'userunit' => $userunit,
                            'tablerow' => Datatable::getSingleRowRest($userunit),
                            'redirect' => 'index', // pour le web service
                            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
        } else {
            return 	array('success' => false, // pour le restservice
                            'userunit' => $userunit,
                            'action_form' => 'update&id='.$id, // pour le web service
                            'detail' => 'error data not updated'); //Detail de l'action ou message d'erreur ou de succes
        }
    }
    
    public function deleteAction($id){
      
            Userunit::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Userunit::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'userunit' => new Userunit(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $userunit = Userunit::find($id);

        return array('success' => true, // pour le restservice
                        'userunit' => $userunit,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
