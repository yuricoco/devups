<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserRestController
 *
 * @author azankang
 */
class UserRestController extends Controller {
    //put your code here
    
    public static function connexionAction() {
        $username = "";
        $phonenumber = "";
        $password = "";
        
        $dbal = new DBAL(new User());
        $user = $dbal->findOneByCritereDbal(" where (user.username = :username and user.password = :password ) or  (user.email = :phonenumber and user.password = :password ) ",
                ["username" => $username, "email" => $email, 'password' => $password]);
        
        if(!$user){
            return ["success" => false, "message" => "invalide credential."];
        }
        
        // create token
        $datetime = new DateTime();
        $api_token = md5($email.$datetime->getTimestamp());        
                
        
    }
    
}
