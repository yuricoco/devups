<?php

function getmailtemplate($activationcode, \User $user) {

    $css = file_get_contents(__DIR__ . "/email.css");

    return '
	
	<!DOCTYPE html>
	<html>
	<head>
	<meta name="viewport" content="width=device-width" />

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Connexion Spacekola</title>
	<style>' . $css . '</style>

	</head>
	 
	<body bgcolor="#FFFFFF">

	<!-- HEADER -->
	<table class="head-wrap" bgcolor="#ffffff">
		<tr>
			<td></td>
			<td class="header container" >
					
					<div class="content">
					<table bgcolor="#ffffff">
						<tr>
							<td><img src="http://dev.spacekola.com/web/images/logospacekola.png" /></td>
							<td align="right"><h6 class="collapse">Connexion</h6></td>
						</tr>
					</table>
					</div>
					
			</td>
			<td></td>
		</tr>
	</table><!-- /HEADER -->


	<!-- BODY -->
	<table class="body-wrap">
		<tr>
			<td></td>
			<td class="container" bgcolor="#FFFFFF">

				<div class="content">
				<table>
					<tr>
						<td>
							<h3>Salut, ' . $user->getUsername() . '</h3>
							<p class="lead">Bien vouloir utiliser le code d\'activation ci-après pour activer votre compte Spacekola.</p>
							<a class="btn">Code d\'activation: ' . $activationcode . '</a>
											
							<!-- Callout Panel -->
						<p class="callout">
							" Toutes l\'équipe SPACEKOLA vous souhaite un <b>joyeux noël </b> et une très <b>bonne année 2018 "</b>
						</p><!-- /Callout Panel -->
						
							<!-- social & contact -->
							<table class="social" width="100%">
								<tr>
									<td>
										
											
										
										<!-- column 2 -->
										<table align="center" class="column">
											<tr>
												<td>				
																				
													<h5 class="">Nous Contacter:</h5>	
													<p>Lieu: <strong>Carrefour MEEC </strong><br/>											
													Phone: <strong>670103490 / 694573490 </strong><br/>
					Email: <strong><a href="emailto:infos@spacekola.com">infos@Spacekola.com</a></strong></p>
					
												</td>
											</tr>
										</table><!-- /column 2 -->
										
										<span class="clear"></span>	
										
									</td>
								</tr>
							</table><!-- /social & contact -->
							
						</td>
					</tr>
				</table>
				</div><!-- /content -->
										
			</td>
			<td></td>
		</tr>
	</table><!-- /BODY -->

	<!-- FOOTER -->
	<table class="footer-wrap">
		<tr>
			<td></td>
			<td class="container">
				
					<!-- content -->
					<div class="content">
					<table>
					<tr>
						<td align="center">
							<p>
								<a href="http://www.spacekola.com">spacekola</a> |
								<a href="#">Conditions d\'utilisations</a> 
								
							</p>
						</td>
					</tr>
				</table>
					</div><!-- /content -->
					
			</td>
			<td></td>
		</tr>
	</table><!-- /FOOTER -->

	</body>
	</html>';
}
