<?php 
    require 'Entity/User.php';

    //require 'Dao/UserDAO.php';
    require 'Form/UserForm.php';
    require 'Controller/UserController.php';
    require 'Controller/UserunitController.php';
    //require 'Genesis/UserGenesis.php';
    require "Controller/GlobalController.php";
    require "Controller/RegistrationController.php";
    require "Controller/LoginController.php";
