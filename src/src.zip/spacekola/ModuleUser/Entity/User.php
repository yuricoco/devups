<?php

/**
 * @Entity @Table(name="user")
 * */
class User extends \Model implements JsonSerializable {

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;

    /**
     * @Column(name="pseudo", type="string" , length=55 )
     * @var string
     * */
    protected $pseudo;

    /**
     * @Column(name="pseudounic", type="string" , length=55 )
     * @var string
     * */
    protected $pseudounic;
    
    /**
     * @Column(name="firstname", type="string" , length=55, nullable=true )
     * @var string
     * */
    protected $firstname;

    /**
     * @Column(name="lastname", type="string" , length=55, nullable=true )
     * @var string
     * */
    protected $lastname;

    /**
     * @Column(name="email", type="string" , length=55, nullable=true )
     * @var string
     * */
    protected $email;

    /**
     * @Column(name="sexe", type="string" , length=5, nullable=true  )
     * @var string
     * */
    protected $sexe;

    /**
     * @Column(name="phonenumber", type="string" , length=25, nullable=true  )
     * @var string
     * */
    protected $phonenumber;

    /**
     * @Column(name="password", type="string" , length=255, nullable=true  )
     * @var string
     * */
    protected $password;
    /**
     * @Column(name="resettingpassword", type="integer" , nullable=true  )
     * @var string
     * */
    protected $resettingpassword;

    /**
     * @Column(name="is_activated", type="integer" , nullable=true  )
     * @var string
     * */
    protected $is_activated;
    /**
     * @Column(name="ischecker", type="integer" , nullable=true  )
     * @var string
     * */
    protected $ischecker;
    /**
     * @Column(name="istranslator", type="integer" , nullable=true  )
     * @var string
     * */
    protected $istranslator;
    /**
     * @Column(name="isdrawer", type="integer" , nullable=true  )
     * @var string
     * */
    protected $isdrawer;
    /**
     * @Column(name="activationcode", type="string" , length=255, nullable=true  )
     * @var string
     * */
    protected $activationcode;

    /**
     * @Column(name="birthdate", type="date", nullable=true   )
     * @var date
     * */
    protected $birthdate;

    /**
     * @Column(name="creationdate", type="datetime", nullable=true   )
     * @var date
     * */
    protected $creationdate;

    /**
     * @Column(name="lang", type="string", length=15, nullable=true   )
     * @var date
     * */
    protected $lang;

    /**
     * @ManyToOne(targetEntity="\Country")
     * , inversedBy="reporter"
     * @var \Country
     */
    protected $country;
    /**
     * @Column(name="aboutme", type="string" , length=255, nullable=true  )
     * @var string
     * */
    protected $aboutme;
    /**
     * @Column(name="location", type="string" , length=155, nullable=true  )
     * @var string
     * */
    protected $location;


    public function __construct($id = null) {

        if ($id) {
            $this->id = $id;
        }

        $this->country = new Country();
    }

    public static function lastregistration()
    {
        return User::select()->where("this.creationdate")
            ->between(getadmin()->getLastloginAt(), date("Y-m-d H:i:s"))
            ->__countEl();
    }

    public function getId() {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getPseudo()
    {
        return htmlspecialchars($this->pseudo);
    }

    /**
     * @param string $pseudo
     */
    public function setPseudo($pseudo)
    {
        $this->pseudo = $pseudo;
    }

    /**
     * @return string
     */
    public function getPseudounic()
    {
        return $this->pseudounic;
    }

    /**
     * @param string $pseudounic
     */
    public function setPseudounic($pseudounic)
    {
        $this->pseudounic = $pseudounic;
    }

    /**
     * @return date
     */
    public function getBirthdate()
    {
        return $this->birthdate;
    }

    /**
     * @param date $birthdate
     */
    public function setBirthdate($birthdate)
    {
        $this->birthdate = $birthdate;
    }

    public function getFirstname() {
        return $this->firstname;
    }

    public function setFirstname($firstname) {
        $this->firstname = $firstname;
    }

    public function getLastname() {
        return $this->lastname;
    }

    public function setLastname($lastname) {
        $this->lastname = $lastname;
    }

    /**
     * @return string
     */
    public function getIschecker()
    {
        return $this->ischecker;
    }

    /**
     * @param string $ischecker
     */
    public function setIschecker($ischecker)
    {
        $this->ischecker = $ischecker;
    }

    /**
     * @return string
     */
    public function getIstranslator()
    {
        return $this->istranslator;
    }

    /**
     * @param string $istranslator
     */
    public function setIstranslator($istranslator)
    {
        $this->istranslator = $istranslator;
    }

    /**
     * @return string
     */
    public function getIsdrawer()
    {
        return $this->isdrawer;
    }

    /**
     * @param string $isdrawer
     */
    public function setIsdrawer($isdrawer)
    {
        $this->isdrawer = $isdrawer;
    }

    /**
     * @return date
     */
    public function getLang()
    {
        return $this->lang;
    }

    /**
     * @param date $lang
     */
    public function setLang($lang)
    {
        $this->lang = $lang;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getPhonenumber() {
        return $this->phonenumber;
    }

    public function setPhonenumber($phonenumber) {
        $this->phonenumber = $phonenumber;
    }

    /**
     *  manyToOne
     * 	@return \Country
     */
    function getCountry() {
        return $this->country;
    }

    function setCountry(\Country $country) {
        $this->country = $country;
    }
    function getSexe() {
        return $this->sexe;
    }

    function setSexe($sexe) {
        $this->sexe = $sexe;
    }

        function getIs_connect() {
        return $this->is_connect;
    }

    /**
     * @return date
     */
    public function getCreationdate()
    {
        return $this->creationdate;
    }

    /**
     * @param date $creationdate
     */
    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }


    function setIs_connect($is_connect) {
        $this->is_connect = $is_connect;
    }

    /**
     * @return string
     */
    public function getisActivated()
    {
        return (int) $this->is_activated;
    }

    /**
     * @param string $is_activated
     */
    public function setIsActivated($is_activated)
    {
        $this->is_activated = $is_activated;
    }

    /**
     * @return string
     */
    public function getActivationcode()
    {
        return $this->activationcode;
    }

    /**
     * @param string $activationcode
     */
    public function setActivationcode($activationcode)
    {
        $this->activationcode = $activationcode;
    }

    public static function errorlist() {
        return ['firstname' => "", 'lastname' => "", 'phonenumber' => "", 'email' => "", 'password' => "", 'Country' => ""];
    }

    /**
     * @return string
     */
    public function getResettingpassword()
    {
        return $this->resettingpassword;
    }

    /**
     * @param string $resettingpassword
     */
    public function setResettingpassword($resettingpassword)
    {
        $this->resettingpassword = $resettingpassword;
    }

    /**
     * @return string
     */
    public function getAboutme()
    {
        return $this->aboutme;
    }

    /**
     * @param string $aboutme
     */
    public function setAboutme($aboutme)
    {
        $this->aboutme = $aboutme;
    }

    /**
     * @return string
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * @param string $location
     */
    public function setLocation($location)
    {
        $this->location = $location;
    }

    public function getImageprofile($mini = ""){
        return Dfile::show($mini."profile.jpg", "users/".$this->id);
    }

    public function commentuser(){
        return [
            'id' => $this->id,
            'pseudo' => $this->__get("pseudo"),
            'imageprofile' => $this->getImageprofile("45_")
        ];
    }

    public function jsonSerialize() {
        return [
            'id' => (int) $this->id,
            'pseudo' => $this->pseudo,
            'lang' => $this->lang,
            'istranslator' => $this->istranslator,
            'ischecker' => $this->ischecker,
            'isdrawer' => $this->isdrawer,
            'is_activated' => $this->is_activated,
            'country' => $this->country,
            'alias' => $this->password,
            'imageprofile' => $this->getImageprofile("45_"),
            'aboutme' => $this->aboutme,
        ];
    }

}
