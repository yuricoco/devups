<?php
            //ModuleLocation
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleLocation</a> ');

    
        		$countryCtrl = new CountryController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'country/index':
        Genesis::renderView('country.index',  $countryCtrl->listAction());
        break;					
    case 'country/create':
        Genesis::renderView( 'country.form', $countryCtrl->createAction(), true);
        break;					
    case 'country/update':
        Genesis::renderView( 'country.form',  $countryCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    