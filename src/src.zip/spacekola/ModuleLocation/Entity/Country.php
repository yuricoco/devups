<?php

/**
 * @Entity @Table(name="country")
 * */
class Country extends \Model implements JsonSerializable {

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;

    /**
     * @Column(name="code", type="string" , length=5 )
     * @var string
     * */
    private $code;

    /**
     * @Column(name="alpha2", type="string" , length=2 )
     * @var string
     * */
    private $alpha2;

    /**
     * @Column(name="alpha3", type="string" , length=3 )
     * @var string
     * */
    private $alpha3;

    /**
     * @Column(name="nom_en", type="string" , length=255 )
     * @var string
     * */
    private $nom_en;

    /**
     * @Column(name="nom_fr", type="string" , length=255 )
     * @var string
     * */
    private $nom_fr;

    /**
     * @Column(name="continent_id", type="integer" )
     * @var string
     * */
    private $continent_id;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getCode() {
        return $this->code;
    }

    public function setCode($code) {
        $this->code = $code;
    }

    public function getAlpha2() {
        return $this->alpha2;
    }

    public function setAlpha2($alpha2) {
        $this->alpha2 = $alpha2;
    }

    public function getAlpha3() {
        return $this->alpha3;
    }

    public function setAlpha3($alpha3) {
        $this->alpha3 = $alpha3;
    }

    public function getName() {
//        if(local() == "fr")
//            return $this->nom_fr;

        return $this->nom_en;
    }

    public function setNom_en($nom_en) {
        $this->nom_en = $nom_en;
    }

    public function getNom_fr() {
        return  $this->nom_fr .  ' (+' . $this->code . ')' ;
    }

    public function setNom_fr($nom_fr) {
        $this->nom_fr = $nom_fr;
    }

    public function jsonSerialize() {
        return [
            'id' => $this->id,
            'name' => $this->getName(),
            'phonecode' => $this->code,
        ];
    }

}
