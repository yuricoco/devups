<?php


class Country2 extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;

    /**
     * @var string
     *
     * @Column(name="iso", type="string", length=2, nullable=false)
     */
    protected $iso;

    /**
     * @var string
     *
     * @Column(name="iso3", type="string", length=3, nullable=true)
     */
    protected $iso3;

    /**
     * @var string
     *
     * @Column(name="name", type="string", length=80, unique=true)
     */
    protected $name;

    /**
     * @var string
     *
     * @Column(name="nicename", type="string", length=80, unique=true)
     */
    protected $nicename;

    /**
     * @var string
     *
     * @Column(name="numcode", type="integer", length=6, nullable=true)
     */
    protected $numcode;

    /**
     * @var string
     *
     * @Column(name="phonecode", type="integer", length=5)
     */
    protected $phonecode;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

    }

    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getPhonecode()
    {
        return $this->phonecode;
    }

    public function setPhonecode($phonecode)
    {
        $this->phonecode = $phonecode;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($status)
    {
        $this->status = $status;
    }


    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'phonecode' => $this->phonecode,
        ];
    }

}
