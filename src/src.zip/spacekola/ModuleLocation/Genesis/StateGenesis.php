<?php 
				
	class StateGenesis{
		
		static function genesis($view, $controllers, \StateController $stateCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('state.index',  $stateCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'state.form',  $stateCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'state.form', $stateCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'state.form',  $stateCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'state.form',  $stateCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'state.show', $stateCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'state.show', $stateCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \StateController $stateCtrl = null ){
			extract($controllers);
			
			switch($view){
				
				case 'index':
					echo json_encode($stateCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($stateCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($stateCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($stateCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($stateCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
