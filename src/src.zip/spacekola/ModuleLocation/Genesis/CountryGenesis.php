<?php 
				
	class CountryGenesis{
		
		static function genesis($view, $controllers, \CountryController $countryCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('country.index',  $countryCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'country.form',  $countryCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'country.form', $countryCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'country.form',  $countryCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'country.form',  $countryCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'country.show', $countryCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'country.show', $countryCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \CountryController $countryCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					echo json_encode($countryCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($countryCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($countryCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($countryCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($countryCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
