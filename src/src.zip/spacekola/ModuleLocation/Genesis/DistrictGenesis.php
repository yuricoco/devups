<?php 
				
	class DistrictGenesis{
		
		static function genesis($view, $controllers, \DistrictController $districtCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('district.index',  $districtCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'district.form',  $districtCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'district.form', $districtCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'district.form',  $districtCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'district.form',  $districtCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'district.show', $districtCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'district.show', $districtCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \DistrictController $districtCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					echo json_encode($districtCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($districtCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($districtCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($districtCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($districtCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
