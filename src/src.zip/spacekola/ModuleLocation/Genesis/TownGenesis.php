<?php 
				
	class TownGenesis{
		
		static function genesis($view, $controllers, \TownController $townCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('town.index',  $townCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'town.form',  $townCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'town.form', $townCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'town.form',  $townCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'town.form',  $townCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'town.show', $townCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'town.show', $townCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \TownController $townCtrl = null ){
			extract($controllers);
			
			switch($view){
				
				case 'index':
					echo json_encode($townCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($townCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($townCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($townCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($townCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
