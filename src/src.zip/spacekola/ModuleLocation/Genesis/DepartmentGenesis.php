<?php 
				
	class DepartmentGenesis{
		
		static function genesis($view, $controllers, \DepartmentController $departmentCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('department.index',  $departmentCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'department.form',  $departmentCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'department.form', $departmentCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'department.form',  $departmentCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'department.form',  $departmentCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'department.show', $departmentCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'department.show', $departmentCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \DepartmentController $departmentCtrl = null ){
			extract($controllers);
			
			switch($view){
				
				case 'index':
					echo json_encode($departmentCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($departmentCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($departmentCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($departmentCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($departmentCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
