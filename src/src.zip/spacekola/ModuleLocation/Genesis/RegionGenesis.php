<?php 
				
	class RegionGenesis{
		
		static function genesis($view, $controllers, \RegionController $regionCtrl = null ){
			extract($controllers);
			
			switch($view){
				case 'index':
					Genesis::renderView('region.index',  $regionCtrl->listAction(), 'list');
					break;
					
				case '_new':
                                                                                                            Genesis::renderView( 'region.form',  $regionCtrl->__newAction(), 'new');
					break;
					
				case 'create':
                                                                                                            Genesis::renderView( 'region.form', $regionCtrl->createAction(), 'error creation', true);
					break;
					
				case '_edit':
                                                                                                            Genesis::renderView( 'region.form',  $regionCtrl->__editAction($_GET['id']), 'edite');
					break;
					
				case 'update':
					Genesis::renderView( 'region.form',  $regionCtrl->updateAction($_GET['id']),'error updating', true);
					break;
					
				case 'show':
                                                                                                                Genesis::renderView( 'region.show', $regionCtrl->showAction($_GET['id']), 'Show');
					break;
					
				case 'delete':
                                                                                                                Genesis::renderView( 'region.show', $regionCtrl->deleteAction($_GET['id']), 'delete', true);
					break;
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}
		}			
			
		static function restGenesis($view, $controllers, \RegionController $regionCtrl = null ){
			extract($controllers);
			
			switch($view){
				
				case 'index':
					echo json_encode($regionCtrl->listAction());
					break;
					
				case 'new':
					echo json_encode($regionCtrl->createAction());
					break;
					
				case 'edit':
					echo json_encode($regionCtrl->editAction($_GET['id']));
					break;
					
				case 'show':
					echo json_encode($regionCtrl->showAction($_GET['id']));
					break;
					
				case 'delete':
					echo json_encode($regionCtrl->deleteAction($_GET['id']));
					break;
		
                                        
				default:
					echo 'la route n\'existe pas!';
					break;
			}  
		}
	}
		
