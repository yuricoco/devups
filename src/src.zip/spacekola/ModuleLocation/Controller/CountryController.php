<?php 


use DClass\devups\Datatable as Datatable;

class CountryController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            CountryForm::__renderFormWidget(Country::find($id), 'update');
        else
            CountryForm::__renderFormWidget(new Country(), 'create');
    }

    public static function renderDetail($id) {
        CountryForm::__renderDetailWidget(Country::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $country = new Country();
        if($id){
            $action = "update&id=".$id;
            $country = Country::find($id);
            //$country->collectStorage();
        }

        return ['success' => true,
            'form' => CountryForm::__renderForm($country, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Country(), $next, $per_page);
        return ['success' => true,
            'tablebody' => Datatable::getTableRest($lazyloading),
            'tablepagination' => Datatable::pagination($lazyloading)
        ];
    }

    public function listAction($next = 1, $per_page = 50){

        $lazyloading = $this->lazyloading(new Country(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $country = Country::find($id);

            return array( 'success' => true, 
                            'Country' => $country,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($country_form = null){
        extract($_POST);
        $this->err = array();

        $country = $this->form_fillingentity(new Country(), $country_form);
 

        if ( $id = $country->__insert()) {
            return 	array(	'success' => true, // pour le restservice
                            'Country' => $country,
                            'tablerow' => Datatable::getSingleRowRest($country),
                            'redirect' => 'index', // pour le web service
                            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
        } else {
            return 	array(	'success' => false, // pour le restservice
                            'Country' => $country,
                            'action_form' => 'create', // pour le web service
                            'detail' => 'error data not persisted'); //Detail de l'action ou message d'erreur ou de succes
        }

    }

    public function updateAction($id, $country_form = null){
        extract($_POST);
            
        $country = $this->form_fillingentity(new Country($id), $country_form);

            
        if ($country->__update()) {
            return 	array('success' => true, // pour le restservice
                            'Country' => $country,
                            'tablerow' => Datatable::getSingleRowRest($country),
                            'redirect' => 'index', // pour le web service
                            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
        } else {
            return 	array('success' => false, // pour le restservice
                            'Country' => $country,
                            'action_form' => 'update&id='.$id, // pour le web service
                            'detail' => 'error data not updated'); //Detail de l'action ou message d'erreur ou de succes
        }
    }
    
    public function deleteAction($id){
      
            Country::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Country::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'Country' => new Country(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $country = Country::find($id);

        return array('success' => true, // pour le restservice
                        'Country' => $country,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
