<?php

class TownController extends Controller {
    
    public static function gettownlocation() {
        
        extract($_POST);
        if ($key != babycare_key){
            return ["error" => true, "message" => "error key", "result" => ""];
        }
        
        $department = new Department($_POST["iddepartment"]);
        $towns = Town::select()->where($department)->__getAllRow();
        
        return ["error" => false, "message" => "", "result" => $towns];
    }
    
    public static function gettown() {
        
        extract($_POST);
        if ($key != babycare_key){
            return ["error" => true, "message" => "error key", "result" => ""];
        }
        
        $user = Parents::find($id);
        
        if($user->getactivationcode() != $token){
            return ["error" => true, "message" => "error token", "result" => ""];
        }
        
        
        $towns = Town::select()
                ->leftjoin("region","department")
                ->leftjoin("country","region")
                ->where("country.id",$countryid)->__getAll($recursif=false);
        
        return ["error" => false, "message" => "", "result" => $towns];
    }


    /**
     * retourne l'instance de l'entité ou un json pour les requete asynchrone (ajax)
     *
     * @param type $id
     * @return \Array
     */
    public function showAction($id) {

        $town = Town::find($id);

        return array('success' => true,
            'town' => $town,
            'detail' => 'detail de l\'action.');
    }

    /**
     * Data for creation form
     * @Sequences: controller - genesis - ressource/view/form
     * @return \Array
     */
    public function __newAction() {

        return array('success' => true, // pour le restservice
            'town' => new Town(),
            'action_form' => 'create', // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }

    /**
     * Action on creation form
     * @Sequences: controller - genesis - ressource/view/form
     * @return \Array
     */
    public function createAction() {
        extract($_POST);
        $this->err = array();

        $town = $this->form_generat(new Town(), $town_form);


        if ($id = $town->__insert()) {
            return array('success' => true, // pour le restservice
                'town' => $town,
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
        } else {
            return array('success' => false, // pour le restservice
                'town' => $town,
                'action_form' => 'create', // pour le web service
                'detail' => 'error data not persisted'); //Detail de l'action ou message d'erreur ou de succes
        }
    }

    /**
     * Data for edit form
     * @Sequences: controller - genesis - ressource/view/form
     * @param type $id
     * @return \Array
     */
    public function __editAction($id) {

        $town = Town::find($id);

        return array('success' => true, // pour le restservice
            'town' => $town,
            'action_form' => 'update&id=' . $id, // pour le web service
            'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }

    /**
     * Action on edit form
     * @Sequences: controller - genesis - ressource/view/index
     * @param type $id
     * @return \Array
     */
    public function updateAction($id) {
        extract($_POST);
        $this->err = array();

        $town = $this->form_generat(new Town($id), $town_form);


        if ($town->__update()) {
            return array('success' => true,
                'town' => $town,
                'redirect' => 'index',
                'detail' => '');
        } else {
            return array('success' => false,
                'town' => $town,
                'action_form' => 'update&id=' . $id,
                'detail' => 'error data not updated'); //Detail de l'action ou message d'erreur ou de succes
        }
    }

    /**
     * 
     *
     * @param type $id
     * @return \Array
     */
    public function listAction($next = 1, $per_page = 10) {

        $lazyloading = $this->lazyloading(new Town(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');
    }

    public function deleteAction($id) {

        $town = Town::find($id);

        if ($town->__delete())
            return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
        else
            return array('success' => false, // pour le restservice
                'town' => $town,
                'detail' => 'Des problèmes sont survenus lors de la suppression de l\'élément.'); //Detail de l'action ou message d'erreur ou de succes
    }

}
