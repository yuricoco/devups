<?php
            //ModuleLocation
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$countryCtrl = new CountryController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'country._new':
                g::json_encode(CountryController::renderForm());
                break;
        case 'country.create':
                g::json_encode($countryCtrl->createAction());
                break;
        case 'country._edit':
                g::json_encode(CountryController::renderForm(R::get("id")));
                break;
        case 'country.update':
                g::json_encode($countryCtrl->updateAction(R::get("id")));
                break;
        case 'country._show':
                g::json_encode(CountryController::renderDetail(R::get("id")));
                break;
        case 'country._delete':
                g::json_encode($countryCtrl->deleteAction(R::get("id")));
                break;
        case 'country._deletegroup':
                g::json_encode($countryCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'country.datatable':
                g::json_encode($countryCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : page note found", 'route' => R::get('path')]);
            break;
     }

