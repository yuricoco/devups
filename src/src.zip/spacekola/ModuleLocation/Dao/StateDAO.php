<?php 

    class StateDAO extends DBAL{

            public function __construct() {
                    parent::__construct(new State());
            }

    }