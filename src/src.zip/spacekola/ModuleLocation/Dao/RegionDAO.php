<?php 

    class RegionDAO extends DBAL{

            public function __construct() {
                    parent::__construct(new Region());
            }

    }