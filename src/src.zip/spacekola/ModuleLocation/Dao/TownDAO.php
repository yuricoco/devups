<?php 

    class TownDAO extends DBAL{

            public function __construct() {
                    parent::__construct(new Town());
            }

    }