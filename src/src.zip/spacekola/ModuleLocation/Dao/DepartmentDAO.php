<?php 

    class DepartmentDAO extends DBAL{

            public function __construct() {
                    parent::__construct(new Department());
            }

    }