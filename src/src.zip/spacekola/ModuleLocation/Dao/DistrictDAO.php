<?php 

	class DistrictDAO extends DBAL{
			
		public function __construct() {
			parent::__construct(new District());
		}			
		
	}