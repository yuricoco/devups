<?php 

    class CountryForm extends FormManager{

        public static function formBuilder(\Country $country, $action = null, $button = false) {
            $entitycore = new Core($country);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['name'] = [
                "label" => 'Name', 
"type" => FORMTYPE_TEXT,
                "value" => $country->getName(), 
            ];

            $entitycore->field['phonecode'] = [
                "label" => 'Phonecode', 
"type" => FORMTYPE_TEXT,
                "value" => $country->getPhonecode(), 
            ];

            $entitycore->field['status'] = [
                "label" => 'Status', 
			FH_REQUIRE => false,
 "type" => FORMTYPE_TEXT,
                "value" => $country->getStatus(), 
            ];

            
            $entitycore->addDformjs($action);
            
            return $entitycore;
        }
        
        public static function __renderForm(\Country $country, $action = null, $button = false) {
            return FormFactory::__renderForm(CountryForm::formBuilder($country, $action, $button));
        }
        
        public static function __renderFormWidget(\Country $country, $action_form = null) {
            include ROOT.Country::classpath()."Form/CountryFormWidget.php";
        }

        public static function __renderDetailWidget(\Country $country){
            include ROOT . Country::classpath() . "Form/CountryDetailWidget.php";
        }
    }
    