<?php 

    class RegionForm extends FormManager{

        public static function formBuilder(\Region $region, $action = null, $button = false) {
            $entitycore = $region->scan_entity_core();
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['name'] = [
                "label" => 'Name', 
			"type" => FORMTYPE_TEXT, 
                "value" => $region->getName(), 
            ];


            return $entitycore;
        }
        
        public static function __renderForm(\Region $region, $action = null, $button = false) {
            return FormFactory::__renderForm(RegionForm::formBuilder($region, $action, $button));
        }
        
    }
    