<?php 

    class DepartmentForm extends FormManager{

        public static function formBuilder(\Department $department, $action = null, $button = false) {
            $entitycore = $department->scan_entity_core();
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['name'] = [
                "label" => 'Name', 
			"type" => FORMTYPE_TEXT, 
                "value" => $department->getName(), 
            ];

                $entitycore->field['region'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $department->getRegion()->getId(),
                    "label" => 'Region',
                    "options" => FormManager::Options_Helper('name', Region::allrows()),
                ];


            return $entitycore;
        }
        
        public static function __renderForm(\Department $department, $action = null, $button = false) {
            return FormFactory::__renderForm(DepartmentForm::formBuilder($department, $action, $button));
        }
        
    }
    