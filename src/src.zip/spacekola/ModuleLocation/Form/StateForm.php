<?php 

    class StateForm extends FormManager{

        public static function formBuilder(\State $state, $action = null, $button = false) {
            $entitycore = $state->scan_entity_core();
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['name'] = [
                "label" => 'Name', 
			"type" => FORMTYPE_TEXT, 
                "value" => $state->getName(), 
            ];

            $entitycore->field['phonecode'] = [
                "label" => 'Phonecode', 
			"type" => FORMTYPE_TEXT, 
                "value" => $state->getPhonecode(), 
            ];


            return $entitycore;
        }
        
        public static function __renderForm(\State $state, $action = null, $button = false) {
            return FormFactory::__renderForm(StateForm::formBuilder($state, $action, $button));
        }
        
    }
    