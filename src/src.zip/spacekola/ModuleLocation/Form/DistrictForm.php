<?php 

    class DistrictForm extends FormManager{

        public static function formBuilder(\District $district, $action = null, $button = false) {
            $entitycore = $district->scan_entity_core();
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['name'] = [
                "label" => 'Name', 
			"type" => FORMTYPE_TEXT, 
                "value" => $district->getName(), 
            ];

                $entitycore->field['town'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $district->getTown()->getId(),
                    "label" => 'Town',
                    "options" => FormManager::Options_Helper('id', Town::allrows()),
                ];


            return $entitycore;
        }
        
        public static function __renderForm(\District $district, $action = null, $button = false) {
            return FormFactory::__renderForm(DistrictForm::formBuilder($district, $action, $button));
        }
        
    }
    