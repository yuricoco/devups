<?php 

    class TownForm extends FormManager{

        public static function formBuilder(\Town $town, $action = null, $button = false) {
            $entitycore = $town->scan_entity_core();
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
                
            
            $entitycore->field['name'] = [
                "label" => 'Name', 
			"type" => FORMTYPE_TEXT, 
                "value" => $town->getName(), 
            ];

                $entitycore->field['department'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $town->getDepartment()->getId(),
                    "label" => 'Department',
                    "options" => FormManager::Options_Helper('name', Department::allrows()),
                ];


            return $entitycore;
        }
        
        public static function __renderForm(\Town $town, $action = null, $button = false) {
            return FormFactory::__renderForm(TownForm::formBuilder($town, $action, $button));
        }
        
    }
    