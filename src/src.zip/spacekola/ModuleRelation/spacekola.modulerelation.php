<?php 
    require 'Entity/Follow.php';
    //require 'Dao/FollowDAO.php';
    require 'Form/FollowForm.php';
    require 'Controller/FollowController.php';
    //require 'Genesis/FollowGenesis.php';
