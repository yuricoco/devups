
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($follow, [
['label' => 'Following', 'value' => 'following'], 
['label' => 'Creationdate', 'value' => 'creationdate']
]); ?>

        </div>
			