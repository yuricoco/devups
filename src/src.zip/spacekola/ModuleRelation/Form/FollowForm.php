<?php 

    class FollowForm extends FormManager{

        public static function formBuilder(\Follow $follow, $action = null, $button = false) {
            $entitycore = new Core($follow);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['following'] = [
                "label" => 'Following', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $follow->getFollowing(), 
            ];

            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate', 
			"type" => FORMTYPE_TEXT, 
                "value" => $follow->getCreationdate(), 
            ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/followForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Follow $follow, $action = null, $button = false) {
            return FormFactory::__renderForm(FollowForm::formBuilder($follow, $action, $button));
        }
        
        public static function __renderFormWidget(\Follow $follow, $action_form = null) {
            include ROOT.Follow::classpath()."Form/FollowFormWidget.php";
        }

        public static function __renderDetailWidget(\Follow $follow){
            include ROOT . Follow::classpath() . "Form/FollowDetailWidget.php";
        }
    }
    