<?php
            //ModuleRelation
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$followCtrl = new FollowController();
		
     (new Request('hello'));

     switch (R::get('path')) {
                
        case 'follow._new':
                g::json_encode(FollowController::renderForm());
                break;
        case 'follow.create':
                g::json_encode($followCtrl->createAction());
                break;
        case 'follow._edit':
                g::json_encode(FollowController::renderForm(R::get("id")));
                break;
        case 'follow.update':
                g::json_encode($followCtrl->updateAction(R::get("id")));
                break;
        case 'follow._show':
                FollowController::renderDetail(R::get("id"));
                break;
        case 'follow._delete':
                g::json_encode($followCtrl->deleteAction(R::get("id")));
                break;
        case 'follow._deletegroup':
                g::json_encode($followCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'follow.datatable':
                g::json_encode($followCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
            break;
     }

