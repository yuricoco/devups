<?php
            //ModuleRelation
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModuleRelation</a> ');

    
        		$followCtrl = new FollowController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'follow/index':
        Genesis::renderView('follow.index',  $followCtrl->listAction());
        break;					
    case 'follow/create':
        Genesis::renderView( 'follow.form', $followCtrl->createAction(), true);
        break;					
    case 'follow/update':
        Genesis::renderView( 'follow.form',  $followCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    