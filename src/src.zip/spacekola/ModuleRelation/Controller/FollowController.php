<?php 


use DClass\devups\Datatable as Datatable;

class FollowController extends Controller{

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Follow(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Follow(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }

    public static function createAction($userid){
        //extract($_POST);

        $follow = new Follow();
        $follow->setFollower($_SESSION[USERID]);
        $follow->setFollowing($userid);
        $follow->setCreationdate(new DateTime());
        $follow->__insert();

        $user = new User($userid);
        $notifuser = new Notificationbroadcasted();
        //$notifuser->notification = $notification;
        $notifuser->user = $user;
        $notifuser->setUrl("profile?user=".$_SESSION[USERID]);

        $notifuser->setCreationdate(new DateTime());
        $notifuser->setContent(gettranslation("notif.newfollower", $user->__get("lang")));
        $notifuser->__insert();

        return 	array(	'success' => true,
                        'follow' => $follow,
                        'username' => User::getattribut("pseudo", $userid),
                        'detail' => '');

    }
    
    public function deleteAction($id){
      
            Follow::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Follow::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
