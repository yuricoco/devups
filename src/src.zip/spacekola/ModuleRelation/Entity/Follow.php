<?php 
    /**
     * @Entity @Table(name="follow")
     * */
    class Follow extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="follower", type="integer"  , nullable=true)
         * @var integer
         **/
        private $follower;
        /**
         * @Column(name="following", type="integer"  , nullable=true)
         * @var integer
         **/
        private $following;
        /**
         * @Column(name="creationdate", type="datetime"  )
         * @var datetime
         **/
        private $creationdate; 
        

        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
}

        public function getId() {
            return $this->id;
        }
        public function getFollower() {
            return $this->follower;
        }

        public function setFollower($follower) {
            $this->follower = $follower;
        }
        
        public function getFollowing() {
            return $this->following;
        }

        public function setFollowing($following) {
            $this->following = $following;
        }
        
        public function getCreationdate() {
            return $this->creationdate;
        }

        public function setCreationdate($creationdate) {
            $this->creationdate = $creationdate;
        }
        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'follower' => $this->follower,
                                'following' => $this->following,
                                'creationdate' => $this->creationdate,
                ];
        }
        
}
