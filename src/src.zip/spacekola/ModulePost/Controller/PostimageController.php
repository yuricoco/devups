<?php 


use DClass\devups\Datatable as Datatable;

class PostimageController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            PostimageForm::__renderFormWidget(Postimage::find($id), 'update');
        else
            PostimageForm::__renderFormWidget(new Postimage(), 'create');
    }

    public static function renderDetail($id) {
        PostimageForm::__renderDetailWidget(Postimage::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $postimage = new Postimage();
        if($id){
            $action = "update&id=".$id;
            $postimage = Postimage::find($id);
            //$postimage->collectStorage();
        }

        return ['success' => true,
            'form' => PostimageForm::__renderForm($postimage, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Postimage(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Postimage(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $postimage = Postimage::find($id);

            return array( 'success' => true, 
                            'postimage' => $postimage,
                            'detail' => 'detail de l\'action.');

    }

    public static function createAction($postid = null){
        extract($_POST);

        $image = new Image();
        $path = "post/$postid/images/".$_SESSION[USERID]."/";
        $url = Image::Dfile("image")
            ->addresize([540], "540_", "", false)
            ->addresize([270, 270], "270_", $path."mini/")
            ->addresize([150, 150], "150_", $path."mini/")
            ->addresize([80], "80_", $path."mini/")
            ->saveoriginal(true)
            ->hashname()
            ->setConstraintfiletype()
            ->moveto($path);

        if (!$url['success']) {
            return 	$url;
        }

        $image->setHeight_size($url['file']["imagesize"][1]);
        $image->setWidth_size($url['file']["imagesize"][0]);
        $image->setPath($path);
        $image->setImage($url['file']["hashname"]);
        $image->setTitle($url['file']["name"]);
        $image->setCreationdate(new DateTime());
        $image->setIsnew(1);

        $image->__insert();

        $postimage = new Postimage();
        $postimage->image = $image;
        $postimage->post = new Post($postid);

        $postimage->setCreationdate(new DateTime());

        $id = $postimage->__insert();
        return 	array(	'success' => true,
                        'postimage' => $postimage,
                        'detail' => '');

    }

    public function updateAction($id, $postimage_form = null){
        extract($_POST);
            
        $postimage = $this->form_fillingentity(new Postimage($id), $postimage_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'postimage' => $postimage,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $postimage->__update();
        return 	array(	'success' => true,
                        'postimage' => $postimage,
                        'tablerow' => Datatable::getSingleRowRest($postimage),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Postimage::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Postimage::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'postimage' => new Postimage(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $postimage = Postimage::find($id);

        return array('success' => true, // pour le restservice
                        'postimage' => $postimage,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
