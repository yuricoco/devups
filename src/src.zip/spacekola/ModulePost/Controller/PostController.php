<?php 


use DClass\devups\Datatable as Datatable;

class PostController extends Controller{

    public function setstatueAction($id, $param)
    {

        $dbal = new DBAL();
        $dbal->executeDbal(" update post set status = '$param' where id = $id ");

    }
    
    public static function getsinglepost($postid, $isnew = false){
        return ['success' => true,
            'postcollection' => self::getpostcollection(Post::find($postid), $_SESSION[USERID]), $isnew];
    }

    public static function getpostcollection(\Post $post, $userid, $isnew = false){
        if($isnew)
            return [
                "post" => $post,
                'iliked' => 0,
                'nbkolas' => 0,
                "postimages" => Postimage::select()->where($post)->limit(5)->__getAll(false),
                "postcomments" => [],
            ];

        $qb = Postcomment::select()->where($post);

        $nbpc = Postcomment::count($post);
        $nbpages = $nbpc/5 + 1;
        $lazycomment = Controller::i()->lazyloading(new Postcomment(), $nbpages, 5, $qb);

        $iliked = 0;
        if(isset($_SESSION[USERID]))
            $iliked = (int) Kolapost::select()->where($post)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

        return [
            "post" => $post,
            'iliked' => $iliked,
            'nbkolas' => Kolapost::count($post),
            "postimages" => Postimage::select()->where($post)->limit(5)->__getAll(false),
            "nbpostimages" => Postimage::select()->where($post)->__countEl(),
            "postcomments" => $lazycomment,
            "nbpostcomments" => $nbpc,
        ];
    }

    public function getcollectionAction($userid = null, $next = 1, $per_page = 3) {

        $qb = Post::select()->where("this.status", 1);
        if($userid)
            $qb = Post::select()->where(new User($userid))->andwhere("this.status", 1);

        $lazyloading = $this->lazyloading(new Post(), $next, $per_page, $qb, "this.id desc");
        $postcollection = [];
        $posts = $lazyloading['listEntity'];
        foreach ($posts as $post){
            $postcollection[] = self::getpostcollection($post, $userid);
        }

        unset($lazyloading['listEntity']);
        $lazyloading['postcollections'] = $postcollection;
        return $lazyloading;

    }

    public function getsinglecollectionAction($postid, $userid) {

        $post = Post::find($postid);
        $postcollection = [];
        $qb = Postcomment::select()->where($post);
        $nbpc = Postcomment::count($post);
        $nbpages = $nbpc/5 + 1;
        $lazycomment = Controller::i()->lazyloading(new Postcomment(), $nbpages, 5, $qb);

        $postimagecollection = [];
        $postimages = Postimage::select()->where($post)->__getAll(false);

        foreach ($postimages as $postimage){

            $iliked = 0;
            if(isset($_SESSION[USERID]))
                $iliked = (int) Kolapostimage::select()->where($postimage)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

            $postimagecollection[] = [
                "postimage" => $postimage,
                'iliked' => $iliked,
                'nbkolas' => Kolapostimage::count($postimage),
            ];
        }

        $iliked = 0;
        if(isset($_SESSION[USERID]))
            $iliked = (int) Kolapost::select()->where($post)->andwhere("this.user_id", $_SESSION[USERID])->__countEl(false);

        $postcollection[] = [
            "post" => $post,
            'iliked' => $iliked,
            'nbkolas' => Kolapost::count($post),
            "postimagecollection" => $postimagecollection,
            "postcomments" => $lazycomment,
            "nbpostcomments" => $nbpc,
        ];

        $lazyloading = Controller::i()->lazyloading2([$post]);

        unset($lazyloading['listEntity']);
        $lazyloading['postcollections'] = $postcollection;
        return $lazyloading;

    }

    public static function renderFormWidget($id = null) {
        if($id)
            PostForm::__renderFormWidget(Post::find($id), 'update');
        else
            PostForm::__renderFormWidget(new Post(), 'create');
    }

    public static function renderDetail($id) {
        PostForm::__renderDetailWidget(Post::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $post = new Post();
        if($id){
            $action = "update&id=".$id;
            $post = Post::find($id);
            //$post->collectStorage();
        }

        return ['success' => true,
            'form' => PostForm::__renderForm($post, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Post(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Post(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $post = Post::find($id);

            return array( 'success' => true, 
                            'post' => $post,
                            'detail' => 'detail de l\'action.');

    }

    public static function createAction($post_form = null){
        extract($_POST);

        $post = new Post();
        if(isset($postcontent))
            $post->setContent(htmlspecialchars($postcontent));

        $post->setUser(new User($_SESSION[USERID]));

        $post->setCreationdate(new DateTime());

        $id = $post->__insert();
        return 	array(	'success' => true,
                        'post' => $post,
                        'postcollection' => self::getpostcollection(Post::find($id), $_SESSION[USERID]),
                        'detail' => '');

    }

    public function updateAction($id, $post_form = null){
        extract($_POST);
            
        $post = $this->form_fillingentity(new Post($id), $post_form);

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'post' => $post,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $post->__update();
        return 	array(	'success' => true,
                        'post' => $post,
                        'tablerow' => Datatable::getSingleRowRest($post),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Post::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Post::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'post' => new Post(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $post = Post::find($id);

        return array('success' => true, // pour le restservice
                        'post' => $post,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
