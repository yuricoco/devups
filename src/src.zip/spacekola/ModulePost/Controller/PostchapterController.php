<?php 


use DClass\devups\Datatable as Datatable;

class PostchapterController extends Controller{


    public static function renderFormWidget($id = null) {
        if($id)
            PostchapterForm::__renderFormWidget(Postchapter::find($id), 'update');
        else
            PostchapterForm::__renderFormWidget(new Postchapter(), 'create');
    }

    public static function renderDetail($id) {
        PostchapterForm::__renderDetailWidget(Postchapter::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $postchapter = new Postchapter();
        if($id){
            $action = "update&id=".$id;
            $postchapter = Postchapter::find($id);
            //$postchapter->collectStorage();
        }

        return ['success' => true,
            'form' => PostchapterForm::__renderForm($postchapter, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Postchapter(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Postchapter(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $postchapter = Postchapter::find($id);

            return array( 'success' => true, 
                            'postchapter' => $postchapter,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($postchapter_form = null){
        extract($_POST);

        $postchapter = $this->form_fillingentity(new Postchapter(), $postchapter_form);
 

        $postchapter->setCreationdate(new DateTime());

        if ( $this->error ) {
            return 	array(	'success' => false,
                            'postchapter' => $postchapter,
                            'action_form' => 'create', 
                            'error' => $this->error);
        }
        
        $id = $postchapter->__insert();
        return 	array(	'success' => true,
                        'postchapter' => $postchapter,
                        'tablerow' => Datatable::getSingleRowRest($postchapter),
                        'detail' => '');

    }

    public function updateAction($id, $postchapter_form = null){
        extract($_POST);
            
        $postchapter = $this->form_fillingentity(new Postchapter($id), $postchapter_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'postchapter' => $postchapter,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $postchapter->__update();
        return 	array(	'success' => true,
                        'postchapter' => $postchapter,
                        'tablerow' => Datatable::getSingleRowRest($postchapter),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Postchapter::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Postchapter::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'postchapter' => new Postchapter(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $postchapter = Postchapter::find($id);

        return array('success' => true, // pour le restservice
                        'postchapter' => $postchapter,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
