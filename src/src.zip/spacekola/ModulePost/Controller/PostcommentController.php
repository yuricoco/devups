<?php 


use DClass\devups\Datatable as Datatable;

class PostcommentController extends Controller{

    public static function getpreviouscomment($postid, $pvpage){

        $qb = Postcomment::select()->where(new Post($postid));

        return Controller::i()->lazyloading(new Postcomment(), $pvpage, 5, $qb);
    }

    public static function renderFormWidget($id = null) {
        if($id)
            PostcommentForm::__renderFormWidget(Postcomment::find($id), 'update');
        else
            PostcommentForm::__renderFormWidget(new Postcomment(), 'create');
    }

    public static function renderDetail($id) {
        PostcommentForm::__renderDetailWidget(Postcomment::find($id));
    }

    public static function renderForm($id = null, $action = "create") {
        $postcomment = new Postcomment();
        if($id){
            $action = "update&id=".$id;
            $postcomment = Postcomment::find($id);
            //$postcomment->collectStorage();
        }

        return ['success' => true,
            'form' => PostcommentForm::__renderForm($postcomment, $action, true),
        ];
    }

    public function datatable($next, $per_page) {
        $lazyloading = $this->lazyloading(new Postcomment(), $next, $per_page);
        return ['success' => true,
            'datatable' => Datatable::getTableRest($lazyloading),
        ];
    }

    public function listAction($next = 1, $per_page = 10){

        $lazyloading = $this->lazyloading(new Postcomment(), $next, $per_page);

        return array('success' => true, // pour le restservice
            'lazyloading' => $lazyloading, // pour le web service
            'detail' => '');

    }
    
    public  function showAction($id){

            $postcomment = Postcomment::find($id);

            return array( 'success' => true, 
                            'postcomment' => $postcomment,
                            'detail' => 'detail de l\'action.');

    }

    public function createAction($postid, $postcomment_form = null){
        extract($_POST);

        $postcomment = new Postcomment();

        if(isset($_FILES["postcomment_form"])){

            $path = "post/$postid/commentimages/".$_SESSION[USERID]."/";
            $url = Postcomment::Dfile("image")
                ->addresize([150, 150], "150_", "mini/")
                ->addresize([80], "80_", $path."mini/")
                ->addresize([300], "", "", false, 90)
                ->saveoriginal(false)
                ->hashname()
                ->setConstraintfiletype()
                ->moveto($path);

            if($url["success"]){
                $postcomment->setPath($path);
                $postcomment->setImage($url["file"]["hashname"]);
            }
        }

        $postcomment->setCreationdate(new DateTime());
        $postcomment->setComment(htmlspecialchars($postcomment_form["comment"]));
        $postcomment->post = new Post($postid);
        $postcomment->user = new User($_SESSION[USERID]);
        $id = $postcomment->__insert();

        return 	array(	'success' => true,
                        'postcomment' => Postcomment::find($id),
                        'detail' => '');

    }

    public function updateAction($id, $postcomment_form = null){
        extract($_POST);
            
        $postcomment = $this->form_fillingentity(new Postcomment($id), $postcomment_form);

                    
        if ( $this->error ) {
            return 	array(	'success' => false,
                            'postcomment' => $postcomment,
                            'action_form' => 'update&id='.$id,
                            'error' => $this->error);
        }
        
        $postcomment->__update();
        return 	array(	'success' => true,
                        'postcomment' => $postcomment,
                        'tablerow' => Datatable::getSingleRowRest($postcomment),
                        'detail' => '');
                        
    }
    
    public function deleteAction($id){
      
            Postcomment::delete($id);
        return 	array(	'success' => true, // pour le restservice
                        'redirect' => 'index', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes
    }
    

    public function deletegroupAction($ids)
    {

        Postcomment::delete()->where("id")->in($ids)->exec();

        return array('success' => true, // pour le restservice
                'redirect' => 'index', // pour le web service
                'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __newAction(){

        return 	array(	'success' => true, // pour le restservice
                        'postcomment' => new Postcomment(),
                        'action_form' => 'create', // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

    public function __editAction($id){

       $postcomment = Postcomment::find($id);

        return array('success' => true, // pour le restservice
                        'postcomment' => $postcomment,
                        'action_form' => 'update&id='.$id, // pour le web service
                        'detail' => ''); //Detail de l'action ou message d'erreur ou de succes

    }

}
