<?php

/**
 * @Entity @Table(name="postcomment")
 * */
class Postcomment extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="creationdate", type="datetime"  )
     * @var datetime
     **/
    private $creationdate;

    /**
     * @ManyToOne(targetEntity="\Post")
     * , inversedBy="reporter"
     * @var \Post
     */
    public $post;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    public $user;

    /**
     * @Column(name="comment", type="string", length=255 , nullable=true  )
     * @var string
     **/
    private $comment;
    /**
     * @Column(name="image", type="string" , length=255 , nullable=true )
     * @var string
     **/
    private $image;
    /**
     * @Column(name="path", type="string" , length=150 , nullable=true)
     * @var string
     **/
    private $path;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->post = new Post();
        $this->user = new User();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getCreationdate()
    {
        return $this->creationdate;
    }

    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    /**
     *  manyToOne
     * @return \Post
     */
    function getPost()
    {
        $this->post = $this->post->__show();
        return $this->post;
    }

    function setPost(\Post $post)
    {
        $this->post = $post;
    }

    /**
     *  manyToOne
     * @return \Comment
     */
    function getComment()
    {
        return $this->comment;
    }

    function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param string $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return string
     */
    public function getPath()
    {
        return $this->path;
    }

    /**
     * @param string $path
     */
    public function setPath($path)
    {
        $this->path = $path;
    }

    /**
     * @return User
     */
    public function getUser()
    {
        $this->user = $this->user->__show();
        return $this->user;
    }

    /**
     * @param User $user
     */
    public function setUser($user)
    {
        $this->user = $user;
    }


    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'creationdate' => $this->creationdate,
            'comment' => $this->comment,
            'user' => $this->user->commentuser(),
            'showimage' => Dfile::show($this->image, $this->path),
            'image' => $this->image,
        ];
    }

}
