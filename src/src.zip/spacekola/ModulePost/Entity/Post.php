<?php

/**
 * @Entity @Table(name="post")
 * */
class Post extends \Model implements JsonSerializable
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="content", type="text"  , nullable=true)
     * @var text
     **/
    private $content;
    /**
     * @Column(name="poststyle", type="text"  , nullable=true)
     * @var text
     **/
    private $poststyle;
    /**
     * @Column(name="reach", type="integer"  , nullable=true)
     * @var integer
     **/
    private $reach;
    /**
     * @Column(name="locked", type="boolean"  , nullable=true)
     * @var boolean
     **/
    private $locked;
    /**
     * @Column(name="creationdate", type="datetime"  )
     * @var datetime
     **/
    private $creationdate;
    
    /**
     * @Column(name="status", type="integer"  )
     * @var boolean
     **/
    private $status = 1;

    /**
     * @ManyToOne(targetEntity="\User")
     * , inversedBy="reporter"
     * @var \User
     */
    public $user;


    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->user = new User();
    }

    public static function lastpublication()
    {

        return self::select()->where("this.creationdate")
            ->between(getadmin()->getLastloginAt(), date("Y-m-d H:i:s"))
            ->__countEl();
    }

    public function getId()
    {
        return $this->id;
    }

    public function getContent()
    {
        return $this->content;
    }

    public function setContent($content)
    {
        $this->content = $content;
    }

    public function getPoststyle()
    {
        return $this->poststyle;
    }

    public function setPoststyle($poststyle)
    {
        $this->poststyle = $poststyle;
    }

    public function getReach()
    {
        return $this->reach;
    }

    public function setReach($reach)
    {
        $this->reach = $reach;
    }

    public function getLocked()
    {
        return $this->locked;
    }

    public function setLocked($locked)
    {
        $this->locked = $locked;
    }

    public function getCreationdate()
    {
        return $this->creationdate;
    }

    public function setCreationdate($creationdate)
    {
        $this->creationdate = $creationdate;
    }

    /**
     *  manyToOne
     * @return \User
     */
    function getUser()
    {
        $this->user = $this->user->__show();
        return $this->user;
    }

    function setUser(\User $user)
    {
        $this->user = $user;
    }

    function getDate(){
        if(is_object($this->creationdate))
            return $this->creationdate;

        return (new DateTime($this->creationdate));
    }
    function getStatus() {
        return $this->status;
    }

    function setStatus($status) {
        $this->status = $status;
    }

    public function getStatusform()
    {
        $ch_publish = '';
        $ch_dust = '';

        ($this->status == '1') ? $ch_publish = 'checked' : $ch_dust = 'checked' ;

        return '  <label class="checkbox-inline">  
                  <input ' . $ch_publish . ' type="radio" name="' . $this->id . '_statu" value="1" class="statuer" >
                  publish
                </label> 
                <label class="checkbox-inline">  
                  <input ' . $ch_dust . ' type="radio" name="' . $this->id . '_statu" value="0" class="statuer" >
                  blocked
                </label> ';
    }
    

    public function jsonSerialize()
    {
        return [
            'id' => $this->id,
            'content' => $this->content,
            'poststyle' => $this->poststyle,
            'reach' => $this->reach,
            'locked' => $this->locked,
            'creationdate' => $this->getDate()->format("Y M d - H:i"),
            'user' => $this->user,
        ];
    }

}
