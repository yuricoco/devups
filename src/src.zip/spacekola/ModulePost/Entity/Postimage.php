<?php 
    /**
     * @Entity @Table(name="postimage")
     * */
    class Postimage extends \Model implements JsonSerializable{

        /**
         * @Id @GeneratedValue @Column(type="integer")
         * @var int
         * */
        protected $id;
        /**
         * @Column(name="content", type="string" , length=255 , nullable=true)
         * @var string
         **/
        private $content;
        /**
         * @Column(name="creationdate", type="datetime"  )
         * @var datetime
         **/
        private $creationdate; 
        
        /**
         * @ManyToOne(targetEntity="\Post")
         * , inversedBy="reporter"
         * @var \Post
         */
        public $post;

        /**
         * @ManyToOne(targetEntity="\Image")
         * , inversedBy="reporter"
         * @var \Image
         */
        public $image;


        
        public function __construct($id = null){
            
                if( $id ) { $this->id = $id; }   
                          
	$this->post = new Post();
	$this->image = new Image();
}

        public function getId() {
            return $this->id;
        }
        public function getContent() {
            return $this->content;
        }

        public function setContent($content) {
            $this->content = $content;
        }
        
        public function getCreationdate() {
            return $this->creationdate;
        }

        public function setCreationdate($creationdate) {
            $this->creationdate = $creationdate;
        }
        
        /**
         *  manyToOne
         *	@return \Post
         */
        function getPost() {
            $this->post = $this->post->__show();
            return $this->post;
        }
        function setPost(\Post $post) {
            $this->post = $post;
        }
                        
        /**
         *  manyToOne
         *	@return \Image
         */
        function getImage() {
            $this->image = $this->image->__show();
            return $this->image;
        }
        function setImage(\Image $image) {
            $this->image = $image;
        }
                        
        
        public function jsonSerialize() {
                return [
                        'id' => $this->id,
                                'content' => $this->content,
                                'creationdate' => $this->creationdate,
                                'post' => $this->post,
                                'image' => $this->image->__show(false)->postimage(),
                ];
        }
        
}
