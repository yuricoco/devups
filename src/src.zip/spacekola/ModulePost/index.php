<?php
            //ModulePost
        
        require '../../../admin/header.php';
        
        global $views;
        $views = __DIR__ . '/Ressource/views';
                


    
    define('CHEMINMODULE', ' <a href="index.php" target="_self" class="titre_module">Administration du system global</a> &gt; <a href="index.php?path=layout" target="_self" class="titre_module">Module ModulePost</a> ');

    
        		$postCtrl = new PostController();		$postimageCtrl = new PostimageController();		$postchapterCtrl = new PostchapterController();		$postcommentCtrl = new PostcommentController();		

(new Request('layout'));

switch (Request::get('path')) {

    case 'layout':
        Genesis::renderBladeView("layout");
        break;
        
    case 'post/index':
        Genesis::renderView('post.index',  $postCtrl->listAction());
        break;					
    case 'post/create':
        Genesis::renderView( 'post.form', $postCtrl->createAction(), true);
        break;					
    case 'post/update':
        Genesis::renderView( 'post.form',  $postCtrl->updateAction($_GET['id']), true);
        break;


    case 'postimage/index':
        Genesis::renderView('postimage.index',  $postimageCtrl->listAction());
        break;					
    case 'postimage/create':
        Genesis::renderView( 'postimage.form', $postimageCtrl->createAction(), true);
        break;					
    case 'postimage/update':
        Genesis::renderView( 'postimage.form',  $postimageCtrl->updateAction($_GET['id']), true);
        break;


    case 'postchapter/index':
        Genesis::renderView('postchapter.index',  $postchapterCtrl->listAction());
        break;					
    case 'postchapter/create':
        Genesis::renderView( 'postchapter.form', $postchapterCtrl->createAction(), true);
        break;					
    case 'postchapter/update':
        Genesis::renderView( 'postchapter.form',  $postchapterCtrl->updateAction($_GET['id']), true);
        break;


    case 'postcomment/index':
        Genesis::renderView('postcomment.index',  $postcommentCtrl->listAction());
        break;					
    case 'postcomment/create':
        Genesis::renderView( 'postcomment.form', $postcommentCtrl->createAction(), true);
        break;					
    case 'postcomment/update':
        Genesis::renderView( 'postcomment.form',  $postcommentCtrl->updateAction($_GET['id']), true);
        break;


		
    default:
        Genesis::renderView('404', ['page' => Request::get('path')]);
        break;
}
    
    