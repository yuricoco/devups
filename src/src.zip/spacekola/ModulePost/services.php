<?php
            //ModulePost
		
        require '../../../admin/header.php';
        
        use Genesis as g;
        use Request as R;
        
        header("Access-Control-Allow-Origin: *");
                

		$postCtrl = new PostController();
		$postimageCtrl = new PostimageController();
		$postchapterCtrl = new PostchapterController();
		$postcommentCtrl = new PostcommentController();
		
     (new Request('hello'));

     switch (R::get('path')) {

         case 'post.setstatus':
             g::json_encode($postCtrl->setstatueAction($_GET['id'], Request::get("param")));
             break;
        case 'post._new':
                g::json_encode(PostController::renderForm());
                break;
        case 'post.create':
                g::json_encode($postCtrl->createAction());
                break;
        case 'post._edit':
                g::json_encode(PostController::renderForm(R::get("id")));
                break;
        case 'post.update':
                g::json_encode($postCtrl->updateAction(R::get("id")));
                break;
        case 'post._show':
                PostController::renderDetail(R::get("id"));
                break;
        case 'post._delete':
                g::json_encode($postCtrl->deleteAction(R::get("id")));
                break;
        case 'post._deletegroup':
                g::json_encode($postCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'post.datatable':
                g::json_encode($postCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'postimage._new':
                g::json_encode(PostimageController::renderForm());
                break;
        case 'postimage.create':
                g::json_encode($postimageCtrl->createAction());
                break;
        case 'postimage._edit':
                g::json_encode(PostimageController::renderForm(R::get("id")));
                break;
        case 'postimage.update':
                g::json_encode($postimageCtrl->updateAction(R::get("id")));
                break;
        case 'postimage._show':
                PostimageController::renderDetail(R::get("id"));
                break;
        case 'postimage._delete':
                g::json_encode($postimageCtrl->deleteAction(R::get("id")));
                break;
        case 'postimage._deletegroup':
                g::json_encode($postimageCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'postimage.datatable':
                g::json_encode($postimageCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'postchapter._new':
                g::json_encode(PostchapterController::renderForm());
                break;
        case 'postchapter.create':
                g::json_encode($postchapterCtrl->createAction());
                break;
        case 'postchapter._edit':
                g::json_encode(PostchapterController::renderForm(R::get("id")));
                break;
        case 'postchapter.update':
                g::json_encode($postchapterCtrl->updateAction(R::get("id")));
                break;
        case 'postchapter._show':
                PostchapterController::renderDetail(R::get("id"));
                break;
        case 'postchapter._delete':
                g::json_encode($postchapterCtrl->deleteAction(R::get("id")));
                break;
        case 'postchapter._deletegroup':
                g::json_encode($postchapterCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'postchapter.datatable':
                g::json_encode($postchapterCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

        case 'postcomment._new':
                g::json_encode(PostcommentController::renderForm());
                break;
        case 'postcomment.create':
                g::json_encode($postcommentCtrl->createAction());
                break;
        case 'postcomment._edit':
                g::json_encode(PostcommentController::renderForm(R::get("id")));
                break;
        case 'postcomment.update':
                g::json_encode($postcommentCtrl->updateAction(R::get("id")));
                break;
        case 'postcomment._show':
                PostcommentController::renderDetail(R::get("id"));
                break;
        case 'postcomment._delete':
                g::json_encode($postcommentCtrl->deleteAction(R::get("id")));
                break;
        case 'postcomment._deletegroup':
                g::json_encode($postcommentCtrl->deletegroupAction(R::get("ids")));
                break;
        case 'postcomment.datatable':
                g::json_encode($postcommentCtrl->datatable(R::get('next'), R::get('per_page')));
                break;

	
        default:
            echo json_encode(['error' => "404 : action note found", 'route' => R::get('path')]);
            break;
     }

