//postCtrl

$("#dv_table").on("click", ".statuer", function () {
    console.log($(this).parents('tr').attr("id"));
    console.log($(this).val());
    $("#blockspinner").fadeIn();
    var id = $(this).parents('tr').attr("id");
    model._get("setstatus&id=" + id + "&param=" + $(this).val(),
        function (response) {
            console.log(response);
            //$("#dv_table").find("#"+id).replaceWith(response.tablerow);
            alert("change saved");
        });
});
