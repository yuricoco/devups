<?php 

    class PostchapterForm extends FormManager{

        public static function formBuilder(\Postchapter $postchapter, $action = null, $button = false) {
            $entitycore = new Core($postchapter);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate', 
			"type" => FORMTYPE_TEXT, 
                "value" => $postchapter->getCreationdate(), 
            ];

                $entitycore->field['post'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $postchapter->getPost()->getId(),
                    "label" => 'Post',
                    "options" => FormManager::Options_Helper('poststyle', Post::allrows()),
                ];

                $entitycore->field['chapter'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $postchapter->getChapter()->getId(),
                    "label" => 'Chapter',
                    "options" => FormManager::Options_Helper('id', Chapter::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/postchapterForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Postchapter $postchapter, $action = null, $button = false) {
            return FormFactory::__renderForm(PostchapterForm::formBuilder($postchapter, $action, $button));
        }
        
        public static function __renderFormWidget(\Postchapter $postchapter, $action_form = null) {
            include ROOT.Postchapter::classpath()."Form/PostchapterFormWidget.php";
        }

        public static function __renderDetailWidget(\Postchapter $postchapter){
            include ROOT . Postchapter::classpath() . "Form/PostchapterDetailWidget.php";
        }
    }
    