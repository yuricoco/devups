<?php 

    class PostcommentForm extends FormManager{

        public static function formBuilder(\Postcomment $postcomment, $action = null, $button = false) {
            $entitycore = new Core($postcomment);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
                $entitycore->field['post'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $postcomment->getPost()->getId(),
                    "label" => 'Post',
                    "options" => FormManager::Options_Helper('poststyle', Post::allrows()),
                ];

                $entitycore->field['comment'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $postcomment->getComment()->getId(),
                    "label" => 'Comment',
                    "options" => FormManager::Options_Helper('id', Comment::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/postcommentForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Postcomment $postcomment, $action = null, $button = false) {
            return FormFactory::__renderForm(PostcommentForm::formBuilder($postcomment, $action, $button));
        }
        
        public static function __renderFormWidget(\Postcomment $postcomment, $action_form = null) {
            include ROOT.Postcomment::classpath()."Form/PostcommentFormWidget.php";
        }

        public static function __renderDetailWidget(\Postcomment $postcomment){
            include ROOT . Postcomment::classpath() . "Form/PostcommentDetailWidget.php";
        }
    }
    