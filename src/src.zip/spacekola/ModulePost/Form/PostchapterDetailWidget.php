
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($postchapter, [
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Post', 'value' => 'Post.poststyle'], 
['label' => 'Chapter', 'value' => 'Chapter.id']
]); ?>

        </div>
			