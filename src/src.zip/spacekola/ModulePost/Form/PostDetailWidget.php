
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($post, [
['label' => 'Poststyle', 'value' => 'poststyle'], 
['label' => 'Reach', 'value' => 'reach'], 
['label' => 'Locked', 'value' => 'locked'], 
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'User', 'value' => 'User.firstname']
]); ?>

        </div>
			