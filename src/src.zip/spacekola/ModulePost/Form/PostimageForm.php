<?php 

    class PostimageForm extends FormManager{

        public static function formBuilder(\Postimage $postimage, $action = null, $button = false) {
            $entitycore = new Core($postimage);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate', 
			"type" => FORMTYPE_TEXT, 
                "value" => $postimage->getCreationdate(), 
            ];

                $entitycore->field['post'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $postimage->getPost()->getId(),
                    "label" => 'Post',
                    "options" => FormManager::Options_Helper('poststyle', Post::allrows()),
                ];

                $entitycore->field['image'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $postimage->getImage()->getId(),
                    "label" => 'Image',
                    "options" => FormManager::Options_Helper('id', Image::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/postimageForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Postimage $postimage, $action = null, $button = false) {
            return FormFactory::__renderForm(PostimageForm::formBuilder($postimage, $action, $button));
        }
        
        public static function __renderFormWidget(\Postimage $postimage, $action_form = null) {
            include ROOT.Postimage::classpath()."Form/PostimageFormWidget.php";
        }

        public static function __renderDetailWidget(\Postimage $postimage){
            include ROOT . Postimage::classpath() . "Form/PostimageDetailWidget.php";
        }
    }
    