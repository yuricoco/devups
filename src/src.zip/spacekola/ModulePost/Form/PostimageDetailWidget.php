
        <div class="col-lg-12 col-md-12">
                
                    <?= \DClass\devups\Datatable::renderentitydata($postimage, [
['label' => 'Creationdate', 'value' => 'creationdate'], 
['label' => 'Post', 'value' => 'Post.poststyle'], 
['label' => 'Image', 'value' => 'Image.id']
]); ?>

        </div>
			