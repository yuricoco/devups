<?php 

    class PostForm extends FormManager{

        public static function formBuilder(\Post $post, $action = null, $button = false) {
            $entitycore = new Core($post);
            
            $entitycore->formaction = $action;
            $entitycore->formbutton = $button;
            
            //$entitycore->addcss('csspath');
                
            
            $entitycore->field['poststyle'] = [
                "label" => 'Poststyle', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $post->getPoststyle(), 
            ];

            $entitycore->field['reach'] = [
                "label" => 'Reach', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $post->getReach(), 
            ];

            $entitycore->field['locked'] = [
                "label" => 'Locked', 
			FH_REQUIRE => false,
 			"type" => FORMTYPE_TEXT, 
                "value" => $post->getLocked(), 
            ];

            $entitycore->field['creationdate'] = [
                "label" => 'Creationdate', 
			"type" => FORMTYPE_TEXT, 
                "value" => $post->getCreationdate(), 
            ];

                $entitycore->field['user'] = [
                    "type" => FORMTYPE_SELECT, 
                    "value" => $post->getUser()->getId(),
                    "label" => 'User',
                    "options" => FormManager::Options_Helper('firstname', User::allrows()),
                ];

            
            $entitycore->addDformjs($action);
            $entitycore->addjs('Ressource/js/postForm.js');
            
            return $entitycore;
        }
        
        public static function __renderForm(\Post $post, $action = null, $button = false) {
            return FormFactory::__renderForm(PostForm::formBuilder($post, $action, $button));
        }
        
        public static function __renderFormWidget(\Post $post, $action_form = null) {
            include ROOT.Post::classpath()."Form/PostFormWidget.php";
        }

        public static function __renderDetailWidget(\Post $post){
            include ROOT . Post::classpath() . "Form/PostDetailWidget.php";
        }
    }
    