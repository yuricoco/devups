<?php 
    require 'Entity/Post.php';
    //require 'Dao/PostDAO.php';
    require 'Form/PostForm.php';
    require 'Controller/PostController.php';
    //require 'Genesis/PostGenesis.php';

    require 'Entity/Postimage.php';
    //require 'Dao/PostimageDAO.php';
    require 'Form/PostimageForm.php';
    require 'Controller/PostimageController.php';
    //require 'Genesis/PostimageGenesis.php';

    require 'Entity/Postchapter.php';
    //require 'Dao/PostchapterDAO.php';
    require 'Form/PostchapterForm.php';
    require 'Controller/PostchapterController.php';
    //require 'Genesis/PostchapterGenesis.php';

    require 'Entity/Postcomment.php';
    //require 'Dao/PostcommentDAO.php';
    require 'Form/PostcommentForm.php';
    require 'Controller/PostcommentController.php';
    //require 'Genesis/PostcommentGenesis.php';
