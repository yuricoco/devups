<div class='form-group'>
<label for='ref'>Ref</label>
	<b><?= $dvups_lang->getRef(); ?></b>
 </div>
<div class='form-group'>
<label for='content'>Content</label>
	<p><?= $dvups_lang->getContent(); ?></p>
 </div>
<div class='form-group'>
<label for='_table'>_table</label>
	<p><?= $dvups_lang->get_table(); ?></p>
 </div>
<div class='form-group'>
<label for='_column'>_column</label>
	<p><?= $dvups_lang->get_column(); ?></p>
 </div>
<div class='form-group'>
<label for='lang'>Lang</label>
	<p><?= $dvups_lang->getLang(); ?></p>
 </div>
