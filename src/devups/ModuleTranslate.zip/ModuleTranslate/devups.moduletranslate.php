<?php 
    require 'Entity/Dvups_lang.php';
    require 'Dao/Dvups_langDAO.php';
    require 'Form/Dvups_langForm.php';
    require 'Controller/Dvups_langController.php';
    require 'Genesis/Dvups_langGenesis.php';

    require 'Entity/Dvups_contentlang.php';
    require 'Dao/Dvups_contentlangDAO.php';
    require 'Form/Dvups_contentlangForm.php';
    require 'Controller/Dvups_contentlangController.php';
    require 'Genesis/Dvups_contentlangGenesis.php';
